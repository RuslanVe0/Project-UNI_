Sipistoverdi© services

#
#
#

Over the time, there'll be added more functionalities to the Server such as - web server client ui, improved UI and GUI with the python lib tkinter.
----------------------------------------------------
This product will also run in sipistoverdi services.
Sipistoverdi also will include downloadable content
packages specifically  for this project - server
"FTSRV".
----------------------------------------------------
To configure the server, please set in "config.ini" file ip_addr="IP-H" where IP-H = where the server will bind, in what network.
where port, configure to a desired port, default will be set to - 2121.

"config.ini" file is required, because it is the software's core. Without the configuration file, the user cannot do any kind of operations and the program will not start
correctly. There are commands that can be editted in the - 'config.ini' file.
-----------------------
User manual

(COMMANDS)
->
    *where "definition" means the user has the privilege to define specific variables inside the actual string, when the program awaits user input*
    *where in the output "!" it requires a definition, where "?" it means it requires another user input, where "*" it requires a single argument, without a definition.*
    * there's commands locally, and remotely. Client will be updated over time as well. This is the official release of this client.* 

x>
	STSRV -> (Start Server) the command will basically start the server on a local level, by binding the localhost IP and port both specified in the 'config.ini' file.
	It is threaded, and it is in a forever loop, asynchronously.
	HLSRV -> (Halt Server) the command will basically will stop binding the current socket instance.
	CLCON -> (Close Specific Connection) close a specific connection that is established with a client.
	ECONF -> (Edit Config) is a command that is specifically to edit the configuration file. That is not editting the file in the cwd! That command requires an argument, thus it requires. E.g => econf bindport 2121
	FING  -> (Fingerprint) is a command to trigger fingerprint or not. This command is not recommended to be activated, but it is due to user solution.
	SRSRV -> (Stop Requests in Server Envoirnemnt) is a command in order to stop accepting clients for specific time. This could be configured, only and only when there's a running instance of the server.
	CLA -> (Client Access), this command closes **all** connected clients, if server is not running hence it'll return that the server is not running, if client is disconnected, but exists it'll just remove it as an element that is in the actual list, where list (x) => that consists all connected clients. In a basic sense, it disconnects every client
	EXIT -> (Exit), this command will exit the current program, thus will close all connections, the actual socket and it'll delete all records from "ftsrv" schema in the local relational database management system (LRDMS which is being used (MySQL community edition, if optional enterprised edition)).
	SHOWCN -> (Show connections), is a command that shows all current existing connections.
	USRS -> (users), is a command that fetches all records from the database, where records - only usernames. All registered accounts.
	ADDUSR -> (Add user), is a command that registeres a new user. There's an existing argument for the command, E.G - addusr anon anon /a True, and that user will be added as anonymous, if anonymous feature activated of course.
	DELUSR (Delete user), is a command that removes a client. It takes an argument, by user desire. E.G delusr anon /f. That argument requires administrative priveleges.
	CLSC -> (Clear screen), is a command that clears the current output in the command ui window.
	UESC -> (Update Account settings), is a command that updates account configuration in the database. If something is updated in the config.ini file, specifically for the client, it'll be automatically updated in the database. Use "uesc /f" to forcibly do the operation.                                                                         
	USEROWN -> (User own), is a command that changes the group purpose of an account. Requires - username and password to be supolied with - accountName and accountpassword arguments in the text of the command.                                                                                            
	AUTACC -> (Auto login account), is a command that automatically tries to authorize the user, without the usage of passwords and etcetera.
<x

z>
	Commands with slashes.
	UESC /? -> /f - forcibly to do an operation, /m - manually to do operation.
	USRS /? -> /f - forcibly to do an operation, mainly for the password or username. Requires administrative elevation.
	USEROWN /? -> /f -forcibly to do an operation, mainly for the password or username. Requires administrative elevation. It requires to be supplied with - accountname and accountpassword as arguments in the cmmand.
<z

y>
	Commands with arguments.
	USRS ? -> ? - change.password, change.username, more.showall. "change.password" => changes password, "change.username" => changes username, "more.showall" => show information, about a specific account.
<y