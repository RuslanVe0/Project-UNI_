class lfinst(object):
	def __init__(self:object, socket:object):
		if self.ioc["wgetinstVerb"] != "False":
			print("[operation.lfinst] Preparing to fetch file...\r\x0A\r\x0A")
		xz = input("Remote resource (http included!):")
		if xz.split(":")[0] not in ["http", "https"]:
			raise Exception("Scheme required. Given non-scheme.")
		sch, host = xz.split("://")
		pathName = host.split(host.split("/")[0])[1]
		socket.create_instance_socket(port={"http":80, "https":443}[sch], host=host.split("/")[0].strip())
		if xz.split("://")[0] == "http" or xz.split("://")[0] == "https":
			pkt = self.httpPrepare(host, "GET", pathName, input("Supply a cookie (if not available just input blank): "))
		socket.sendPacket(packet=(pkt).encode("utf-8", errors="ignore"))
		name = ""
		while name == "":
			name = input("Validate a name for the file: ")
		if bool(self.ioc["wgetinstVerb"]) != "False":
			print("[operation.lfinst] Downloading file....\r\x0A\r\x0A")
		fileContents = socket.downloadFile(namefile=name)