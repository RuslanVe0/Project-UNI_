from hashlib import sha512
from Cryptodome.Cipher import AES
from json import loads

class login_env(object):
	def __init__(self:object, instance:object, socket:object) -> (object, object):
		self.instance = instance; self.socket = socket
		self.open_env()

	def open_env(self:object):
		username = input("username>> ").lower()
		self.socket.sendPacket(username.encode("utf-8", errors="ignore"))
		ex = self.socket.receivePacket()
		if ex == False:
			print("[operation.login_env] Operation failed!")
			self.instance.instanceOfClass.connected = False
			self.instance.instanceOfClass.instanceSock = None
			return
		ex = ex.decode("utf-8", errors="ignore")
		if ex.startswith("error:") == True:
			print(ex)
			return
		encr = self.local_encrypt(username, input("password>> ").lower())
		self.socket.sendPacket(encr.encode("utf-8", errors="ignore"))
		attempt = self.socket.receivePacket().decode("utf-8", errors="ignore")
		if attempt.startswith("error:") == True:
			print(attempt)
			return
		self.instance.instanceOfClass.userToken = loads(attempt) # the authorization token
		print("[operation.login_env] Login success. UUID-token account --> %s"%(self.instance.instanceOfClass.userToken["token"]))

	def crypt_pack(self:object, targets:tuple) -> (tuple):
		username, password = targets
		if len(username) > len(password):
			username = username[:len(username)-((len(username)-len(password)))]
		elif len(password) > len(username):
			password = password[:len(password)-(len(password) - len(username))]
		packed = ""
		n = 0
		for index, items in enumerate(username, 0):
			if index+1+n >= len(username)-1:
				continue
			pck = items + username[index+1+n]
			pck += password[index] + password[index+1+n]
			packed += pck
			n += 1
		while len(packed) > 32:
			packed = packed[:-1]
		while len(packed) < 32:
			packed += "a"
		return packed.encode("utf-8", errors="ignore")

	def hashlib_(self:object, target:bytes) -> (object, bytes):
		mod = sha512()
		mod.update(target)
		return mod.hexdigest()

	def local_encrypt(self:object, *args):
		username, password = args
		pack = self.crypt_pack((username, password))
		return self.hashlib_(AES.new(pack, AES.MODE_GCM, pack).encrypt(password.encode("utf-8", errors="ignore")))