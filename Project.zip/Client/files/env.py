from types import MethodType
from os import system, getcwd
from time import time
import os
from os.path import getsize, exists
from math import sqrt
from shutil import move
from winsound import Beep
from docs.gui.abstraction import *
from files.auto_login import auto_login

class scommands():

	def __init__(self:object, command:str, instanceOfClass:object) -> (object, str, object):
		self.cmd = command; self.instanceOfClass = instanceOfClass

	def return_(self:object):
		if isinstance(self.cmd, bool) == True:
			return False
		intf = {"help":'''
*--------------------------------------*

This product is licensed with -> Attribution-Non Commercial CC BY-NC 
(Intended for servers that support ONLY this client!)
(check README.md for command guide)
(help menu)

help    -> display all commands.
HELP+   -> Description of all commands.
HELPCMD -> Help on specific command (e.g helpcmd conn (and it'll output the help.))
____________________________________
                                    |
  CONN    BYES    EXIT * LMVFI      |
  REBD    CLSC  ! LOGR   LOPINI     |
! RLOD    CLST  ! CLER   LEDINI     |
! LOGF    REBD  ? LAPN   LDIFFIL    |
  LSDR  ? LFET    LTIM   LFINST     |
* LCHD    LPRVD * LRMFI  LBFID      |
  BELL    LPROV   CHIFC  AUTACC     | 
*--------------------------------------*

For further command guidence, please read contents from README.md file. All of the commands
are mentioned there, and described well and easily readable. You can of course integrate a new
command, its the client of course, BUT IT SHOULD actually meet server's commands ~ IF SERVER-SIDE ~.
This client is offical release. User inputs are NOT case sensitive, it doesn't matter if you enter a
command with upper || lower case.

------------------------------------------
Connection: %s
'''%(self.instanceOfClass.connected),
		"connect":self.instanceOfClass.establishConnection,
		"rebd":self.instanceOfClass.rebuild, "exit":exit,
		"logr":[self.cmd, "argumentParser"], "logf":[self.cmd, 
 		"argumentParser"], "rlod":[self.cmd, "argumentParser"], 
 		"clst":"\x0A".join(bob for bob in self.instanceOfClass.tmp),
 		"cler":[self.cmd, "argumentParser"], "ltim":"\x2D"*20 + "\r\x0A" + "Local Time\r\x0A\r\x0A" + self.instanceOfClass.getLocalTime() + "\r\x0A",
 		"lapn":[self.cmd, "argumentInput"], "lsdr":self.instanceOfClass.enumCWD,
   		"lfet":[self.cmd, "argumentInput"], "lchd":[self.cmd, "oneself"], 
    	"lprvd":self.instanceOfClass.prevDir, "lrmfi":[self.cmd, "argumentInput"],
		"lmvfi":[self.cmd, "argumentInput"], "opini":self.instanceOfClass.outputiniprop,
 		"ledini":self.instanceOfClass.editIni, "ldiffil":self.instanceOfClass.dbtf,
 		"lfinst":self.instanceOfClass.wgetinst,"help+":self.instanceOfClass.outputDesc, "helpcmd":[self.cmd, "argumentParser"],
 		"lbfid":self.instanceOfClass.biggestF, "bell":self.instanceOfClass.triggerBell,
 		"conn":self.instanceOfClass.conn_server, "lprov":self.instanceOfClass.trigger,
 		"diq":self.instanceOfClass.disconnect, "byes":self.instanceOfClass.disconnect, "quit":self.instanceOfClass.disconnect, "chifc":"Connected to server.\n" if self.instanceOfClass.connected == True and self.cmd.split(" ")[0].strip() == "chifc" and self.instanceOfClass.sendConReq() else "Disconnected.\n",}
		if self.cmd.strip() == "clsc":
			self.instanceOfClass.output("", True)
			return False
		if self.instanceOfClass.instanceSock != None and self.instanceOfClass.lbis != True:
			if self.cmd.strip() == "lprov":
				self.instanceOfClass.lbis = True
				return "[operation.trigger] Local based - %r"%(self.instanceOfClass.lbis)
			else:
				try:
					if len(self.cmd.strip()) == 0:
						return "Cannot send null message."
					if self.cmd.strip() == "test.connection":
						return ""
					if self.cmd.strip() == "user" and self.instanceOfClass.userToken != None and self.ami_authorized() == "False":
						msg = "[operation] gin_env] Account '%s' no longer in use!"%(self.instanceOfClass.userToken["account_user"]) + "\x0A"
						self.instanceOfClass.instanceSock.sendPacket(b"question_msg:closed_connection")
						reason = self.instanceOfClass.instanceSock.receivePacket().decode("utf-8", errors="ignore")
						msg += "[operation.login_env] Reason>> %s"%(reason)
						self.instanceOfClass.userToken = None
						return msg
					elif self.cmd.split(" ")[0].strip() == "saveac" and self.instanceOfClass.userToken != None:
						return auto_login(self).save_login(arguments=self.cmd)
					elif self.cmd.strip() == "user" and self.instanceOfClass.userToken != None and self.ami_authorized() == "True":
						msg = "[operation] Logging out of account... '%s'"%(self.instanceOfClass.userToken["account_user"])
						self.instanceOfClass.userToken = None
						return msg
					xz = self.instanceOfClass.instanceSock.sendPacket(self.cmd.strip().encode("utf-8", errors="ignore"))
					if self.instanceOfClass.instanceSock == None:
						return "[operation.connected] Server disconnected!"
					rcv = self.instanceOfClass.instanceSock.receivePacket()
					if isinstance(rcv, bool) == True:
						return
					if rcv == b"logout":
						self.instanceOfClass.userToken = None
						return "[operation.logout] Logout successful!"
					chk = self.instanceOfClass.xza.decode_commands(command=rcv)
					if chk == "login.username":
						self.instanceOfClass.login_env(instance=self, socket=self.instanceOfClass.instanceSock)
						chk = ""
					return chk
				except Exception as f:
					print(f)
					self.instanceOfClass.instanceSock = None; self.instanceOfClass.lbis = True
					return "[operation.connected] Disconnected from server!"
		if self.cmd.strip() == "autacc" and self.instanceOfClass.instanceSock != None:
			return auto_login(self).make_login_session()
		if self.cmd.strip().split(" ")[0] not in intf:
			return "'%s' is not recognized as a command. Please enter 'help' in order to output the help menu."%(self.cmd)
		self.instanceOfClass.cmd = self.cmd
		return intf[self.cmd.split(" ")[0].strip()]

	def ami_authorized(self:object):
		# this method is especially to understand whether the user is authorized or not.
		self.instanceOfClass.instanceSock.sendPacket(b"question_msg::amiauthorized?")
		rcv = self.instanceOfClass.instanceSock.receivePacket().decode("utf-8", errors="ignore")
		return rcv

	def parser(self:object, argument:str, value:str) -> (object, str, str):
		if argument == "local" and self.cmd[0].split(" ")[0] == "logr":
			cmds = {"on":True, "off":False}
			if value in cmds:
				self.instanceOfClass.log = cmds[value]
				return "local logging=%s"%(value)
		elif argument == "pars" and self.cmd[0].split(" ")[0] == "rlod":
			act = {"configfile":self.instanceOfClass.attr[0].__init__}
			if value in act:
				func = act[value]
				func(self.instanceOfClass)
				return " '%s' reloaded successfully!"%(value)
		elif argument == "var":
			n = False
			match value:
				case "tmp":
					self.instanceOfClass.tmp = []
					n = True
			if n != False:
				return "cleared for '%s'"%(value)
		elif argument == "filename" and self.cmd[0].split(" ")[0] == "logf":
			self.instanceOfClass.fileName = value
			return "filename='%s'"%(value)
		elif self.cmd[0].split(" ")[0] == "helpcmd" and argument == "cmd":
			commands = [bob.strip() for bob in self.instanceOfClass.outputDesc().split("\x0A")]
			sorts = {}
			for items in commands:
				if "->" in items:
					it, ti = items.split("->")
					sorts[it.strip().lower()] = ti.strip()
			if value in sorts:
				return sorts[value] + "\r\x0A"
		return "Incorrect argument passed for ='%s'"%(self.cmd[0].split(" ")[0])

	def LocalappendFile(self:object, *args):
		try:
			print(self.instanceOfClass.enumCWD())
			localFileInp, actualrmDir, undern = input("File>> "), input("Save path (leave blank for current directory)>>>> "), input("Name under>> ")
			fileContents = self.streamFile(file=localFileInp)
			fileContents = [bob for bob in fileContents]
		except (Exception, KeyboardInterrupt) as reason:
			return "Operation interrupted! Reason:: %s"%(reason)
		if len(actualrmDir) != 0 and actualrmDir[len(actualrmDir)-1] != "/":
			actualrmDir += "/"
		else:
			actualrmDir = getcwd()
		xz = open(actualrmDir + "/" + "%s"%(undern), "wb")
		for contents in fileContents:
			xz.write(contents)
		xz.close()
		return "[operation.appendFile] Operation succeeded with file '%s'!\x0A"%(localFileInp)

	def streamFile(self:object, file:str, chunk_size=1024) -> (str, int):
		with open(file, "rb") as reax:
			while True:
				chunk = reax.read(chunk_size)
				if not chunk:
					break
				yield chunk

	def RemoveFile(self:object, *args) -> (object, list):
		print(self.instanceOfClass.enumCWD())
		count = 0
		size = 0
		try:
			nameOfFile = input("File>> ")
			if "," in nameOfFile and len(nameOfFile.split(",")) > 1:
				nameOfFile = [bob for bob in nameOfFile.split(",")]
			else:
				nameOfFile = nameOfFile.split(",")
			mbn = 0
			for nameOfFile in nameOfFile:
				if len(nameOfFile) != 0:
					mb = getsize(nameOfFile)/1000000
					print("Attempting to delete :/%s, size: %d/mb"%(nameOfFile, mb))
					os.remove(nameOfFile.strip())
					count += 1
					size += mbn
		except Exception as e:
			return "[operation.RemoveFile] Operation failed due to %s!"%(e)
		return "All %d (total size of all files: %.2f/mb) files has been deleted successfully!"%(count, size)

	def LocalfetchFile(self:object, *args) -> (object, list):
		contents = self.instanceOfClass.enumCWD()
		print(contents + "\x0A")
		try:
			file, saveFile, nameFile = input("File>> "), input("Save path (leave blank for current directory)>> "), input("Name under>> ")
			tim = time()
			print("Trying to fetch %s -> %s [dir(%s)->%s]..."%(file, nameFile, getcwd(), saveFile))
			lenx = getsize(file) # length.
			print("Size of file: %d/mb"%(lenx/1000000))
			content = self.streamFile(file=file)
			content = [bob for bob in content]
			op = open(saveFile+"/%s"%(nameFile), "wb")
			print("Writing in new file..")
			for contents in content:
				op.write(contents)
			op.close()
		except Exception as e:
			return "\x0A[operation.fetchFile] Operation failed due to %s (Operation took:: %.10f)\x0A"%(e, time()-tim)
		return "\x0AFile written in destination >> %s (Operation took:: %.10f)"%(saveFile + "/%s"%(nameFile), time()-tim)

	def moveFile(self:object, *args) -> (object):
		try:
			print(self.instanceOfClass.enumCWD())
			source_file, destination_file = input("Source file: "), input("Destination directory: ")
			move(source_file, destination_file)
		except:
			return "[operation.moveFile] Operation interrupted\x0A"
		return "File '%s' moved to '%s'..\x0A"%(source_file, destination_file)

	def helpcmd(self:object, *args) -> (object):
		commands = self.instanceOfClass.outputDesc


	def argument_(self:object) -> (object, object, str):
		if len(self.cmd) == 2 and self.cmd[1] == "argumentParser" and len(self.cmd[0].split(" ")) > 1 and len(self.cmd[0].split(" ")[1].split("=")) == 2:
			eq,val = self.cmd[0].split(" ")[1].split("=")
			eq, val = eq.lower(), val.lower()
			return self.parser(argument=eq, value=val)
		elif len(self.cmd) == 2 and self.cmd[1] == "argumentInput":
			cause = {"lapn":[self.LocalappendFile, []], "lfet":[self.LocalfetchFile, []], "lrmfi":[self.RemoveFile, []], "lmvfi":[self.moveFile, []]}
			if self.cmd[0] not in cause:
				return "Incorrect argument passed for ='%s'"%(self.cmd[0].split(" ")[0])
			cause = cause[self.cmd[0]]
			func = cause[0]
			if len(cause) > 1:
				args = cause
				args.pop(0)
			else:
				args = []
			return func(args)
		elif len(self.cmd) == 2 and self.cmd[1] == "oneself" and len(self.cmd[0].split(" ")) > 1:
			arg = self.cmd[0].split(" ")[1].strip()
			return self.instanceOfClass.changeWD(todir=arg)
		return "Incorrect argument passed for ='%s'"%(self.cmd[0].split(" ")[0])

class runnogui(object):

	def readUserInput(self) -> (object):
		Argument = input("command> ")
		if len(Argument.strip()) == 0:
			return ""
		self.logOff(file=self.fileName, text="[Locally-%s] user executed '%s' command!"%(self.getLocalTime(), Argument))
		if len(Argument) > int(self.ioc["maxBuffer"]):
			rex = {True:Argument[:int(self.ioc["maxBuffer"])] + "......", False:Argument}[len(Argument)>int(self.ioc["maxBuffer"]) and len(Argument)>int(self.ioc["maxBuffer"])+12]
			Argument = rex
			return "Maximum length of a command is set to > %d, entered %d!"%(int(self.ioc["maxBuffer"]), len(Argument))
		self.tmp.append(Argument)
		return Argument.lower()

	def __init__(self:object, *args) -> (object):
		self.log = self.getValueDict(self.ioc, "log")
		self.fileName = self.getValueDict(self.ioc, "logf")
		self.connected = False
		self.tmp = []
		self.prv = []
		while (True):
			try:
				xz = scommands(command=runnogui.readUserInput(self).strip(), instanceOfClass=self).return_()
			except KeyboardInterrupt:
				if self.instanceSock != None:
					self.disconnect()
				exit()
			if xz == None:
				continue
			if xz == False:
				continue
			if isinstance(xz, str) == False and not isinstance(xz, tuple) == True and isinstance(xz, list) != True:
				xz = xz() # calling the actual method from the other class.
			if isinstance(xz, tuple) == True or isinstance(xz, list) == True:
				xz = scommands(command=xz, instanceOfClass=self).argument_()
			if self.bell == True:
				self.makeSoundEffect(func=Beep, melody="bell")
			print(xz)

class rungui(object):
	def __init__(self:object, *args) -> (object):
		instanceObject = gui(self)
		instanceObject.build()
		instanceObject.mainloop()
