from base64 import b64encode, b64decode
from os.path import exists
from Cryptodome.PublicKey import RSA
from Cryptodome.Cipher import PKCS1_OAEP
from json import dumps, loads
class auto_login(object):

    def __init__(self:object, instance:object) -> (object, object):
        self.instance = instance

    def save_login(self:object, arguments="saveac"):
        if self.save_login_exists() == True:
            return "[operation.save_login] Already a saved session exists! Please, remove old session then do this operation!"
        print("[operation.save_login] Saving current account...")
        self.instance.instanceOfClass.instanceSock.sendPacket(arguments.encode("utf-8", errors="ignore"))
        print("[operation.save_login] Receiving RSA pub key.")
        rcv = self.instance.instanceOfClass.instanceSock.receivePacket()
        if rcv.startswith(b"error:") == True:
            return "[operation.save_login] Operation failed! A problem occured while saving current login session! Reason>> %s"%(rcv.decode("utf-8", errors="ignore"))
        bits_size, rcv = rcv.split(b",")
        print("[operation.save_login] RSA (%s) public key received '%s'!"%(bits_size.decode("utf-8", errors="ignore"), len(rcv)))
        self.instance.instanceOfClass.write_in_file(file=self.instance.instanceOfClass.ioc["load_auto_login"], contents=b64decode(rcv))
        return "[operation.save_login] Operation completed! Saved RSA-public key!"
    
    def save_login_exists(self:object):
        find = self.instance.instanceOfClass.ioc["load_auto_login"]
        return exists(find)
    
    def make_login_session(self:object):
        if self.save_login_exists() == False:
            return "[operation.make_login_session] Session not found! Cannot automatically authorize a client."
        read = b64encode(b"".join(bob for bob in open(self.instance.instanceOfClass.ioc["load_auto_login"], "rb")))
        self.instance.instanceOfClass.instanceSock.sendPacket(b"auto_login")
        rcv = self.instance.instanceOfClass.instanceSock.receivePacket()
        if rcv != b"pub?":
            return "[operation.make_login_session] Operation failed! Server returned an unexpected response!"
        self.instance.instanceOfClass.instanceSock.sendPacket(dumps({"datetime":self.instance.instanceOfClass.getLocalTime(), "action":"login.action", "pub":read.decode("utf-8", errors="ignore")}).encode("utf-8", errors="ignore"))
        rcv = self.instance.instanceOfClass.instanceSock.receivePacket()
        if rcv.startswith(b"error:"):
            return "[operation.make_login_session] Operation failed! Reason>> %s"%(rcv.decode("utf-8", errors="ignore"))
        self.instance.instanceOfClass.userToken = loads(rcv) # the authorization token
        return "[operation.make_login_session] Auto login was successful!"