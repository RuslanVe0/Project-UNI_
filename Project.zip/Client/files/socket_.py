from socket import socket, AF_INET, SOCK_STREAM, getprotobyname
from ssl import create_default_context
from sys import stdout
from typing import Type, Union


class Socket(object):
	def __init__(self:object, instance:object, verbose=None) -> (object, bool):
		self.verbose = verbose; self.instance = instance

	def create_instance_socket(self:object, port:int, host:str) -> (object):
		if self.verbose:
			stdout.write("Preparing to connect to %s ...\x0A"%(host))

		self.sock = socket(AF_INET, SOCK_STREAM, getprotobyname("tcp"))
		self.sock.settimeout(20)
		self.sock.connect((host, port))
		if port == 443:
			if self.verbose:
				stdout.write("Preparing for SSL handshake ...\x0A")
			ctx = create_default_context()
			self.sock = ctx.wrap_socket(self.sock, server_hostname=host)

	def create_instance_socket_(self:object, host:int, port:int):
		self.create_instance_socket(host=host, port=port)
		return self.sock

	def return_instance(self:object):
		return self

	def sendPacket(self:object, packet:bytes) -> (bytes):
		try:
			self.sock.send(packet)
		except Exception as e:
			print("[operation.establishConn] Could not send data to server!")
			self.instance.instanceSock = None
			self.instance.connected = False
			return False
		return True

	def close(self:object):
		self.sock.close()

	def downloadFile(self:object, namefile:str, buffer=1284845) -> (int, str):
		with open(namefile, "wb") as file:
			itre = 1
			dots = "."
			while True:
				try:
					cont = self.sock.recv(buffer)
					if self.verbose == True:
						if len(dots) >= 3:
							dots = "."
						print("Downloading file... ::/%d-bytes %s"%(len(cont), dots), end="\r")
						dots += "."
					if len(cont) == 0:
						break
					if itre == 1:
						cont = cont.split(b"\r\x0A\r\x0A")[1]
					file.write(cont)
				except:
					break
				itre += 1
		self.sock.close()
		file.close()
		if self.verbose == "True":
			print("\r\x0A")
		return True

	def alert_receiverest(self:object, buffer:int):
		data = b""
		try:
			while (True):
				data += self.sock.recv(buffer)
		except Exception as e:
			print("Stopped receiving data. Reason>> %s"%(e))
		return data


	def receivePacket(self:object, buffer=None, is_only=True) -> (object, int):
		if buffer == None:
			buffer = int(self.instance.ioc["receive_buffer"])
		try:	
			recv = self.sock.recv(buffer)
			if recv == b"big_amount":
				recv = self.alert_receiverest(buffer)
			if recv == b"get_buffer" and is_only == True:
				self.sendPacket(bytes(str(buffer), "utf-8"))
				recv = b"warning: successfully send buffer TO server"
		except Exception as e:
			print("[operation.establishConn] Could not download the rest of the data! Reason>> %s "%(e))
			return False
		return recv
	