def httpPrepare(*args) -> (list):
	host, method, path, cookie__ = args[0], args[1], args[2], args[3]
	if len(cookie__) == 0:
		cookie__ = None
	first_part = "%s %s HTTP/1.1\r\x0AHost: %s\r\x0AConnection: close\r\x0AUser-Agent: FSRV/wgetinst/v1.0\r\x0AAccept: */*\r\x0AAccept-Encoding: */*\r\x0ACookie: %s\r\x0A\r\x0A"%(method, path,host.split("/")[0], cookie__)
	return first_part