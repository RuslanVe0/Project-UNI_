from os import chdir

class load_file(object):

	def __init__(self:object):
		load = [bob.split(" ")[0].strip() for bob in [bob for bob in open(self.umr+"/"+self.default_config, "r", encoding="utf-8")] if bob.split(" ")[0] != "#" or "#" not in bob.split(" ")[0]]
		dictI = {}
		for items in load:
			if len(items) == 0 or "#" in items:
				continue
			var, val = items.split("=")
			dictI[var] = val
		for items in dictI:
			dictI[items] = dictI[items].replace('"', "")
		dictI["port"] = int(dictI["port"])
		self.ioc = dictI