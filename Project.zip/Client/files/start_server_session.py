# To create a session between the client and server.
from uuid import uuid4
from Cryptodome.Cipher import AES
from base64 import b64encode, b64decode
from json import loads

class start_server_session(object):
	def __init__(self:object, socket_module, instance:object, printoff=None) -> (object, None, object):
		self.instance=instance; self.socket_module = socket_module; self.printoff = printoff
		self.create_the_session()

	def create_the_session(self, *args):
		try:
			xz = self.socket_module(instance=self.instance)
			xz.create_instance_socket(host=self.instance.ioc["ip_addr"], port=int(self.instance.ioc["port"]))
			self.instance.connected = True
		except Exception as e:
			print(e)
			self.instance.connected = False
			return "[operation.start_Exchange] Couldn't connect to server! Reason >> %s"%(e)
		self.instanceSock = xz.return_instance()
		self.instanceSock.sendPacket((b"!website_ui"))
		self.start_Exchange()

	def require_uuid(self:object, *args):
		self.instanceSock.sendPacket(b"uuidtok")
		token_ = self.instanceSock.receivePacket(buffer=2**14)
		if isinstance(token_, bool) == True:
			return
		return token_.decode("utf-8", errors="ignore")
		
	def receive_procedure(self:object, buffer:int):
		data = self.instanceSock.receivePacket(buffer)
		if isinstance(data, bool) == True:
			exit()
		if b"uenc_data:" in data:
			return data.split(b"uenc_data:")[1]
		return data.decode("utf-8", errors="ignore")

	def start_antibot_exchange(self:object, nonce:str) -> (object):
		"""
The server expects the client to send a proper JSON-like message, encrypted in AES-256 algorithm.
"""
		data = False
		retr = 0
		while data == False:
			if retr != 0:
				print("Retrying (%d)..."%(retr))
			print("[start_antibot_exchange.security] Receiving nonce-key...")
			message_to_encrypt = self.receive_procedure(buffer=1024) # receiving the nonce.
			print("[start_antibot_exchange.security] Nonce-key retrieved! '%d'"%(len(message_to_encrypt)))
			aes = AES.new((nonce).encode("utf-8", errors="ignore"), AES.MODE_GCM, (nonce).encode("utf-8", errors="ignore")).encrypt(message_to_encrypt.encode("utf-8", errors="ignore"))
			print("[start_antibot_exchange.security] AES-message created '%d'!"%(len(aes)))
			self.instanceSock.sendPacket(b64encode(aes)) # sending the encrypted message.
			data = self.receive_procedure(buffer=512)
			if "error:" in data:
				print("[start_antibot_exchange.security] Uh-oh, an error occured, while retrieving anti-bot-session like id...More of error: '%s'..\nRetrying.."%(data))
				retr += 1
				continue
			self.instance.antirobot_id = loads(data.split("_PARS_")[0])
		print("[start_antibot_exchange.security] Anti-robot system successfully finished!")
		print(data)
		if len(data.split("_PARS_")) > 1:
			return data.split("_PARS_")[1]
		else:
			return data.split("_PARS_")[0]


	def start_Exchange(self:object):
		try:
			self.instance.instanceSock = self.instanceSock
			self.instance.xza = self
			# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!BUFFER!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
			#self.instanceSock.receivePacket() 
			flag = self.instanceSock.receivePacket()
			if isinstance(flag, bool) == True:
				exit()
			flag = flag.decode("utf-8", errors="ignore")
			if "AntiBot-NONCE" in flag:
				xz = self.start_antibot_exchange(nonce=flag.split("AntiBot-NONCE:")[1])
				if len(xz) == 0:
					flag = self.instanceSock.receivePacket()
					if isinstance(flag, bool) == True:
						exit()
					flag = flag.decode("utf-8", errors="ignore")
				else:
					flag = xz
			xz = [bob for bob in flag.split("\x0A") if "Fingerprint" in bob]
			if len(xz) != 0 and xz[0].split(":")[1].strip() == "'True'":
				self.instance.fingerprint = (self.instanceSock.receivePacket()).decode("utf-8", errors="ignore")
				self.instanceSock.sendPacket(("FING_::%s"%(self.instance.get_device_data(uuid=self.instance.fingerprint.split("RequestID::")[1].strip()))).encode("utf-8", errors="ignore"))
			else:
				self.instance.fingerprint = None
			self.instanceSock.receivePacket() 
			self.instance.uuid_client = self.require_uuid()
			if self.printoff != False:
				print("%s\x0AConnection-uuid: %s"%(flag, self.instance.uuid_client))
			self.instanceSock.sendPacket(b"req.info_menu")	
			info_menu = self.instanceSock.receivePacket().decode("utf-8", errors="ignore") + "\r\x0A"
			if self.printoff != False:
				print(info_menu)
			if self.instance.fingerprint != None:
				print("Server information>>\x0A\x0A" + self.instance.fingerprint)
			self.instance.info_menu = info_menu
			#self.automatic_authorization()
		except Exception as e:
			print(e)
			self.instance.connected = False
			return "[operation.start_Exchange] Server stopped connection! Reason>> %s"%(e)

	def decode_commands(self:object, command:bytes) -> (bytes):
		command = command.decode("utf-8", errors="ignore")
		xz = {"error::mpkt":"Error: message too long!", "error::ntfcmd":"Error: command not found!"}
		if command.strip() in xz:
			return xz[command.strip()]
		return command