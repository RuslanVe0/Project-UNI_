from functools import partial
from docs.gui.resolution_based_cmd.rbc import resolution
from docs.gui.resolution_based_cmd.connectivity_changes import connectivity
class commands(object):
	
	def __init__(self, *args):
		assert args != []
		self.inst1, self.inst2, self.navbar, self.other_self = args
		self.conn = connectivity(self.inst1, self.inst2, self, self.other_self)

	def change_geometry(self:object):
		"""
		This method is specifically to configure resolution settings.
		"""
		self.inst2.remove_all() # remove all.
		self.navbar.navbar(self.inst2.master, self.inst2, self.inst2.instance_obj)
		self.inst2.create_text(text="Change geometry", font=("Arial", 30))
		self.inst2.create_text(text="Current resolution %sx%s"%(self.inst2.resol[0], self.inst2.resol[1]), font=("Arial", 30)) # to display the current resolution setting.
		resols = self.find_resolution_values() # to smallest ones. Sorted in a list.
		for based in resols:
			self.inst2.create_button(text="%s"%(based), font=("Arial", 16), height=1, command=partial(resolution(self.inst1, self.inst2, self, self.other_self).change_geometry, based), bg="cyan")
		self.inst2.create_button(text="Main menu", command=self.other_self.options, font=("Arial", 12), height=2, width=16)

	def change_connectivity(self:object) ->(object):
		self.inst2.remove_all()
		self.navbar.navbar(self.inst2.master, self.inst2, self.inst2.instance_obj)
		self.inst2.create_text(text="Change connectivity settings", font=("Arial", 22))
		self.inst2.create_button(text="Receive buffer", command=self.conn.buffer_change, font=("Arial", 12), height=2, bg="white", width=40)
		self.inst2.create_button(text="Main menu", command=self.other_self.options, font=("Arial", 12), height=2, width=16)

	def find_resolution_values(self:object) -> object:
		resolutions = self.inst2.create_numpy_array(size=7)
		fixedw, fixedh = self.inst2.master.winfo_screenwidth(), self.inst2.master.winfo_screenheight()
		for times in range(0, 8, 1):
			if fixedw <= 100 or fixedh <= 100:
				break
			resolutions[times] = "%sx%s"%(fixedw, fixedh) # widthxheight.
			fixedw,fixedh = fixedw//2, fixedh//2
		return [element for element in resolutions if element != Ellipsis]
	
	def toggle_fullscreen(self:object) -> (object):
		self.inst2.fullscreen = True if self.inst2.fullscreen == False else False
		self.inst2.master.attributes("-fullscreen", True if self.inst2.fullscreen == True else False)