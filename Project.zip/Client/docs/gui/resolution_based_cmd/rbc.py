from typing import Union, Type
# this class is related to - client-based commands
# .

class resolution(object):

    def __init__(self:object, instanceofclass:object, instanceofclass2:object, instanceofclass3:object, otherself:object):
        self.instanceofclass = instanceofclass; self.instanceofclass2=instanceofclass2; self.instanceofclass3 = instanceofclass3; self.otherself=otherself
    
    def change_geometry(self:object, geometry:Type[tuple]=()):
        self.instanceofclass2.resol = (int(geometry.split("x")[0]), int(geometry.split("x")[1]))
        self.instanceofclass2.create_tk_instance()
        self.instanceofclass3.change_geometry()
    
    