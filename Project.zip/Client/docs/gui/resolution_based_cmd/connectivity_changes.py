from functools import partial
from typing import Type, Union
from tkinter import messagebox, simpledialog

class connectivity(object):
    def __init__(self:object, instanceofclass:object, instanceofclass2:object, instanceofclass3:object, otherself:object):
        # instanceofclass - button_like class, instanceofclass2 - gui.
        self.instanceofclass = instanceofclass; self.instanceofclass2 = instanceofclass2; self.instanceofclass3=instanceofclass3; self.otherself = otherself
    
    def buffer_change(self:object):
        self.change_buff(simpledialog.askinteger("Buffer change", "Enter buffer: "))
    
    def change_buff(self:object, arg:int) -> (object):
        # change buffer setting.
        if arg == None:
            messagebox.showerror("Error", "'None' cannot be set as a value!")
            return
        if arg == 0 or arg > pow(2, 22):
            messagebox.showerror("Error", "Invalid provided value!")
            return
        old_value = self.instanceofclass.ioc["receive_buffer"]
        self.instanceofclass.ioc["receive_buffer"] = arg
        messagebox.showinfo("Operation based", "Operation completed! Old value '%s' -> '%s'"%(old_value, arg))