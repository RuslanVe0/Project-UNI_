# the navigation bar is a bar that purpose is to navigate in a specific direction where the user can use it. Which should be maximum user-friendly

from tkinter import Frame, Label, Y, X
from math import sqrt

class navbar(object):

	def __init__(self:object, master:object, self_inst:object, self_inst_inst:object, side="left") -> (object):

		# if the instance of related_ != True, thus it'll raise an 'AssertationError' because the value isn't correct or the length of the tuple IS fewer than 1 (is = 0).

		#assert isinstance(related_, tuple) != True or len(related_) != 0

		"""
		'related_' argument is related to widgets that will be added later in the navigation bar, they might include - label, button, radio buttons, label images
		and etcetera
		argument 'side' default value is - "left", because the main purpose was to be on the 'left' side.
		"""

		self.master = master; self.sinst = self_inst; self.sinst_inst = self_inst_inst; self.side = side
		self.build_navigation_structure()
   
	def build_navigation_structure(self:object, *args) -> (object):
		width, height = self.find_resolution()
		scr_width = sqrt(width)/1.5
		master = self.fill_area(scr_width) # fill the 'side' in grey color.
		self.create_items_onbar(master)
		self.sinst.created.append(master)

	def create_items_onbar(self:object, master:object):
		self.sinst.create_button(text="User", font=("Arial", 12),nroot=master, bg="orange", command=self.sinst.button_like.user, height=1, width=20)
		#self.sinst.create_canvas_hr(width=256, height=64, bg="orange", color="black", nmaster=master)
		if self.sinst_inst.connected == True:
			arg, cmd = "Disconnect", self.sinst.button_like.disconnect
			self.sinst.create_button(text="Server info", font=("Arial", 12), nroot=master, bg="orange", command=self.sinst.button_like.server_info, height=1, width=20)
		else:
			arg, cmd = "Connect", self.sinst.button_like.connect_button
		self.sinst.create_button(text=arg, font=("Arial", 12), nroot=master, bg="orange", command=cmd, height=1, width=20)
		self.sinst.create_button(text="Local Environment", font=("Arial", 12), nroot=master, bg="orange", command=self.sinst.button_like.localEnv, height=1, width=20)
		self.sinst.create_button(text="Options", font=("Arial", 12), nroot=master, bg="orange", command=self.sinst.button_like.options, height=1, width=20)
		self.sinst.create_button(text="Main Menu", font=("Arial", 12), nroot=master, bg="orange", command=self.sinst.build, height=1, width=20)
		self.sinst.create_button(text="Exit", font=("Arial", 12), nroot=master, bg="orange", command=self.sinst.on_close_instance, height=1, width=20)
		pass

	def fill_area(self:object, screen_width:int) -> (object):
		# the width will be set to 
		label = Label(self.master, background="orange", width=int(screen_width))
		label.pack(side=self.side, fill=Y)
		self.sinst.create_text(text="Navigation bar", font=("Arial", 22), color="cyan", anchor="w", nroot=label, background="orange")
		self.sinst.create_canvas_hr(width=128, height=64, bg="orange", color="black", nmaster=label)
		return label

	def find_resolution(self:object, *args):
		return (self.master.winfo_screenwidth(), self.master.winfo_screenheight())