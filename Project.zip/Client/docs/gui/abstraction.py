# this file is important for GUI envoirnment.

import tkinter as tk
from tkinter import messagebox, Canvas, RIGHT, LEFT, Y, X, Frame, Toplevel, PhotoImage	
from sys import stdout
import tkinter.font as tkFont
from PIL import ImageTk, Image
from os.path import exists
from asyncio import run, sleep as as_sleep
from threading import Thread, Event
from docs.gui.custom import buttons_, navbar
from functools import partial
from docs.gui import commands
from typing import Type, Union
from numpy import array

class gui(Frame):
	# this is the base gui.
	def __init__(self, instance_of_class:object, verbosity=False):
		self.master = tk.Tk()
		self.fullscreen = False
		self.verbosity = verbosity; self.instance_obj = instance_of_class; self.created = []; self.tm = False; self.top_window_ = False; super().__init__(self.master)
		self.resol = self.master.winfo_screenwidth(), self.master.winfo_screenheight()
		self.button_like = button_like_class(self.instance_obj, self) # instantiation of 'button_like' class.
		self.create_tk_instance() # create 'App' menu in a top level instance.

	def create_textbox(self:object, font:Type[tuple]=(), height:Type[int]=0):
		textbox = tk.Text(self.master,height=height, font=font)
		textbox.pack()
		self.created.append(textbox)

	def create_entry_box(self:object, text:str, width:int, button_text:str, command:object, title:str, args:tuple):
		entr = Entry(text, title=title)
		entr.pack()
		self.create_button(text=button_text, font=("Arial",12), command=partial(command, args))

	def create_text(self:object, text:str, font:tuple, pady:Type[int]=16, padx:Type[int]=16, side:Type[str]="top", color:Type[str]="black", anchor:Type[str]="n", append_:Type[bool]=True, nroot=None, background:Type[str]="white") -> (str, tuple):
		straight = [text, font, pady, padx, side, anchor, color]
		self.ConsoleOutput_onVerbosity(text="[operation.button_like_class.connection] Creating text with paramters %s.."%(straight))
		master = nroot if nroot != None else self.master
		label = tk.Label(master, text=text, font=font, fg=color, background=background)
		label.pack(pady=pady, padx=padx, side=side, anchor=anchor)
		if append_ == True:
			self.created.append([label, text])
		return label

	def create_option_menu(self:object, tearoff:Type[int]=0, label_text:Type[str]="Options"):
		m1, navbar = self.create_navbar(tearoff=0, label=label_text)

	def create_canvas_hr(self:object, width:int, height:int, bg:str, color:str, nmaster=None, side:Type[str]="top") -> (int, int, str):
		master = nmaster if nmaster != None else self.master
		canvas = Canvas(master, width=width, height=height, bg=bg, highlightbackground=bg)
		canvas.create_line(0, 50, 128, 50, fill=color, tags="line")
		canvas.pack(side=side)
		self.created.append(canvas)

	def run(self:object):
		self.ConsoleOutput_onVerbosity(text="[operation.button_like_class.connection] Starting root..")
		self.master.bind("<Escape>", self.on_close_instance)
		self.master.bind("<F1>", self.button_like.connect_button)


	def create_button(self:object, font:tuple,command:object, pad:Type[tuple]=(16, 16), height:Type[int]=30, bg:Type[str]="white", text:Type[str]="", side:Type[str]="top", returnbutton:Type[bool]=False, width:Type[int]=30,cursor:Type[str]="hand2", opacity:Type[int]=1, nroot=None, image:Type[str]="", pack:Type[bool]=True):		# this method of the 'gui' class is specifically to create buttons, by giving specific values to the function. That method is used constantly when creating buttons.
		#assert isinstance(height, int) == False
		straight = [text, font, command, pad, height, bg, side]
		self.ConsoleOutput_onVerbosity(text="[operation.button_like_class.connection] Creating button with paramters %s.."%(straight))
		padx,pady = pad
		master = nroot if nroot != None else self.master
		if image != "":
			img = self.open_image(img=image)
			button = tk.Button(master, command=command, cursor=cursor, image=img, background="white", borderwidth=0, relief=tk.FLAT, bd=0, width=width, height=height)
			button.image = img
		else:
			button = tk.Button(master, text=text, font=font, height=height, command=command, bg=bg, cursor=cursor, activebackground="dark blue", activeforeground="cyan", borderwidth=2, width=width)
		if pack == True and image == "":
			button.pack(padx=padx, pady=pady, side=side)
		elif pack == True and image != "":
			button.pack(side=side, fill="both", expand=True)
		self.created.append([button, text])
		return button

	def open_image(self:object, img:str) -> (str):
		xz = Image.open(img)
		pht = ImageTk.PhotoImage(xz.resize((410, 100)), master=self.master)
		#photoimage = pht.subsample(3, 3)
		return pht


	@classmethod
	def self_re(cls:object):
		return cls

	def build(self:object):
		self.remove_all()
		navbar.navbar(self.master, self, self.instance_obj)
		self.put_image(img=self.instance_obj.ioc["img1"], side="top")
		self.create_text(text="File Transfer Server - Client", font=("Arial", 20))
		if self.instance_obj.connected == True:
			self.create_button(text="Menu (connectivity)", font=("Arial", 16), height=1, command=self.button_like.toOtherMenuSwitcher, bg="cyan")
			self.create_button(text="Disconnect", font=("Arial", 16), height=1, command=self.button_like.disconnect, bg="cyan")
		else:
			self.create_button(text="Connect", font=("Arial", 0), height=0, command=self.button_like.connect_button, bg="cyan", image=self.instance_obj.ioc["btnimg"], width=0)
			self.create_button(text="Local Envorinment", font=("Arial", 0), height=0, command=self.button_like.localEnv, bg="cyan", image=self.instance_obj.ioc["btnimg1"], width=0)
		#self.create_text(text="Connected: %r"%(self.instance_obj.connected), font=("Arial", 16), color="red", side="top", anchor="se", side="bottom")
		if self.tm == False:
			self.create_text(text="Copyleft sipistoverdi™", font=("Arial", 16), color="darkblue", side="bottom", append_=False, anchor="s")
			self.tm = True

	def exist_obj(self:object, tosearch:str) -> (object, str):
		for items in self.created:
			if isinstance(items, list) == True and items[1] == tosearch:
				return True
		return False

	def return_obj(self:object, search:str) -> (object):
		try:
			return self.created.index(search)
		except ValueError:
			return [None, "not found"]

	def ConsoleOutput_onVerbosity(self:object, text:str):
		if self.verbosity == True:
			stdout.write("\r%s"%(text)+"\r\x0A\r\x0A")
		return

	def configure_font(self:object, object:object, underline:bool) -> (object):
		font = tkFont.Font(object, object.cget("font")).configure(underline=underline)
		object.configure(font=font)

	def restart(self):
		self.remove_all()
		self.button_like.disconnect(True)

	def create_navbar(self:object, tearoff=0, label="", *args) -> (object):
		menubar = tk.Menu(self.master)
		navbar = tk.Menu(menubar, tearoff=tearoff)
		menubar.add_cascade(menu=navbar, label=label)
		return (menubar, navbar)

	def create_tk_instance(self:object, name_label:Type[str]="App"):
		self.remove_all()
		m1, navbar = self.create_navbar(tearoff=0, label=name_label)
		self.ConsoleOutput_onVerbosity(text="[operation.button_like_class.connection] Creating basic instance..")
		self.master.geometry("%sx%s"%(self.resol))
		self.ConsoleOutput_onVerbosity(text="[operation.button_like_class.connection] Setting resolution that corresponds to 'config.ini' file as value '%s'.."%(self.instance_obj.ioc["resol"]))
		self.master.title("File Transfer Server GUI - Client")
		self.master.protocol("WM_DELETE_WINDOW", self.on_close_instance)
		self.master.iconbitmap(self.instance_obj.ioc["ico"])
		self.ConsoleOutput_onVerbosity(text="[operation.button_like_class.connection] Setting Iconbitmap value that corresponds to 'config.ini' file as value '%s''.."%(self.instance_obj.ioc["ico"]))
		navbar.add_command(label="Main menu", command=self.build)
		navbar.add_command(label="Refresh", command=self.build)
		navbar.add_command(label="Options", command=self.button_like.options)
		navbar.add_command(label="Restart", command=self.restart)
		navbar.add_command(label="Rebuild", command=self.build)
		navbar.add_command(label="Top window", command=self.top_window)
		navbar.add_command(label="Close", command=self.on_close_instance)
		self.master.config(menu=m1)
		self.ConsoleOutput_onVerbosity(text="[operation.button_like_class.connection] All properties to root instance added!..")

	def create_window(self:object, title:str, geometry:str, label_text:str) -> (str, str, str):
		new = Toplevel(self.master)
		new.title(title)
		new.geometry(geometry)
		lab = tk.Label(new, text=label_text).pack()
		self.created.append(lab)
		return new

	def top_window(self:object):
		fas = True if self.top_window_ == False else False
		self.master.attributes("-topmost", fas)
		self.top_window_ = fas
		self.ConsoleOutput_onVerbosity(text="[operation.top_window] top_window='%r'"%(self.top_window_))

	def put_image(self:object, img:str, side:str, width=(230, 200)) -> (str):
		if exists(img) == False:
			messagebox.showerror(title="[operation.put_image] Image not found! Skipping..")
			return
		xz = Image.open(img)
		rx = ImageTk.PhotoImage(xz.resize(width), master=self.master)
		label = tk.Label(self.master, image=rx)
		label.image = rx
		label.pack(side=side, fill="both", expand="yes")
		self.created.append([label, img])

	def remove_all(self:object):
		# this is somewhat straightforward.
		for index, items in enumerate(self.created, 0):
			if items != None:
				if isinstance(items, list) == True:
					items = items[0]
				items.destroy()
			else:
				del self.created[index]

	def on_close_instance(self:object, *args): self.master.destroy() if messagebox.askyesno(title="Quit",  message="Do you really want to close that application?") == True else None


	def scroll_bar(self:object):
		scr = tk.Scrollbar()
		scr.pack(side=RIGHT, fill=Y)
		self.created.append(scr)
	
	def create_numpy_array(self:object, size:Type[int]=4):
		sort = array([Ellipsis for io in range(0, size+1, 1)])
		return sort

class button_like_class(object):
	"""
This class contains ALL button-like command methods.
"""
	def __init__(self:object, instance:object, gui_instance:object) -> (object):
		self.cmd = commands.commands(instance, gui_instance, navbar, self)
		self.inst = instance; self.gui_instance = gui_instance

	def connect_button(self:object, *args):
		self.host = self.inst.ioc["ip_addr"]
		self.gui_instance.ConsoleOutput_onVerbosity(text="[operation.button_like_class.connecion] Preparing to connect to server (%s).."%(self.host))
		if messagebox.askyesno(title="[operation.connect_button]", message="Are you sure you want to connect to: '%s'"%(self.host)) == False:
			self.gui_instance.ConsoleOutput_onVerbosity(text="[operation.button_like_class.connection] User has cancelled operation ..")
			return
		inherited_object = self.inst.conn_server(False)
		if isinstance(inherited_object, str) == True and (inherited_object.startswith("ERR:") == True or "[ERR]::" in inherited_object):
			self.gui_instance.ConsoleOutput_onVerbosity(text="[operation.button_like_class.connecion] [ERR::] Connection has failed to server (%s).."%(self.host))
			messagebox.showerror(title="[operation.connection]", message=inherited_object)
			return
		messagebox.showinfo(title="[operation.connection]", message=inherited_object)
		self.gui_instance.ConsoleOutput_onVerbosity(text="[operation.button_like_class.connection] [INFO::] Removing ALL previous created objects (Total:: '%d')... "%(len(self.gui_instance.created)))
		self.gui_instance.remove_all()
		self.create_menu()

	def disconnect(self:object, *args):
		force = args[0] if len(args) != 0 else None
		if force == None and (messagebox.askyesno(title="[operation.disconnect]", message="Are you sure that you want to disconnect from remote server")) != True:
			return
		if self.inst.connected == True:
			messagebox.showinfo(title="[operation.disconnect]", message="Disconnected from server...")
			self.inst.disconnect()
		self.gui_instance.remove_all()
		self.gui_instance.build()

	def user(self:object):
		pass

	def create_menu(self:object) -> (object):
		self.gui_instance.remove_all()
		navbar.navbar(self.gui_instance.master, self.gui_instance, self.gui_instance.instance_obj)
		self.gui_instance.put_image(img="C:/Users/Ruslan/Desktop/FileTransferSrv/Client/docs/gui/images/data-transfer.png", side="top")
		self.gui_instance.create_text(text="File Transfer Server - Client", font=("Arial", 16), anchor="n")
		label = self.gui_instance.create_text(text="Envoirnment", font=("Arial", 16), anchor="center")
		self.gui_instance.configure_font(object=label, underline=True)
		self.gui_instance.create_button(text="Local Envorinment", font=("Arial", 16), height=30, command=self.localEnv, bg="cyan", image=self.inst.ioc["btnimg1"])
		self.gui_instance.create_button(text="Remote Envorinment", font=("Arial", 16), height=1, command=self.remoteEnv, bg="cyan")
		self.gui_instance.create_button(text="Back to main menu", font=("Arial", 16), command=self.gui_instance.build, bg="cyan", height=1)
		self.gui_instance.scroll_bar()

	def server_info(self:object) -> (object):
		instance = self.gui_instance.create_window(title="| Server information |", geometry="640x768", label_text=self.inst.info_menu)
		btn = self.gui_instance.create_button(text="Close", font=("Ariel", 12), command=instance.destroy, nroot=instance, height=1, width=6, bg="cyan")

	def options(self:object):
		self.gui_instance.remove_all()
		navbar.navbar(self.gui_instance.master, self.gui_instance, self.gui_instance.instance_obj)
		self.gui_instance.create_text(text="Options", font=("Arial", 35), anchor="center")
		#self.gui_instance.create_canvas_hr(width=256, height=64, bg="white", color="black", nmaster=self.gui_instance.master, side="top")
		self.gui_instance.create_button(text="Change resolution", font=("Arial", 16), height=0, width=20, command=self.cmd.change_geometry)
		self.gui_instance.create_button(text="Toggle fullscreen", font=("Arial", 16), height=0, width=20, command=self.cmd.toggle_fullscreen)
		self.gui_instance.create_button(text="Change connectivity options", font=("Arial", 17), height=0, width=21, command=self.cmd.change_connectivity)
		self.gui_instance.create_button(text="Back", font=("Arial", 16), height=0, width=20, command=self.gui_instance.build)

	def server_related(self:object):
		pass

	def localEnv(self:object):
		pass

	def toOtherMenuSwitcher(self:object):
		self.create_menu()

	def remoteEnv(self:object):
		pass





