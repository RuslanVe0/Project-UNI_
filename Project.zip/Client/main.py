from files.loads import *
from files.env import runnogui
from files.socket_ import Socket
import mysql.connector
from files.lfinst import lfinst
from files.httpPrepare import httpPrepare
from files.env import rungui
from sys import stdout
#
from socket import gethostbyname, gethostname
#
from os import system as os_system, listdir, getcwd, chdir
#
from datetime import datetime, date
#
from files.start_server_session import start_server_session
#
import os

from os.path import exists, isfile, getsize

from threading import Thread

from platform import platform,system,machine, architecture

from math import sqrt

from files.login_env import login_env

from sys import stdout

from typing import Type, Union 

from itertools import cycle
"""
This client is official release, AND it'll be used for the default client of that file transfer server.
Also the client will be updated over the time, since it requires - improvement and development, which will take a long time.


"""
class startFTSrv(load_file, runnogui, lfinst, Socket):
	rl = lambda x : x*20
	def __init__(self:object, default_config:Type[str] = "config.ini", verbose:Type[bool] = False, gui=None, default=getcwd()) -> (object):
		self.login_env = login_env
		self.default_config = default_config; self.verbose = verbose; self.httpPrepare = httpPrepare; self.umr = default; self.bell = False; self.Session = start_server_session; self.instanceSock = None; self.xza = None; self.lbis = True; self.connected = False; self.userToken = None
		load_file.__init__(self)
		self.gui = self.ioc["env"]
		self.output(targetString=startFTSrv.rl("\x2D") + "\x0A\x0AFTRs client v1.0\x0A\x0A>>>>\x0A", clear=False)
		self.attr = [load_file, runnogui]
		if self.ioc["startdir"] == "current":
			self.pathr = getcwd()
		else:
			self.pathr = self.ioc["startdir"]
			if exists(self.pathr) == True:
				chdir(self.pathr)
		self.chooseEnv()

	def sendConReq(self:object, *args):
		if self.instanceSock == None:
			return False
		try:
			self.instanceSock.sendPacket(packet=b"test.connection")
			rcv = self.instanceSock.receivePacket()
		except:
			return False
		return True

	def trigger(self:object, *args):
		self.lbis = True if self.lbis == False else False
		return "[operation.trigger] Local based - %r"%(self.lbis)

	def triggerBell(self:object) -> (object):
		caser = {True:False, False:True}
		if self.bell not in caser:
			return "[operation.triggerBell] Operation failed! Reason >> Incorrect value passed."
		self.bell = caser[self.bell]
		return "[operation.triggerBell] Bell => %s"%({True:"on", False:"off"}[self.bell])

	def makeSoundEffect(self:object, func:object, melody:str) -> (object, object, str):
		caser = {"bell":([1500, 1200, 1500], 100)}
		if melody not in caser:
			return "[operation.makeSoundEffect] Unknown melody passed.."
		var = caser[melody]
		sang = [func(freq, var[1]) for freq in var[0]]
		return

	def disconnect(self:object):
		if not "instanceSock" in dir(self) or self.connected == False:
			return "[operation.disconnect] No alive connection located!"
		self.instanceSock.sock.close()
		self.connected = False
		return "[operation.disconnect] Successfully disconnected from the remote server!"

	def conn_server(self:object, *args):
		if self.connected == True:
			return "[operation.conn_server] Couldn't connect. [ERR]:: Alive connection already exists!"
		self.Session(instance=self, socket_module=Socket, printoff=False if self.gui == "True" or self.gui == True else True)
		if self.connected == True:
			return "Connection successful!"
		return "ERR:[operation.conn_server] Uh-oh, couldn't connect to server ..."


	def wgetinst(self:object):
		try:
			lfinst.__init__(self, Socket(verbose=bool(self.ioc["socketVerb"], instance=self)))
		except Exception as e:
			return "[operation.wgetinst] Operation failed! Reason >> %s"%(e)
		return "[operation.lfinst] Operation completed!"

	def chooseEnv(self:object):
		if self.gui == "gui":
			rungui.__init__(self, )
		else:
			runnogui.__init__(self, )

	def checkdiff(self, *args):
		arg0, arg1 = args
		if arg0 > arg1:
			return True
		elif arg0 < arg1:
			return False
		else:
			return "equal"

	def find_max_list(self:object, target:Union[tuple, list]):
		max_n = []
		for values in target:
			if len(max_n) == 1 and max_n[0] < values:
				max_n[0] = values
				continue
			max_n.append(values)
		return max_n[0]

	def biggestF(self:object) -> (object):
		enmFiles = [self.openReadFile(bob)/1000000 for bob in listdir() if isfile(bob) == True]
		avg, findmax = sum(enmFiles)/len(enmFiles), self.find_max_list(target=enmFiles)
		return startFTSrv.rl("\x2D") + "\r\x0A" + "(path -> %s)\x0A\x0AAvg: %d-mb\x0AMax: %d-mb\r\x0A\r\x0A"%(getcwd(), avg, findmax)

	def dbtf(self:object, *args):
		print(self.enumCWD())
		fil = input("Enter two files, seperated by commas (e.g file_1.txt,file_2.txt)>> ")
		if "," not in fil or len(fil.split(",")) <= 1 or (len(fil.split(","))%2) == 1:
			return "[operation.dbtf] Operation failed! Reason>> Two files seperated by commas! Or it should be even."
		fil = fil.split(",")
		difference = []
		for index, files in enumerate(fil, 0):
			if index+1 > len(fil)-1:
				continue
			if exists(fil[index].strip()) == True and exists(fil[index+1].strip()) == True:
				fir, sec = getsize(fil[index].strip()), getsize(fil[index+1].strip())
				difference.append({True:"'%s' file is bigger than '%s'"%(fil[index], fil[index+1]), 
				False:"'%s' file is smaller than '%s'"%(fil[index], fil[index+1]), 
				"equal":"'%s' file is equivalent to '%s'"%(fil[index], fil[index+1])}[self.checkdiff(fir, sec)])
				continue
			return "[operation.dbtf] Operation failed! Reason>> Passed a file that does not exist!"
		return ("\x0A".join(element for element in difference))

	def write_in_file(self:object, file:Type[str], contents:bytes) -> (object, str, bytes):
		assert isinstance(contents, bytes) != False
		try:
			with open(file, "wb") as write_pipe:
				write_pipe.write(contents)
			write_pipe.close()
		except Exception as failure:
			print(failure)
			return False
		return True

	def outputDesc(self:object) -> (object):
		load = "".join(bob for bob in open(self.umr+"/" + "README.md", "r"))
		return "\x0A" + ((load.split("x>")[1].split("<x")[0]).strip()) + "\r\x0A"

	def logOff(self:object, file:str, text:str) -> (object, str, str):
		if int(self.log) == 1:
			try:
				xz = open(file, "a")
			except:
				return
			xz.write(text + "\x0A")
			xz.close()
		return

	def openReadFile(self:object, file:str, ccontents:Type[bool]=False) -> (str):
		assert file != ""
		if exists(file) == False:
			raise FileNotFoundError("File not located!")
		try:
			lenx = getsize(file) # length.
			if ccontents != False:
				contents = os.read(os.open(file, os.O_RDWR | os.O_BINARY), lenx)
			else:
				contents = lenx
		except Exception as e:
			contents = ("Permission denied, %s"%(e)).encode("utf-8", errors="ignore")
		return contents
	
	def get_device_data(self:object, uuid:str):
		assert uuid != ""
		return "OS::%s,System::%s\x0AMachine:%s\x0AArchitecture:%s\x0aRequestID::%s"%(platform(), system(), machine(), ",".join(bob for bob in architecture()), uuid)

	def editIni(self:object) -> (object):
		print(self.outputiniprop())
		try:
			opt = input("Key-value (e.g. host='something'): ")
			if not "=" in opt or len(opt.split("=")) <= 1 or len(opt.split("=")) > 2:
				raise Exception("Invalid argument!")
			key, val = opt.split("=")
			if key not in self.ioc:
				raise Exception("Incorrect key inputed!")
			self.ioc[key] = val
		except Exception as reason:
			return "Operation interrupted! Reason -> %s!"%(reason)
		return "[operation.editIni] Operation succeded! Edited '%s'='%s'"%(key, val)

	def outputiniprop(self:object) -> (object):
		return ("Key" + "  "*5 + "Value\x0A" + "\x2D"*20 + "\x0A" + "\x0A".join("%s -> %s"%(bob, self.ioc[bob]) for bob in self.ioc)) +"\x0A" + "\x2D"*20 + "\x0A"

	def prevDir(self:object) -> (str):
		if len(self.prv) == 0:
			return "[operation.prevDir] Operation succeded! But no previous wd!"
		chdir(self.prv[0])
		return "[operation.prevDir] Operation succeded! Returned to - %s"%(self.prv[0])

	def enumCWD(self:object) -> (str):
		fl = lambda x: int(((sum(x)/2)/len(x))*2)-2 # anonymous function, this function is to find how much "-" should be outputed in order to be somewhat in the correct align.
		files = listdir()
		enm = ["%s"%(getcwd()+"\\%s"%(pathf)) + " "*5 + "%.2f/mb"%((getsize(getcwd()+"\\%s"%(pathf))/1000000)) for pathf in files if isfile(pathf)]
		totalsize = sum([(getsize(getcwd()+"\\%s"%(pathf))/1000000) for pathf in files if isfile(pathf)])
		abt = [len(act) for act in enm]
		length = fl(abt)
		xz = "Total size: %.2f/mb\x0AFILE"%(totalsize) + " " * length + "SIZE\x0A" + "\x2D"*(length+10) + "\x0A" + "\x0A".join(bob for bob in enm) + "\x0A\x0A"
		return xz

	def changeWD(self:object, todir:str) -> (object):
		if len(self.prv) == 1:
			self.prv.pop(0)
		self.prv.append(getcwd())
		try:
			chdir(todir)
		except Exception as e:
			return "[operation.changeWD] Operation interrupted! Reason '%s'\x0A"%(e)
		return "[operation.changeWD] Operation successful!\x0A"

	def getValueDict(self:object, *args):
		dictx, key = args
		if key not in dictx:
			return None
		return dictx[key]

	def output(self:object, targetString:str, clear=False) -> (object, str):
		if clear == True and self.verbose == True:
			os_system("cls")
		if self.verbose == True:
			print(targetString)

	def getLocalTime(self:object) -> (object):
		items = {"month":{1:"Jan", 2:"Feb", 3:"Mar", 4:"Apr", 5:"May", 6:"Jun", 7:"Jul", 8:"Aug", 9:"Sep", 10:"Oct", 11:"Nov", 12:"Dec"}, "week":{0:"Mon", 1:"Tue", 2:"Wed", 3:"Thu", 4:"Fri", 5:"Sat", 6:"Sun"}}
		year, monthn, dayn, day, hour, minute, sec = datetime.now().year, items["month"][datetime.now().month], items["week"][datetime.now().weekday()],datetime.now().day, datetime.now().hour, datetime.now().minute, datetime.now().second
		return "%d %s %d %s, %d:%d:%d"%(year, monthn, day, dayn, hour, minute, sec)

	def establishConnection(self:object) -> (object):
		pass

	def rebuild(self:object) -> (object):
		self.output("", True)
		chdir(self.pathr)
		startFTSrv(verbose=self.verbose, gui=self.gui, default=self.umr)

if __name__ == "__main__":
	startFTSrv(verbose=True, gui=False)