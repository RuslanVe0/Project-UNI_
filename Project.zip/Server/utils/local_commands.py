from utils.loads_ import *
from utils.env import *
from utils.commands import commands_Interface as commands
from utils.UserAdministration import UserProp
from utils.database import database
from utils.mitigation_strategy import mitigation_strategy
from utils.datetime_complexity_solution import solution
from server.start_threaded_server import * 
from os import getcwd
from typing import Union, Type
from functools import partial
from threading import Thread
from datetime import datetime
from string import ascii_letters
from Cryptodome.Cipher import AES
from uuid import uuid4
from utils.tools import tools
from hashlib import sha256, sha512, md5
from os import system as os_system
from socket import SHUT_RDWR
from regex import search
from platform import platform,system,machine, architecture
from sys import stdout
from utils.userown import user_operations
from json import loads, dumps
from base64 import b64encode, b64decode
import ctypes
class local_commands(object):
	def __init__(self:object, instanceOfClass:object):
		self.instanceOfClass = instanceOfClass

	def unpack(self:object, j:dict) -> (object):
		xz = []
		for i, k in enumerate(j, 0):
			xz.append(j[k])
		return xz

	def is_base64(self:object, x:bytes) -> (object, bytes):
		try:
			b64decode(x)
		except:
			return False
		return True

	def is_json(self:object, x:str, is_bytes:bool) -> (object, bytes):
		if is_bytes == True:
			x = x.decode("utf-8")
		try:
			loads(x)
		except:
			return False
		return True

	def is_user(self:object, username:str, password:str) -> (str, str):
		xz = self.instanceOfClass.database(db="ftsrv", syntax="SELECT is_anon, is_admin FROM __db__.user_ftsrv_accounts WHERE username='%s' AND password='%s'"%(username, password))._fetch()
		assert xz != []
		if int(xz[0][0]) != 0 or int(xz[0][1]) != 0:
			return False
		return True
		
	def is_anon(self:object, username:str, password:str) -> (str, str):
		xz = self.instanceOfClass.database(db="ftsrv", syntax="SELECT is_anon FROM __db__.user_ftsrv_accounts WHERE username='%s' AND password='%s'"%(username, password))._fetch()
		assert xz != []
		if int(xz[0][0]) == 1:
			return True
		return False
 
	def userown(self:object, *args):
		if len(self.instanceOfClass.cmd.split(" ")) < 2:
			return "[operation.userown] Operation failed! Missing arguments where userown. Too few arguments provided!"
		pars = tools()
		pars.argument = self.instanceOfClass.cmd
		parsed_data = pars.parse_command()		
		if isinstance(parsed_data, str) == True:
			return parsed_data
		actual_ = {"group_admin":user_operations(self).add_user_administrator, "group_users":user_operations(self).add_user_user, "group_anon":user_operations(self).add_user_anon}
		if "/f" in parsed_data:
			# that is an option for "force" action onto the service.
			function = [(actual_[data], (parsed_data[index+1:-1], ""), True) for index, data in enumerate(parsed_data, 0) if data in ["group_admin", "group_users", "group_anon"]]
		else:
			function = [(actual_[data], parsed_data[index+1:], False) for index, data in enumerate(parsed_data,0) if data in ["group_admin", "group_users", "group_anon"]]
		if len(function) == 0:
			return "[operation.userown] Operation failed! Command does not exist?"
		func = function[0][0]
		p1, output = func(arguments=function[0][1], force=function[0][2])
		if p1:
			self.update_database_settings()
			tol = tools()
			for users in self.instanceOfClass.logged_client_sessions:
				self.unauthorize_users(tol.json_many_in_much_find(self.instanceOfClass.logged_client_sessions, self.instanceOfClass.database(db="ftsrv", syntax="SELECT account_id FROM __db__.user_ftsrv_accounts WHERE username='%s'"%(parsed_data[2]))._fetch()[0][0], "account_id"))
		return output

	def unauthorize_users(self:object, list:list) -> (list):
		tl = tools()
		for client_ids in list:
			self.instanceOfClass.logged_client_sessions[client_ids] = tl.parse_json_join(self.instanceOfClass.logged_client_sessions[client_ids], (("logged", False), ("account_id","user"), ("username","guest"), ("directory",""), ("typeacc", "System.Ftsrv/users/guest"), ("logging", False), ("anon", 0)))
			self.instanceOfClass.database(db="ftsrv", syntax="INSERT INTO __db__.logout_errors(client_id, message, datetime) VALUES ('%s','Reason>> user logout due to changes in db','%s')"%(client_ids, self.getLocalTime()))._insert()

	def parse_config(self:object, property_:str, new_value:str):
		array = [bob for bob in open(self.instanceOfClass.configFile, "r", encoding="utf-8", errors="ignore")]
		old = [(bob,index) for index, bob in enumerate(array, 0) if property_ in bob.lower()]
		if len(old) == 0:
			return []
		comment = ""
		if "#" in old[0]:
			comment = old[0].split("#")[1]
		new_ = old[0][0].split("#")[0]
		p1, p2 = new_.split("=")
		array[old[0][1]] = p1 + "=" + new_value + "#" + " " + comment
		return array

	def edit_config_file_file(self:object):
		if len(self.instanceOfClass.cmd.split(" ")) < 2:
			return "[operation.edit_config_file_file] Operation failed! Too few arguments provided!"
		if len(self.instanceOfClass.cmd.split(" ")) > 2:
			return "[operation.edit_config_file_file] Operation failed! Too much arguments provided!"
		cmd, arg = self.instanceOfClass.cmd.split(" ")
		output = {}
		config = []
		for items in arg.split(","):
			var, value = items.split("=")
			config = self.parse_config(property_=var, new_value=value)
			if config != []:
				output[var] = "Command changed!"
			else:
				output[var] = "Command may not exist!"
		if config != []:
			self.write_new_config_normalProperties(config)
		return "\x2D" * 20  + "\x0A" + "\x0A".join("%s -> %s"%(bob, output[bob]) for bob in output) + "\x0A" + "\x2D"*20 + "\x0A"

	def write_new_config_normalProperties(self:object, new:list):
		self.write_in_file(self.instanceOfClass.configFile, "\x0A".join(bob.strip() for bob in new))
		return True

	#### time complexity ####
	def check_complexity(self:object, pool:list, minutes:Type[int]=0, hour:Type[int]=0, add_hour=0, add_minute=0) -> (list):
		# time related stuff.
		"""
In order to find - fast and reliable solution, and rational approach to the problem. 
We need to divide time into smaller parts - each day consists of 24-hour, which is 12*2=24.
If time is bigger than 24, thus it should add to day += 1, each month, if not months 
that does not consists 31-days, are (15 + 15)+1 days in one year.
There are 12-months, consisting of 4-weeks, which is approximately 52-weeks per year
, and that is equivalent to 365, due to the fact  that 48-weeks in days are
(each week consists of 7-days) * 7, is approximately 365-days per year.
In order to solve that problem, and reduce its complexity, we need to find the sum of all - 


	-> months in the year,
		weeks of each months,
			days in each months.
	-> h:m:s (where h=hours, m=minutes, s=seconds) of each day (<=> i.e 24-hoursd).
		check hours,
			check minutes,
				check seconds,


We'll basically need this, the sum of weeks in a month, in order to know WHETHER to use 
next month. If current week is 3, and month consists of 
3-weeks and today is the last day of the month, thus ... if hour is >= 24, it'll
change to 0, and month + 1, thus if february it'll become march, and will do that again.
We'll start by finding current year, then we need to find if it is a leap year, thus if leap year - 366-days otherwise -> 365(-1).

		"""
		current_year = pool["year"]
		total_months = 12 # 12-months in each year.
		current_day = pool["day"] # to get current day.
		total_days = 365 if current_year % 2 == False else 366 # depends if the year is a leap year.
		total_hours_day = 24 # 24-hours (12+12)=24 <=> (12*2)=24.
		pool["hour"] = pool["hour"]+hour
		pool = solution(year=current_year, day=current_day, total_days=total_days, total_hours_day=total_hours_day, pool=pool, add_hour=add_hour, add_minute=add_minute).create_pool()
		return pool
	
	def check_Timing(self:object, stamp:dict) -> (object, dict):
		current, stamp = self.unpack(self.datetime_pool()), self.unpack(stamp)
		if current[3] > stamp[3] or current[2] > stamp[2] or current[1] > stamp[1] or current[0] > stamp[0]:
			return True
		if (stamp[0] <= current[0] and stamp[1] <= current[1] and stamp[2] <= current[2] and stamp[3] <= stamp[3]) and stamp[4] < current[4]:
			return True
		return False

	##################

	def stop_receiving_request_for_time(self:object, *args) -> (object, dict):
		"""
Manually configure an outage
		"""
		if self.binded == False:
			return "[operation.stop_receiving_request_for_time] Server is not running!"
		xz = [bob for bob in self.instanceOfClass.cmd.split(" ")]
		try:
			hour = 0 if "/th" not in xz else self.instanceOfClass.cmd.split("/th")[1]
		except:
			hour = 0
		minutes = int(self.instanceOfClass.normalProperties["srsrv_option"]) if len(self.instanceOfClass.cmd.split(" ")) < 2 or self.instanceOfClass.cmd.split(" ")[1].startswith("/") == True else self.instanceOfClass.cmd.split(" ")[1]
		if tools().is_int(minutes) == False or tool().is_int(hour) == False:
			return "[operation.stop_receiving_request_for_time] Non-integer type given!"
		hour, minutes = int(hour), int(minutes)
		if self.server_instance	== None:
			return "[operation.stop_receiving_request_for_time] Server not running.."
		if minutes > 59 or minutes < 1 or hour > 23 or hour < 0:
			return "[operation.stop_receiving_request_for_time] Only minutes are allowed, within the range (1-59) and hours within the range (0, 23)"
		pool = self.datetime_pool()
		if pool["minutes"]+minutes < 59:
			pool["minutes"] = pool["minutes"]+minutes
		else:
			pool = self.check_complexity(pool=pool, minutes=minutes)
		if pool["hour"]+hour > 23 or len(self.server_instance.srsrv) != 0:
			pool = self.check_complexity(pool=pool, minutes=minutes, hour=hour)
		else:
			pool["hour"] = pool["hour"]+hour
		if len(self.server_instance.srsrv) != 0:
			print("[operation.stop_receiving_request_for_time] Removing current time-stamp ...")
			del self.server_instance.srsrv[0]
		try:
			msg = "Warning: manual outage time for %s"%(",".join(str(pool[bob]) for bob in pool)) if "/m" not in xz else self.instanceOfClass.cmd.split("/m")[1].strip()
		except Exception as e:
			print(e)
			msg = "Warning: manual outage time for %s"%(",".join(str(pool[bob]) for bob in pool))
		self.instanceOfClass.database(db="ftsrv", syntax="INSERT INTO server_outage(outage_type, datetime, notes, level) VALUES ('%s','%s','%s', %s);"%("srsrv.outage", self.getLocalTime(), msg, 1))._insert()
		self.server_instance.srsrv.append(pool)
		self.server_instance.stop_server_connectionsSimult = True
		return "[operation.stop_receiving_request_for_time] Stopped accepting clients for %d-minutes and %d-hours!"%(minutes, hour)

	def request_IP_BlackList(self:object, client:str) -> (object):
		xz = open(self.currentWork + "/" + "cont/blacklist", "a")
		xz.write(client + "\x0A")
		xz.close()

	def write_in_file(self:object, file:str, contents:str) -> (str):
		op = open(file, "w", encoding="utf-8") # since it is write.
		op.write(contents)
		op.close()

	def datetime_pool(self:object) -> (object):
		return {"year":datetime.now().year, "month":datetime.now().month, "day":datetime.now().day, "hour":datetime.now().hour, "minutes":datetime.now().minute,
		"seconds":datetime.now().second}

	def get_system_data(self:object, client:str) -> (object):
		unique = uuid4()
		self.instanceOfClass.database(db="ftsrv", syntax="INSERT INTO __db__.request_given(client, request_id, type, datetime) VALUES ('%s', '%s', '%s', '%s');"%(client[0], unique, "fingerprint", self.getLocalTime()))._insert()
		return "OS::%s,System::%s\x0AMachine:%s\x0AArchitecture:%s\x0aRequestID::%s"%(platform(), system(), machine(), ",".join(bob for bob in architecture()), unique)

	def trigger_fingerprint(self:object, *args) -> (object, (list, tuple)):
		if self.instanceOfClass.fingerprint == False:
			self.instanceOfClass.fingerprint = True
			# It's a bit risky due to bots which crawls, and fetches informations and etcetera. Default will be set to -> "False" ('0').
			stdout.write("[operation.trigger_fingerprint] This option is a bit risky. This option is now activated upon on the user responsibility.\x0A")
		else:
			self.instanceOfClass.fingerprint = False
		return "[operation.trigger_fingerprint] Fingerprint set to '%r'"%(self.instanceOfClass.fingerprint)

	def edit_config(self:object, *args) -> (object, list):

		#that operation is temporary, and it is not editting the whole file!

		if len(self.instanceOfClass.nlw.split(" ")) < 3:
			return "[operation.edit_config] Operation failed! Too few arguments provided."
		param, value = self.instanceOfClass.nlw.split(" ")[1:]
		if param not in self.instanceOfClass.normalProperties:
			return "[operation.edit_config] Operation failed! Invalid key."
		old_val = self.instanceOfClass.normalProperties[param.strip()]
		self.instanceOfClass.normalProperties[param.strip()] = value
		return "[operation.edit_config] Operation completed! '%s' -> '%s'"%(old_val, value)

	def user_input(self:object):
		actualCommand = (input("ftsrv> "))
		if len(actualCommand) == 0:
			return False, ""
		if len(actualCommand) > int(self.instanceOfClass.normalProperties["localBuffer"]):
			stdout.write("Maximum length of command is set to be = '%d', while user inputted '%d'.\n"%(int(self.instanceOfClass.normalProperties["localBuffer"]), len(actualCommand)))
			return False, ""
		self.nlw = actualCommand
		return True, actualCommand.strip().lower()

	def update_database_settings(self:object):

		def in_check(elm:str, props:dict, account_ids:str) -> (str, dict, str):
			if elm in ["createDir"]:
				bool_edit(elm, bool(props[items]), account_ids)
			else:
				self.instanceOfClass.database(db="ftsrv", syntax="UPDATE __db__.account_rules SET %s='%s' WHERE account_id='%s'"%(elm, props[items], account_ids))._insert()

		def bool_edit(elm:str, value:bool, account_ids:str) -> (str, bool, str):
			self.instanceOfClass.database(db="ftsrv", syntax="UPDATE __db__.account_rules SET %s=%r WHERE account_id='%s'"%(elm, value, account_ids))._insert()

		enum = self.instanceOfClass.database(db="ftsrv", syntax="SELECT account_id, is_anon, active, is_admin, active_admin FROM user_ftsrv_accounts")._fetch()
		is_anon, anon_props, account_props, admin_props, is_admin = self.instanceOfClass.normalProperties["anon"], self.instanceOfClass.anonProperties, self.instanceOfClass.account_rules, self.instanceOfClass.adminProp, self.instanceOfClass.normalProperties["adminAccount"]
		xz = {"uploadFiles":"append_files", "startdir":"start_directory", "movedir":"movdir", "browseDirs":"browse_files", "removeFiles":"remove_files", "OneClientPerSess":"account_usage_per_clients", "fixeddir":"fixeddir", "createDir":"createDir", "forbiddenDir":"forbiddenDirs"}
		for account_ids, anon, active, admin, active_admin in enum:
			if anon == 1 and is_anon == "True" and active == 1:
				for items in anon_props:
					if items not in xz:
						continue
					elm = xz[items]
					self.instanceOfClass.database(db="ftsrv", syntax="UPDATE __db__.account_rules SET %s='%s' WHERE account_id='%s'"%(elm, anon_props[items], account_ids))._insert()
			elif anon == 1 and is_anon == "False":
				self.instanceOfClass.database(db="ftsrv", syntax="UPDATE __db__.user_ftsrv_accounts SET active=0 WHERE account_id='%s'"%(account_ids))._insert()
			elif active == 0 and anon == 1:
				self.instanceOfClass.database(db="ftsrv", syntax="UPDATE __db__.user_ftsrv_accounts SET active=1 WHERE account_id='%s'"%(account_ids))._insert()
			elif is_admin == "True" and admin == 1 and active_admin == 0:
				self.instanceOfClass.database(db="ftsrv", syntax="UPDATE __db__.user_ftsrv_accounts SET active_admin=1 WHERE account_id='%s'"%(account_ids))._insert()
			elif is_admin == "False" and admin == 1 and (active_admin == 1 or active_admin == None):
				self.instanceOfClass.database(db="ftsrv", syntax="UPDATE __db__.user_ftsrv_accounts SET active_admin=0 WHERE account_id='%s'"%(account_ids))._insert()
			else:
				for items in account_props:
					if items not in xz:
						continue
					elm = xz[items]
					if anon == 1:
						in_check(elm, anon_props, account_ids)
					elif admin == 1:
						in_check(elm, admin_props, account_ids)
					else:
						in_check(elm, account_props, account_ids)
		print("[operation.reset_database_settings] Operation completed!")
		return

	def update_config_file(self:object) -> (object):
		loadFile.__init__(self)
		camd = self.instanceOfClass.cmd.split(" ")
		if "/f" in camd:
			self.update_database_settings()
		else:
			r = self.update_database_settings() if input("Do you want to edit database -> account settings (y/n): ").strip() == "y" else None
		return "[operation.reset_config_file] Reset completed!"

	def locate_uuid_session_token(self:object, *args):
		return self.instanceOfClass.database(db="ftsrv", syntax="SELECT session_id FROM connections WHERE client='%s' AND port='%d'"%(args[0][0], args[0][1]))._fetch()

	def clear_screen(self:object):
		os_system("cls")
		return ""

	def stream_big_File(self:object, file:str, chunk_size=1024) -> (str, int):
		repeat = 0
		with open(file, "rb") as reax:
			while True:
				chunk = reax.read(chunk_size)
				if not chunk:
					repeat += 1
				yield chunk

	def exist_username(self:object, username:str) -> (object, str):
		fetc = self.instanceOfClass.database(db="ftsrv", syntax="SELECT username FROM user_ftsrv_accounts WHERE username='%s'"%(username))._fetch()
		if len(fetc) != 0:
			return True
		return False

	def account_existence(self:object, account:[tuple], encrypted=False) -> (object, str):
		usr, pass_ = account
		if encrypted == False:
			pass_ = self.encrypt_pass(username=usr, password=pass_)
		if len(self.instanceOfClass.database(db="ftsrv", syntax="SELECT * FROM __db__.user_ftsrv_accounts WHERE username='%s' AND password='%s'"%(usr, pass_))._fetch()) == 0:
			return False
		return True

	def encrypt_pass(self:object, username:str, password:str,) -> (object, str, str):

		def checksum(username:str, password:str) -> (str, str):
			packed = ""
			n = 0
			for index, items in enumerate(username, 0):
				if index+1+n >= len(username)-1:
					continue
				pck = items + username[index+1+n]
				pck += password[index] + password[index+1+n]
				packed += pck
				n += 1
			while len(packed) > 32:
				packed = packed[:-1]
			while len(packed) < 32:
				packed += "a"
			return packed
		usrtemp, passtemp = username, password
		if len(usrtemp) > len(passtemp):
			usrtemp = usrtemp[:len(usrtemp)-((len(usrtemp)-len(passtemp)))]
		if len(passtemp) > len(usrtemp):
			passtemp = passtemp[:len(passtemp)-(len(passtemp) - len(usrtemp))]
		ak = checksum(usrtemp, passtemp).encode("utf-8", errors="ignore")
		aes = AES.new(ak, AES.MODE_GCM, ak)
		msg = self.hash_((self.hash_(aes.encrypt(password.encode("utf-8", errors="ignore")))).encode("utf-8", errors="ignore"))
		return msg

	# create account feature.
	def addusr(self:object) -> (object):
		anon = False
		admin = False
		if len(self.instanceOfClass.cmd.split(" ")) < 3:
			return "[operation.addusr] Couldn't create an account. Too few arguments provided."
		spl = self.instanceOfClass.cmd.split(" ")
		xza = [spl[bob+1] for bob in range(0, len(spl), 1) if bob+1 <= len(spl)-1 and spl[bob] == "/a"]
		# not admin in array, since anonymous SHOULD not be considered an administrative profile.
		if "/a" in spl and len(xza) != 0 and xza[0] == "true" and not "/admin" in xza:
			anon = True
		elif "/admin" in spl:
			if self.is_admin_user() == False:
				return "[operation.addusr] Operation failed! Run as administrator in order to create that account to be an admin."
			admin =  True
		usr, pass_ = self.instanceOfClass.cmd.split(" ")[1], self.instanceOfClass.cmd.split(" ")[2]
		if search(r"^[0-9a-zA-Z]*$", usr) == None:
			return "[operation.addusr] Forbidden symbols have been used! Symbols from - [A-z] and [0-9] are only allowed!"
		if not (4 <= len(usr) <= 32):
			return "[operation.addusr] Operation failed! Reason>> username is not 4 <= len(usr) >= 32!"
		if len(self.instanceOfClass.database(db="ftsrv", syntax="SELECT count(id) FROM user_ftsrv_accounts")._fetch()) != 0 and int(self.instanceOfClass.database(db="ftsrv", syntax="SELECT count(id) FROM user_ftsrv_accounts")._fetch()[0][0]) >= int(self.instanceOfClass.database_prop["maxAcc"]):
			return "[operation.addusr] Cannot create more accounts ..."
		if self.exist_username(username=usr) == True:
			return "[operation.addusr] Couldn't create an account. Account with that username already exists."
		msg = self.encrypt_pass(usr, pass_)
		xz = input("Are you really sure that you want to create account with name - '%s' (y/n)>> "%(usr))
		if xz.lower() == "n":
			return "[operation.addusr] Not creating account for now..."
		acc = str(uuid4())
		x1, uploadfiles, browsedirs, removefiles, oneper, dirto, movdir, fixeddir, createDir, forbiddenDir = UserProp(self).user_operations(anon, admin)
		if x1 == False:
			return uploadfiless
		if dirto == "":
			dirto = getcwd()
		if admin == True:
			digit_pass = ""
			while (digit_pass == ""):
				xz = input("Enter pass-key for admin-password (4-chars or more): ")
				if len(xz) < 4:
					print("[operation.addusr] Pass-key cannot be fewer than 4-characters!")
				digit_pass += xz
			digit_pass = digit_pass.encode("utf-8", errors="ignore")
			pass_ = self.hash_(digit_pass + pass_.encode("utf-8", errors="ignore"))
		self.instanceOfClass.database(db="ftsrv", syntax="INSERT INTO user_ftsrv_accounts(username, password, account_id, datetime_created, is_anon, is_admin) VALUES ('%s', '%s', '%s', '%s', %r, %r);"%(usr, msg, acc, self.getLocalTime(), anon, admin))._insert()
		self.instanceOfClass.database(db="ftsrv", syntax="INSERT INTO account_rules(account_id, append_files, remove_files, start_directory,fixeddir ,fetch_files, account_usage_per_clients, movdir, browse_files, is_anon, forbiddenDirs) VALUES ('%s', %d, %d, '%s', '%s', %d, %d, %d, %d, %r, '%s');"%(acc, int(uploadfiles), int(removefiles), dirto,fixeddir, 1,int(oneper), int(movdir), int(browsedirs), anon, forbiddenDir))._insert()
		return "[operation.addusr] Account created successfully!"

	def disconnect_user_account(self:object, account_id:str) -> (object, str):
		account_id = account_id[0]
		sel_hosts = self.instanceOfClass.database(db="ftsrv", syntax="SELECT client FROM __db__.alive_user_sessions WHERE account_id='%s'"%(account_id))._fetch()
		for hosts in sel_hosts:
			if hosts in self.alive_sessions:
				self.instanceOfClass.database(db="ftsrv", syntax="UPDATE __db__.user_log SET is_logged=false WHERE client='%s'"%(hosts))._insert()
				self.instanceOfClass.alive_sessions[hosts]["logged"] = None
		return None

	def is_admin(self:object, username:str, password:str):
		retr = self.instanceOfClass.database(db="ftsrv", syntax="SELECT is_admin FROM __db__.user_ftsrv_accounts WHERE username='%s' AND password='%s'"%(username, password))._fetch()
		assert retr != []
		if retr[0][0] == 1:
			return True
		return False


	def is_admin_user(self:object): cx = False if (ctypes.windll.shell32.IsUserAnAdmin() != 0) == False else True; return cx

	def delusr(self:object) -> (object):
		slashes = [slash for slash in self.instanceOfClass.cmd.split(" ") if "/" in slash]
		if len(self.instanceOfClass.cmd.split(" ")) < 3:
			return "[operation.delusr] Couldn't delete an account. Too few arguments provided."
		if not ("/F" in slashes or "/f" in slashes):
			usr, pass_ = self.instanceOfClass.cmd.split(" ")[1:]
			if self.account_existence(account=(usr, pass_)) == False:
				# this is specifically for account protection over the account.
				return "[operation.delusr] Couldn't delete an account. Account does not exist or the entered password is incorrect.."
			pass_ = self.encrypt_pass(usr, pass_)
			xz = input("Are you sure, really sure, VERY sure that you want to delete account with name - '%s' (y/n)>> "%(usr))
			if xz == "n" or xz == "N":
				return "[operation.delusr] Not deleteing account for now..."
			syntax = "DELETE FROM __db__.user_ftsrv_accounts WHERE username='%s' AND password='%s'"%(usr, pass_)
			account_id = self.instanceOfClass.database(db="ftsrv", syntax="SELECT account_id FROM user_ftsrv_accounts WHERE username='%s' AND password='%s'"%(usr, pass_))._fetch()
		else:
			if len(self.instanceOfClass.cmd.split(" ")) < 3:
				return "[operation.delusr] No username provided!"
			usr = self.instanceOfClass.cmd.split(" ")[1]
			if self.is_admin_user() == False:
				return "[operation.delusr] Not deleting account for now, with forcibly option provided. Permission denied!"
			account_id = self.instanceOfClass.database(db="ftsrv", syntax="SELECT account_id FROM user_ftsrv_accounts WHERE username='%s'"%(usr))._fetch()
			if len(account_id) == 0:
				return "[operation.delusr] Account does not exist!"
			syntax = "DELETE FROM user_ftsrv_accounts WHERE username='%s'"%(usr)
		id_ = self.instanceOfClass.database(db="ftsrv", syntax="SELECT account_id FROM __db__.user_ftsrv_accounts WHERE username='%s'"%(usr))._fetch()
		self.instanceOfClass.database(db="ftsrv", syntax=syntax)._insert()
		self.instanceOfClass.database(db="ftsrv", syntax="DELETE FROM __db__.account_rules WHERE account_id='%s'"%(id_[0][0]))._insert()
		self.disconnect_user_account(account_id=account_id)
		return "[operation.delusr] User '%s' successfully deleted!"%(usr)

	def hash_(self:object, target:bytes) -> (object, bytes):
		xz = sha512()
		xz.update(target)
		return xz.hexdigest()

	def hash_own(self:object, target:bytes, hashm:object) -> (object, bytes, object):
		xz = hashm()
		xz.update(target)
		return xz.hexdigest()


	# TODO: updates onto user method.
	def users(self:object) -> (object):

		def users_func():
			caser = {"change.password":self.User(instance=self).change_password, "change.username":self.User(instance=self).change_username, "more.showall":self.User(instance=self).show_acc_info}
			if self.instanceOfClass.cmd.split(" ")[1].strip() not in caser:
				return
			func = caser[self.instanceOfClass.cmd.split(" ")[1].strip()]
			func()

		xz = None if len(self.instanceOfClass.cmd.split(" ")) == 1 else users_func
		if xz != None:
			try:
				users_func()
			except Exception as e:
				print(e)
		fet = self.instanceOfClass.database(db="ftsrv", syntax="SELECT datetime_created, username FROM __db__.user_ftsrv_accounts")._fetch()
		if len(fet) == 0:
			return "\r\x0ANo accounts available..\r\x0A"
		xz = "\n".join(bob + ", date created - %s "%(date) for date, bob in fet)
		return "\x2D" * 50 + "\r\x0A" + xz + "\r\x0A" + "\x2D" * 50 + "\r\x0A"

	def clean_connectedList(self:object) -> (object):
		for index, elements in enumerate(self.instanceOfClass.connectedList, 0):
			sock, ip = elements
			if -1 >= sock.fileno():
				del self.instanceOfClass.connectedList[index]

	def send_little_file(self:object, file:str, socket_obj:object, socket:object) -> (str, object):
		with open(file, "rb") as file:
			for contents in file:
				socket_obj(contents, socket=socket, flag=False)

	# to stream little file.
	def stream_little_File(self:object, file:str) -> (str, int):
		return b"".join(bob for bob in open(file, "rb"))

	# more slow, but user-friendly.
	def show_connections(self:object) -> (object):
		av = "\n".join("%s:%s connected, Connection-time: %s."%(h[1][0], h[1][1], self.instanceOfClass.database(db="ftsrv", syntax="SELECT datetime FROM __db__.connections WHERE client='%s' AND port=%d"%(h[1][0], int(h[1][1])))._fetch()[0][0]) for h in self.instanceOfClass.connectedList)
		if len(av) == 0:
			av = "No connections from clients."
		return "\x2D" * 60 + "\n" + "Total connections: %d\n\n"%(len(self.instanceOfClass.connectedList))+ av + "\n" + "\x2D"*60 + "\n"

	# fast and effortless.
	def show_only_number_of_connections(self:object) -> (object): return len(self.instanceOfClass.connectedList)

	def close_specific_conn(self:object) -> (object):
		try:
			if len(self.instanceOfClass.com.split(" ")) == 1:
				return "[operation.close_specific_conn] Operation failed! Missing client and port."
			cmd, val, port = [bob for bob in self.instanceOfClass.com.split(" ") if len(bob) != 0]
			index = [enm for enm, bob in enumerate(self.instanceOfClass.connectedList, 0) if val == bob[1][0] and int(port) == bob[1][1]]
		except Exception as e:
			return "[operation.close_specific_conn] Operation failed! Reason >> %s"%(e)
		if len(index) == 0:
			return "No host found with '%s' address."%(val)
		elif len(index) != 0 and self.instanceOfClass.connectedList[index[0]][0].fileno() != -1:
			sock, addr = self.instanceOfClass.connectedList[index[0]]
			sock.close()
			del self.instanceOfClass.connectedList[index[0]]
		else:
			del self.instanceOfClass.connectedList[index[0]]
		self.kick_client(addr=val, port=int(port))
		return "(%s) Host found! And connection stopped."%(val)

	def kick_client(self:object, addr:str, port:int) -> (object, str):
		session_id = self.instanceOfClass.database(db="ftsrv", syntax="SELECT session_id FROM __db__.connections WHERE client='%s' AND port=%d"%(addr, port))._fetch()
		if len(session_id) == 0:
			return
		session_id = session_id[0][0]
		#socket = self.instanceOfClass.alive_sessions[session_id]["socket"]
		for syntax in ("DELETE FROM __db__.connections WHERE client='%s' AND port=%d"%(addr, port), "DELETE FROM __db__.alive_user_sessions WHERE account_id='%s'"%(session_id), "DELETE FROM __db__.user_log WHERE client='%s'"%(session_id)):
			self.instanceOfClass.database(db="ftsrv", syntax=syntax)._insert()
		if session_id in self.instanceOfClass.alive_sessions:
			del self.instanceOfClass.alive_sessions[session_id]
		index = [index for index, enm in enumerate(self.connectedList, 0) if socket == enm]
		if len(index) != 0:
			del self.connectedList[index[0]]
		return

	def check_logins(self:object) -> (object):
		from utils.abstraction import abstractions
		self.dictObj = self.instanceOfClass.logged_client_sessions
		self.p = [keys for keys in self.dictObj if "timePool" in self.dictObj]
		self.dictPVal = [(self.check_Timing(stamp[keys]["timePool"]), keys) for stamp, keys in self.p]
		for values, keys in self.dictPVal:
			if values == True:
				del self.instanceOfClass.logged_client_sessions[keys]
		abstractions().clear(None, [self.dictObj, self.p, self.dictPVal])

	def check_logins_typeaccs(self:object) -> (object):
		from utils.abstraction import abstractions
		self.dictObj = self.instanceOfClass.logged_client_sessions
		self.dictPVal = [(self.dictObj[keys]["typeacc"], keys) for keys in self.dictObj]
		for type_acc, keys in self.dictPVal:
			if type_acc == "System.Ftsrv/users/administrators" and self.instanceOfClass.normalProperties["admin"] == 0:
				del self.instanceOfClass.logged_client_sessions[keys]
		abstractions().clear(None, [self.dictObj, self.dictPVal])

	# TODO: Check "timePool" - client logins, client connections.
	def check_entries(self:object, *args) -> (object):
		self.check_logins()
		self.check_logins_typeaccs()
				

	def getLocalTime(self:object, dict_like_obj=False) -> (object):
		items = {"month":{1:"Jan", 2:"Feb", 3:"Mar", 4:"Apr", 5:"May", 6:"Jun", 7:"Jul", 8:"Aug", 9:"Sep", 10:"Oct", 11:"Nov", 12:"Dec"}, "week":{0:"Mon", 1:"Tue", 2:"Wed", 3:"Thu", 4:"Fri", 5:"Sat", 6:"Sun"}}
		year, monthn, dayn, day, hour, minute, sec = datetime.now().year, items["month"][datetime.now().month], items["week"][datetime.now().weekday()],datetime.now().day, datetime.now().hour, datetime.now().minute, datetime.now().second
		out = "%d %s %d %s, %d:%d:%d"%(year, monthn, day, dayn, hour, minute, sec) if dict_like_obj == False else {"year":year, "month":datetime.now().month, "day":day, "hour":hour, "minute":minute, "second":sec}
		return out

	def delete_Records_Connections(self:object) -> (object):
		for syntax in (("DELETE FROM __db__.connections"), ("DELETE FROM __db__.user_log"), ("DELETE FROM __db__.alive_user_sessions")):
			self.instanceOfClass.database(db="ftsrv", syntax=syntax)._insert()
		return

	def close_connection(self:object, client:str, port:int) -> (object, str):
		index = [enm for enm, act in enumerate(self.instanceOfClass.connectedList, 0) if act[1][0] == client and act[1][1] == port][0]
		sock, addr = self.instanceOfClass.connectedList[index]
		del self.instanceOfClass.connectedList[index]
		sock.close()
		self.kick_client(addr=addr[0], port=port)

	def exit_(self):
		if self.instanceOfClass.binded == True and "sock" in dir(self.instanceOfClass):
			self.instanceOfClass.sock.close()
		for connections in self.instanceOfClass.connectedList:
			connections[0].close()
		if self.instanceOfClass.normalProperties["DeleteRecordsInDBOnExit"] != "False":
			self.delete_Records_Connections()
		exit("Server exitting..")

	def verbose_operation(self:object, text:str, handle:bool) -> (object, str, bool):
		if handle == True:
			stdout.write(text + "\n")

	def start_server(self:object) -> (object):
		xz = [bob for bob in self.instanceOfClass.cmd.split(" ")]
		self.instanceOfClass.verbose_srv = True if "/v" in xz or "/V" in xz else False
		if "/h" in xz and len(self.instanceOfClass.cmd.split("/h")) != 1:
			self.instanceOfClass.toH = self.instanceOfClass.cmd.split("/h")[1]
		self.verbose_operation(text="[operation.start_server] Clearing old connections records...", handle=self.instanceOfClass.verbose_srv)
		self.delete_Records_Connections()
		self.instanceOfClass.alive_sessions = {}
		if self.instanceOfClass.binded == True:
			return "[operation.start_server] Server is already started.."
		def xzx():
			try:
				self.verbose_operation(text="[operation.start_server] Starting server ...", handle=self.instanceOfClass.verbose_srv)
				start_threaded_server.__init__(self)
				self.instanceOfClass.binded = True
			except Exception as e:
				print("[operation.start_server] Operation failed! Reason>> %s"%(e))
				exit()
		Thread(target=xzx, args=()).start()
		return "[operation.start_server] Socket created %s://%s! Server started"%(self.instanceOfClass.normalProperties["bindHost"], self.instanceOfClass.normalProperties["bindPort"])

	def stop_server(self:object) -> (object):
		self.stop_all_connections()
		try:
			self.instanceOfClass.sock.close()
		except Exception as e:
			return "[operation.stop_server] Operation failed! Due to >> %s.."%(e)
		self.instanceOfClass.binded = False
		return "[operation.stop_server] Operation completed!"

	def stop_all_connections(self:object) -> (object):
		if self.instanceOfClass.binded == False:
			return "[operation.stop_all_connections] No binded socket."
		if len(self.instanceOfClass.connectedList) == 0:
			return "[operation.stop_all_connections] No clients connected!"
		n = 0
		try:
			for sock, addr in self.instanceOfClass.connectedList:
				ip, port = addr
				if sock.fileno() == -1:
					pass
				else:
					sock.send(b"closing")
					sock.close()
				n += 1
		except Exception as f:
			return "[operation.stop_all_connections] Operation failed! Due to reason>> %s!"%(f)
		self.instanceOfClass.connectedList = []
		self.delete_Records_Connections()
		return "[operation.stop_all_connections] Operation succeeded! Closed '%d' connections!"%(n)
