"""
Denial Of Service mitigation strategy - - - - -.

(multiple clients forcibly connecting the client for Nh, Nm, Ns) - - - - - > (server accepting all these N-clients connected for Nh, Nm, Ns).
When the pool with connected clients reaches more than the limit (N, where it could be 16) the server will
stop receiving connections for specific time and blacklists the hosts which connected the mosts(automatically), 
it could be a hour or half a hour <=> 60-minutes || 30-minutes.

----

That strategy will be updated, and improved over the time.

"""
class mitigation_strategy(object):
	def __init__(self:object, client:str, connectedList:list, instance:object):
		self.client = client; self.connectedList = connectedList; self.instance = instance
		self.scan_client()

	def check_connectivity_time_event(self:object, actual:list) -> (list):
		traffic_encounter = 0
		for i, j in enumerate(actual, 0):
			if i+1 > len(actual)-1:
				continue
			ch1, ch2 = self.instance.inst.unpack(j), self.instance.inst.unpack(actual[i+1]) # instance -> 2023, 2, 26, 11, 16, 53
			if ch1[0] == ch2[0] and ch1[1] == ch2[1] and ch1[2] == ch2[2] and ch1[3] == ch2[3] and ch1[4] == ch1[4] and abs(ch1[5]-ch2[5]) < 10:
				traffic_encounter += 1
		return traffic_encounter

	def scan_client(self:object):
		actual = [self.connectedList[client]["connected"] for client in self.connectedList if self.client in client]
		len_, find_h = len(actual), self.check_connectivity_time_event(actual)
		if len_ > 16 and find_h > 16:
			self.instance.request_Blacklist = True
			if self.instance.inst.instanceOfClass.firewallProperties["stopconnectionsOnDoS"] == "1":
				def check_actual(stamp:dict) -> (int):
					if stamp["minutes"]+int(self.instance.inst.firewallProperties["outage_time"])<59:
						stamp["minutes"] = stamp["minutes"]+int(self.instance.inst.firewallProperties["outage_time"])
					else:
						stamp = self.instance.inst.check_complexity(stamp, int(self.instance.inst.firewallProperties["outage_time"]))
					return stamp
				xza = check_actual(self.instance.inst.datetime_pool())
				self.instance.stop_server_connectionsFIREWALL = True; self.instance.mitg_stamp = xza
			self.instance.inst.database(db="ftsrv", syntax="INSERT INTO __db__.server_outage(outage_type, datetime, notes, level) VALUES ('%s', '%s', '%s', %d)"%("dos.mitigation",self.instance.inst.getLocalTime(), "Warning: DoS attack detected? Host:: %s"%(self.client), 5))._insert()
