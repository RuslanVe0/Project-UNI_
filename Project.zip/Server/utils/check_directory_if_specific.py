from typing import Union, Type
from utils.commands import commands_Interface
from utils.website.commands import commands
from utils.commands import commands_Interface as cface

class main(object):


    def __init__(self, instance_class:object, search=None): self.commands = commands(self, instance_class); self.search = search; self.instance_class = instance_class;self.cie = commands_Interface;self.abparts = abstract_parts(self.instance_class); self.abparts_this = abstract_parts(self); self.parts = {"/ftsrv/account/guest/fetch-connections":self.abparts.fetch_connections, "/ftsrv/account/guest/help":self.abparts_this.help_mode, "/ftsrv/account/fetch/userData":self.abparts_this.userData, "/ftsrv/account/fetch/fetch_uuid":self.abparts_this.fetch_uuid, "/ftsrv/account/userAccount/":self.abparts_this.user_account, "/ftsrv/account/userAccount/fetch-buttons/":self.abparts_this.fetch_buttons}

    def ispart(self):
        if self.instance_class.path.split("?")[0].split("~")[0] in self.parts:
            return True
        return False

    def uploaded_detection(self:object):
        webbased = self.instance_class.path.split("~")
        if len(webbased) < 2:
            return "/ftsrv/account/login.html", "text/html", "301", "/ftsrv/account/login.html"
        webbased = webbased[1].split("/")[0]
        if webbased not in self.instance_class.instance.inst.inst.instanceOfClass.logged_client_sessions:
            return "/ftsrv/account/login.html", "text/html", "301", "ftsrv/account/login.html"
        if webbased not in self.instance_class.instance.inst.inst.instanceOfClass.uploaded_files:
            return {"msg":["No uploaded files located!", "unknown", "0"]}
        sel = self.instance_class.instance.inst.inst.instanceOfClass.uploaded_files[webbased]
        return {"msg":[sel["file"], sel["datetime"], sel["size"], sel["designated"]]}

    def check_authorize(self:object):
        webbased = self.instance_class.path.split("~")
        if len(webbased) < 2:
            return {"msg":False}
        webbased = webbased[1].split("/")[0]
        if webbased in self.instance_class.instance.inst.inst.instanceOfClass.logged_client_sessions:
            return {"msg":True}
        return {"msg":False}

    def dosc(self):
        func = self.parts[self.instance_class.path.split("?")[0].split("~")[0]]
        return func()
    
    def is_pdf(self:object):
        splitted = self.instance_class.path.split("?id=")
        if "/ftsrv/rules/pdf/" in self.instance_class.path.split("?")[0] and len(splitted) != 1:
            return True
        return False

class abstract_parts(object):
    def __init__(self:object, instance_of_class:object) -> (object):
        self.instance_of_class = instance_of_class
    
    def fetch_connections(self:object) -> (object):
        fetched = self.instance_of_class.instance.inst.inst.show_only_number_of_connections()
        return fetched

    def user_account(self:object) -> (object):
        webBased = self.instance_of_class.instance_class.path.split("~")[1].split("/")[0]
        if self.instance_of_class.commands.check_if_authorizedWebBased(webBased) == False:
            self.instance_of_class.instance_class.path, self.instance_of_class.instance_class.st = "/ftsrv/account/~remove-token.html", "301"
        elif "/command/" in self.instance_of_class.instance_class.path.split("~")[1]:
            if len(self.instance_of_class.instance_class.path.split("/command")) < 2:
                self.instance_of_class.instance_class.path, self.instance_of_class.instance_class.st = "/ftsrv/account/fbo404.html", "404"
            else:
                get_command = self.instance_of_class.instance_class.path.split("/command")[1]
                act = None if len(self.instance_of_class.instance_class.path.split("?")) <= 1 else self.instance_of_class.instance_class.path.split("?")[1]
                return_ = self.instance_of_class.cie(website_instance=True, command=get_command, instance=self.instance_of_class.instance_class.instance, sock=self.instance_of_class.instance_class.socket, socket_handler=self.instance_of_class.instance_class.instance.inst).formulate(wuuid=webBased, arg=act)
                if isinstance(return_, dict) == True:
                    self.instance_of_class.instance_class.path, self.instance_of_class.instance_class = self.instance_of_class.instance_class.path, "200"
                    return return_
        else:
            self.instance_of_class.instance_class.path, self.instance_of_class.instance_class.st = "/logged/account/%s"%(self.instance_of_class.instance_class.path.split("/")[len(self.instance_of_class.instance_class.path.split("/"))-1]), "200"
        self.instance_of_class.instance_class.webbasedToken = webBased
        return "text/html"

    def fetch_buttons(self:object):
        sel_ = self.instance_of_class.instance_class.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="SELECT encoded_base64 FROM website_contents_specific WHERE name='fetch-buttons'")._fetch()
        return {"msg":sel_}

    def fetch_uuid(self:object) -> (object):
        uuid = cface(website_instance=True, instance=self.instance_of_class.instance_class.instance, data=self.instance_of_class.instance_class.data_hold[0]).fetch_uuid()
        if uuid == None or len(uuid) == 0 or uuid == []:
            return False
        return {"msg":uuid}

    def userData(self:object) -> (object):
        uuid = cface(website_instance=True, instance=self.instance_of_class.instance_class.instance, data=self.instance_of_class.instance_class.data_hold[0]).fetch_uuid()
        if uuid == None:
            return False
        uuid = uuid
        objectCl = self.instance_of_class.instance_class.instance.inst.inst.instanceOfClass.logged_client_sessions[uuid]
        return {"toc":objectCl["typeacc"], "uuid":uuid, "las":objectCl["username"]}
    
    def help_mode(self:object) -> (object): return self.instance_of_class.commands.help_menu()

