from dataclasses import dataclass
from typing import Union, Type
from gc import collect as gcollect

class types(object):
    types_list:(Type[list], Type[tuple], Type[set], Type[dict])=(Type[list], Type[tuple], Type[set], Type[dict])

class abstractions(object):
    def __init__(self):
        pass

    @classmethod
    def clear(cls, pointed_list:types().types_list, *args) -> (types().types_list):
        if len(args) != 0:
            for pointed in args:
                assert isinstance(pointed, (list, tuple, set, dict)) != False
                del pointed
        else:
            del pointed_list
        gcollect()