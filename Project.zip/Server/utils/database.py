# a program to communicate with MySQL relationship database.
import mysql.connector

class database(object):
	
	def __init__(self:object, db:str, syntax:str, verbosity=False,*args) -> (object, str, list, bool):
		self.db=db; self.verbosity=verbosity
		self.load_auths()
		self.syntax = syntax.replace("__db__", db); self.instance = self.create_database_connection(creds=self.password, user=self.username)

	def load_auths(self:object):
		creds = [bob for bob in open("sql_auth.txt", "r", encoding="utf-8")]
		self.username, self.password = creds

	def _fetch(self:object):
		lf = self.instance.cursor()
		lf.execute(self.syntax)
		return lf.fetchall()

	def create_database_connection(self:object, creds:str, user:str) -> (object, str, str):
		return mysql.connector.connect(host="localhost", database=self.db, user=user, password=creds)

	def _insert(self:object) -> (object):
		lf = self.instance.cursor()
		lf.execute(self.syntax)
		self.instance.commit()
		return

