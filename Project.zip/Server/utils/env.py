from sys import stdout

class commands(object):

	def __init__(self, command:str, instanceOfClass:object):
		self.instanceOfClass = instanceOfClass; self.command = command
		self.instanceOfClass.instation = self

	def return_(self:object):
		inf = {"help":'''
This product is licensed with -> Attribution-Non Commercial CC BY-NC 
(Intended for clients that support ONLY this server!)
(check README.md for command guide)
(help menu)

help    -> display all commands.
HELP+   -> Description of all commands.
HELPCMD -> Help on specific command (e.g helpcmd conn (and it'll output the help.))
____________________________________
STSRV  HLSRV  CLA     EXIT
CLCON  SHOWCN USRS    ADDUSR
CLSC   ECONF  FING    SRSRV
UESC   ECONFE USEROWN

*--------------------------------------*

For further command guidence, please read contents from README.md file. All of the commands
are mentioned there, and described well and easily readable.

Use - somecommand /? to output help, about the slashes.
Use - somecommand ? to output help, about the arguments.
------------------------------------------

''', "help+":self.show_further_help, "stsrv":self.instanceOfClass.local_commands.start_server, "hlsrv":self.instanceOfClass.local_commands.stop_server,"helpcmd":self.show_cmd_help,
"cla":self.instanceOfClass.local_commands.stop_all_connections, "exit":self.instanceOfClass.local_commands.exit_, "clcon":self.instanceOfClass.local_commands.close_specific_conn,
"showcn":self.instanceOfClass.local_commands.show_connections, "usrs":self.instanceOfClass.local_commands.users,
"addusr":self.instanceOfClass.local_commands.addusr, "delusr":self.instanceOfClass.local_commands.delusr, "clsc":self.instanceOfClass.local_commands.clear_screen, "econf":self.instanceOfClass.local_commands.edit_config,
"fing":self.instanceOfClass.local_commands.trigger_fingerprint, "srsrv":self.instanceOfClass.local_commands.stop_receiving_request_for_time,
"uesc":self.instanceOfClass.local_commands.update_config_file,
"econfe":self.instanceOfClass.local_commands.edit_config_file_file, "userown":self.instanceOfClass.local_commands.userown}
		if self.command == None:
			return
		help_ = ""
		for j in self.command.split(" "):
			# it'll be user desired, how much time a specific argument is used, while data is getting parsed here.
			if "/?" == j and self.command.split(" ")[0].strip() in self.instanceOfClass.loaded_slashes_help:
				help_ += self.instanceOfClass.loaded_slashes_help[self.command.split(" ")[0].strip()] + "\x0A\x0A"
			elif j.strip() == "?" and self.command.split(" ")[0].strip() in self.instanceOfClass.loaded_argument_help:
				help_ += self.instanceOfClass.loaded_argument_help[self.command.split(" ")[0].strip()] + "\x0A\x0A"
		if help_ != "":
			return help_
		if self.command.split(" ")[0].strip() not in inf:
			return "'%s' is not recognized as a command. Please enter 'help' in order to output the help menu."%(self.command)
		self.instanceOfClass.cmd = self.command
		return inf[self.command.split(" ")[0].strip()]

	def show_cmd_help(self:object, *args):
		if len(self.command.split(" ")) < 2 or self.command.split(" ")[1] not in self.instanceOfClass.podrobno_menu:
			return "Too few arguments provided for 'helpcmd' command or command does not exist!"
		sf = self.instanceOfClass.podrobno_menu[self.command.split(" ")[1]]
		return sf

	def show_further_help(self:object, *args):
		if_str = self.instanceOfClass.local_commands.stream_little_File(file="%s/README.md"%(self.instanceOfClass.currdir))
		stdout.write(if_str.decode("utf-8", errors="ignore") + "\x0A")
		return ""


class run_no_gui(object):

	def __init__(self:object, *args):
		self.website = args[0] if len(args) != 0 else False
		while True:
			try:
				p1, self.com = self.local_commands.user_input()
				if p1 == False:
					print(self.com)
					continue
				cmd = commands(command=self.com, instanceOfClass=self).return_()
			except (KeyboardInterrupt, Exception) as e:
				print(e)
				continue
			if cmd == None or cmd == False:
				continue
			if isinstance(cmd, list) == False and isinstance(cmd, tuple) == False and isinstance(cmd, str) == False:
				cmd = cmd()
			stdout.write(cmd + "\x0A")

