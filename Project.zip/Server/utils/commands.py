from datetime import datetime
from utils.file_control import file_control
from utils.saved_sessions import saved_sessions # module specifically for interactions of client's saved sessions.
from datetime import date
from hashlib import sha512
from uuid import uuid4
from json import loads,dumps
from os.path import exists, isfile, getsize
from os import listdir
import hashlib
from string import ascii_letters
from typing import Type, Union
from random import randint
from Cryptodome.PublicKey import RSA
from Cryptodome.Cipher import PKCS1_OAEP
from utils.tools import tools # module specifically for tools that are required for management and control over client and server behavior.
#from utils.cryptobased import cryptobased

class commands_Interface():
	def __init__(self:object, command="", socket_handler=None, instance=None, sock=None, data=((None, 1234)), website_instance=False) -> (str):
		self.socket = sock; self.arg = None; self.session_class = saved_sessions(self) # inheritence.
		self.command = command; self.socket_handler = socket_handler; self.instance = instance; self.inc = None; self.file_control = file_control; self.client_data = data; self.website_instance = website_instance
		self.commandd = {"help":'''
This product is licensed with -> Attribution-Non Commercial CC BY-NC 
(Intended for servers that support ONLY this client!)
(check README.md for command guide)
(help menu)

help    -> display all commands.
HELP+   -> Description of all commands.
HELPCMD -> Help on specific command (e.g helpcmd conn (and it'll output the help.))

____________________________________
TIME  USER   APN     CUSER
CDCH  SIZD   DIR     LOGOUT
CD    SHOWCN SPTH    GHASHF
LOG   DELFIL MKDIR   DELDIR
TACC  WHOAMI GETSZ   SAVEAC
DOWNLOAD

*--------------------------------------*

For further command guidence, please read contents from README.md file. All of the commands
are mentioned there, and described well and easily readable. You can of course integrate a new
command, its the client of course, BUT IT SHOULD actually meet server's commands ~ IF SERVER-SIDE ~.
This client is offical release. User inputs are NOT case sensitive, it doesn't matter if you enter a
command with upper || lower case.

------------------------------------------

''', "time":self.time_, "user":self.user_handler, "login":self.user_handler, "cuser":self.current_user, "cd":self.current_dir, "cdch":self.change_dir, "sizd":self.check_size_current_dir, "dir":self.fs_dir,
"logout":self.logout_user, "showcn":self.show_connections_available, "spth":self.send_first_path,
"ghashf":self.ghashf, "log":self.trigger_log, "delfil":self.request_file_deletion, "mkdir":self.create_directory, "deldir":self.delete_directory,
"tacc":self.typeacc, "whoami":self.typeacc, "help_admin":'''
This product is licensed with -> Attribution-Non Commercial CC BY-NC 
(Intended for servers that support ONLY this client!)
(check README.md for command guide)
(help menu)

help    -> display all commands.
HELP+   -> Description of all commands.
HELPCMD -> Help on specific command (e.g helpcmd conn (and it'll output the help.))

____________________________________
SHOWCONS SHOWTOPCON SHOWUSR




*--------------------------------------*

For further command guidence, please read contents from README.md file. All of the commands
are mentioned there, and described well and easily readable. You can of course integrate a new
command, its the client of course, BUT IT SHOULD actually meet server's commands ~ IF SERVER-SIDE ~.
This client is offical release. User inputs are NOT case sensitive, it doesn't matter if you enter a
command with upper || lower case.

------------------------------------------
''', "showcons":self.show_conns, "showtopcon":self.top_connections, "easteregg":self.easter_egg,
"getsz":self.get_file_size, "showusr":self.show_users, "saveac":self.session_class.save_account, "helpcmd":self.help_cmd, "download":self.download_webbased}
		if website_instance == False:
			self.actual_command()

	def actual_command(self:object):
		if self.command == "question_msg:closed_connection":
			out = self.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="SELECT message, datetime FROM __db__.logout_errors WHERE client_id='%s' ORDER BY id DESC LIMIT 1"%(self.fetch_uuid()))._fetch()
			if len(out) == 0 or out == []:
				self.socket_handler.send_normal_pkt(data=b"Unknown reason..", socket=self.socket)
				return
			self.socket_handler.send_normal_pkt(data=("%s:%s"%(out[0][0], out[0][1])).encode("utf-8", errors="ignore"), socket=self.socket)
			return
		if self.command == "auto_login" and self.instance.inst.inst.instanceOfClass.logged_client_sessions[self.fetch_uuid()]["logged"] == False:
			self.login_auto_client()
			return
		elif self.command == "auto_login" and self.instance.inst.inst.instanceOfClass.logged_client_sessions[self.fetch_uuid()]["logged"] == True:
			self.socket_handler.send_normal_pkt(data=b"error: client is already authorized!", socket=self.socket)
			return
		if self.command == "question_msg::amiauthorized?":
			self.socket_handler.send_normal_pkt(data=("%s"%(self.instance.inst.inst.instanceOfClass.logged_client_sessions[self.fetch_uuid()]["logged"])).encode("utf-8", errors="ignore"), socket=self.socket)
			return
		if self.authorize() != False and self.instance.inst.inst.instanceOfClass.logged_client_sessions[self.fetch_uuid()]["logging"] == True:
			self.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="INSERT INTO __db__.logging_info(client_id, command, datetime) VALUES ('%s', '%s', '%s')"%(self.fetch_uuid(), self.command, self.instance.inst.inst.getLocalTime()))._insert()
		if self.command.strip() == "test.connection":
			self.socket_handler.send_normal_pkt(data=b"connection: True", socket=self.socket)
			return
		if self.command.strip() == "help+":
			self.socket_handler.send_normal_pkt(data=("\x0A\x0A" + "\x0A".join("%s -> %s"%(bob, self.instance.inst.inst.instanceOfClass.remote_based_commands[bob]) for bob in self.instance.inst.inst.instanceOfClass.remote_based_commands) + "\r\x0A\r\x0A").encode("utf-8", errors="ignore"), socket=self.socket)
			return
		if self.command.strip().split(" ")[0] not in self.commandd:
			self.socket_handler.send_normal_pkt(data=b"Command: Not found!", socket=self.socket)
			return
		xz = self.commandd[self.command.strip().split(" ")[0]]
		if isinstance(xz, str) == False:
			xz = xz()
		if xz == False or xz == None:
			return
		if self.website_instance == True:
			return xz
		self.socket_handler.send_normal_pkt(data=xz.encode("utf-8", errors="ignore"), socket=self.socket)

	# usage of this method will be specifically for 'website_instance'.
	def formulate(self:object, wuuid:str, arg:str) -> (object, str, str):
		self.arg = arg
		if len(self.command.split("/")) == 0:
			return {"msg":"The requested command has an invalid context ... "}
		self.command = self.command.split("/")[1]
		if self.command.split("?")[0].lower() not in self.commandd:
			return {"msg":"Command is not located!"}
		func = self.commandd[self.command.split("?")[0].lower()]
		return func(wuuid)

	def help_cmd(self:object, wuuid=""):
		if (1 < len(self.command.split(" ")) < 3) == False:
			if self.website_instance == True:
				return {"msg":"Not enough arguments were parsed!"}
			self.socket_handler.send_normal_pkt(data=b"error: Arguments were not enough!", socket=self.socket)
			return
		cmd, tohelp = self.command.split(" ")
		if (tohelp not in self.instance.inst.inst.instanceOfClass.remote_based_commands):
			if self.website_instance == True:
				return {"msg":"Command is not located!"}
			self.socket_handler.send_normal_pkt(data=b"error: Command not found!", socket=self.socket)
			return
		sel = self.instance.inst.inst.instanceOfClass.remote_based_commands[tohelp]
		parsed = "Type: %s\r\x0AType2: %s"%("Argumentative" if "[argumentative]" in sel else "Non-argumentative", "Permission required" if "[permissive]" in sel else "Non-permission required")  + "\r\x0A%s"%(sel)
		if self.website_instance == True:
			return {"msg":parsed}
		self.socket_handler.send_normal_pkt(data=parsed.encode("utf-8", errors="ignore"), socket=self.socket)
		return

	def download_webbased(self:object, wuuid=""):
		from utils.website.server_side import create_packet
		if self.arg == None:
			return {"msg":"req.down"}
		if wuuid not in self.instance.inst.inst.instanceOfClass.logged_client_sessions:
			return {"msg":"Unauthorized access!"}
		args = [bob.split("=")[1] for bob in self.arg.split("&") if "=" in bob]
		if self.website_instance == True:
			file = args[0]
		dir = self.instance.inst.inst.instanceOfClass.logged_client_sessions[wuuid]["directory"]
		if isinstance(dir, list) == True:
			dir = dir[0][0]
		path = dir + "/" + file
		if exists(path) == False:
			return {"msg":"File does not exists ..."}
		self.socket_handler.send_file(file=path, socket=self.socket, header=create_packet(code="200",  content=b"", xmessage=dumps({"msg":"File fetched!"}), location=path, ymessage="OK", date=self.instance.inst.inst.getLocalTime(), reduce_lines=False, content_disposition=True, filename=file, type="multipart/form-data"))

	def login_auto_client(self:object, wuuid=""):
		if self.website_instance == True:
			return {"msg":"Login auto is disabled on the frontend ..."}
		from base64 import b64encode, b64decode
		self.socket_handler.send_normal_pkt(data=b"pub?", socket=self.socket)
		receivePub = self.socket_handler.readClient(buffer=4096, sockaddr=self.socket).decode("utf-8", errors="ignore")
		if self.instance.inst.inst.is_json(receivePub, False) == False:
			self.socket_handler.send_normal_pkt(data=b"error: Invalid JSON message!", socket=self.socket)
			return
		receivePub = loads(receivePub)
		receivePub, datetime, action = receivePub["pub"], receivePub["datetime"], receivePub["action"]
		sel = self.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="SELECT account_id, encrypted_msg, priv FROM __db__.auto_auth WHERE pub='%s'"%(receivePub))._fetch()
		if action != "login.action" or len(sel) == 0:
			self.socket_handler.send_normal_pkt(data=b"error: Invalid operation!", socket=self.socket)
			return
		account_id, encrypted_msg, priv = sel[0]
		obj = PKCS1_OAEP.new(RSA.importKey(b64decode(priv.encode("utf-8", errors="ignore"))))
		try:
			decr = obj.decrypt(b64decode(encrypted_msg.encode("utf-8", errors="ignore"))).decode("utf-8", errors="ignore")
		except:
			self.socket_handler.send_normal_pkt(data=b"error: error occured, while decrypting data. Are you sure you send the correct data?", socket=self.socket)
			return
		account_id, type, addr = decr.split("_")
		account_id = account_id.split("::")[0].split("Account-")[1].strip()
		fet = self.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="SELECT username, password FROM __db__.user_ftsrv_accounts WHERE account_id='%s'"%(account_id))._fetch()
		if len(fet) == 0:
			self.socket_handler.send_normal_pkt(data=b"error: Invalid username and password. That is an expected error! Please, try again!", socket=self.socket)
			return
		username, password = fet[0]
		anon = self.check_anon_admin_like(username, password)
		if anon == False:
			return
		self.instance.inst.inst.instanceOfClass.logged_client_sessions[self.fetch_uuid()] = {"logged":True, "account_id":fet[0][0], "datetime":self.instance.inst.inst.getLocalTime(), "username":username,
		"directory":self.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="SELECT start_directory FROM __db__.account_rules WHERE account_id='%s'"%(account_id))._fetch()[0][0], "anon":anon, "logging":False, "typeacc":self.find_typeacc(account_id, anon[0], anon[1])}
		self.socket_handler.send_normal_pkt(data=dumps({"token":self.fetch_uuid(), "account_user":username}).encode("utf-8", errors="ignore"), socket=self.socket)
		return
	
	def check_anon_admin_like(self:object, user:str, password:str, wuuid="") -> (object):
		sel = self.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="SELECT is_anon, active, active_admin, is_admin FROM __db__.user_ftsrv_accounts WHERE username='%s' AND password='%s'"%(user, password))._fetch()
		if len(sel) == 0:
			return ":nt", ":nt"
		anon, admin = int(sel[0][0]), int(sel[0][3])
		if anon == 1 and (sel[0][1] == 0 or self.instance.inst.inst.instanceOfClass.normalProperties["anon"]=="False"):
			if self.website_instance == True:
				return ":ap", ":ap"
			self.socket_handler.send_normal_pkt(data=b"error: critical error! Anonymous account cannot be interacted at this moment!", socket=self.socket)
			return None, None
		if admin == 1 and (sel[0][2] == 0 or self.instance.inst.inst.instanceOfClass.normalProperties["admin"]=="False"):
			if self.website_instance == True:
				return ":adp", ":adp"
			self.socket_handler.send_normal_pkt(data=b"error: critical error! Administrator account cannot be interacted at this moment!", socket=self.socket)
			return None, None
		return admin, anon
	
	def find_typeacc(self:object, account_id=None, is_admin=0, is_anon=0, wuuid="") -> (object, str):
		if is_admin == 1:
			typeacc = "System.Ftsrv/users/administrators"
		elif is_anon == 1:
			typeacc = "System.Ftsrv/users/anonymous_users"
		else:
			typeacc = "System.Ftsrv/users/user"
		return typeacc

	def get_account_id(self:object, user:str, password:str, wuuid="") -> (object, str, str):
		return self.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="SELECT account_id from __db__.user_ftsrv_accounts WHERE username='%s' AND password='%s'"%(user, password))._fetch()[0][0]

	def too_much(self:object, table:Type[str], limit:Type[int], to_unique:Type[tuple], wuuid=""):
		assert to_unique != () or isinstance(to_unique, tuple) != True
		sel = self.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="SELECT * FROM %s WHERE %s='%s'"%(table, to_unique[0], to_unique[1]))._fetch()
		if len(sel) >= limit:
			return True
		return False

	def show_users(self:object, wuuid=""):
		if self.authorize() == False or self.instance.inst.inst.instanceOfClass.logged_client_sessions[self.fetch_uuid()]["typeacc"] != "System.Ftsrv/users/administrators":
			self.socket_handler.send_normal_pkt(data=b"error: unauthorized access! User has 0 permissions to execute that command!", socket=self.socket)
			return
		sel = "\x0A" + "\x2D"*20 + "\x0A" + "\x0A".join(self.enumerate_user(account_id) for account_id in self.instance.inst.inst.instanceOfClass.logged_client_sessions) + "\x0A" + "\x2D"*20 + "\x0A" + "\x0A"
		self.socket_handler.send_normal_pkt(data=sel.encode("utf-8", errors="ignore"), socket=self.socket)

	def easter_egg(self:object, wuuid=""):
		self.socket_handler.send_normal_pkt(data=b"Hello from the team, :D!\n", socket=self.socket)
		return

	def enumerate_user(self:object,account_id:str, wuuid=""):
		if self.authorize() == False or self.instance.inst.inst.instanceOfClass.logged_client_sessions[self.fetch_uuid()]["typeacc"] != "System.Ftsrv/users/administrators":
			self.socket_handler.send_normal_pkt(data=b"error: unauthorized access! User has 0 permissions to execute that command!", socket=self.socket)
			return
		sels = self.instance.inst.inst.instanceOfClass.logged_client_sessions[account_id]
		act = "\x0A".join("%s=%s"%(bob, sels[bob]) for bob in sels)
		return act

	def get_file_size(self:object, wuuid="") -> (object):
		from os.path import isfile
		if self.arg == None:
			return {"msg":"req.form"}
		if self.authorize() == False and self.website_instance == False:
			self.socket_handler.send_normal_pkt(data=b"error: unauthorized access!", socket=self.socket)
			return
		if len(self.command.split(" ")) < 2 and self.website_instance == False:
			self.socket_handler.send_normal_pkt(data=b"error: too few arguments provided", socket=self.socket)
			return
		args = [bob.split("=")[1] for bob in self.arg.split("&") if "=" in bob]
		if self.website_instance == False:
			cmd, arg = self.command.split(" ")
		else:
			arg = args[0]
		directory = self.instance.inst.inst.instanceOfClass.logged_client_sessions[wuuid if wuuid != "" else self.fetch_uuid()]["directory"]
		if isinstance(directory, list) == True:
			directory = directory[0][0]
		sizeofs = {}
		for files in arg.split(","):
			if ":/" in files:
				mashup = files
			else:
				mashup = directory + "/" + files
			if exists(mashup) == False or isfile(mashup) == False:
				sizeofs[files] = "file does not exist!"
				continue
			sizeof = getsize(mashup)
			sizeofs[files] = "%.3f/kb, %d/b"%(sizeof/1000, sizeof)
		packet = "\x0A".join("%s = %s"%(bob, sizeofs[bob]) for bob in sizeofs)
		if self.website_instance == True:
			return {"msg":packet}	
		self.socket_handler.send_normal_pkt(data=(packet + "\x0A").encode("utf-8", errors="ignore"), socket=self.socket)
		return



	def top_connections(self:object, wuuid=""):
		if self.authorize() == True and self.instance.inst.inst.instanceOfClass.logged_client_sessions[self.fetch_uuid()]["typeacc"] != "System.Ftsrv/users/administrators":
			self.socket_handler.send_normal_pkt(data=b"error: unauthorized access! User has 0 permissions to execute that command!",socket=self.socket)
		if self.authorize() == False:
			self.socket_handler.send_normal_pkt(data=b"error: unauthorized access!", socket=self.socket)
			return
		try:
			arg = 5 if len(self.command.split(" ")) < 2 else int(self.command.split(" ")[1])
		except:
			arg = 5
		data = "\x2D"*20 + "\x0A" + "Total connections: %d (%d)"%(arg, len(self.instance.inst.inst.connectedList)) + "\x0A\x0A" + "\x0A".join("%s:%s -> %s"%(h[1][0], h[1][1], self.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="SELECT datetime FROM __db__.connections WHERE client='%s' AND port='%d'"%(h[1][0], h[1][1]))._fetch()[0][0]) for h in self.instance.inst.inst.connectedList[:arg]) + "\x0A" + "\x2D"*20 + "\x0A"
		self.socket_handler.send_normal_pkt(data=data.encode("utf-8", errors="ignore"), socket=self.socket)
		return

	def show_conns(self:object, wuuid=""):
		if self.authorize() == True and self.instance.inst.inst.instanceOfClass.logged_client_sessions[self.fetch_uuid()]["typeacc"] != "System.Ftsrv/users/administrators":
			self.socket_handler.send_normal_pkt(data=b"error: unauthorized access! User has 0 permissions to execute that command!", socket=self.socket)
			return
		if self.authorize() == False:
			self.socket_handler.send_normal_pkt(data=b"error: unauthorized access!", socket=self.socket)
			return
		self.socket_handler.send_normal_pkt(data=(self.instance.inst.inst.show_connections()).encode("utf-8", errors="ignore"), socket=self.socket)
		return

	def typeacc(self:object, wuuid="") -> (object):
		if self.website_instance == True:
			return {"msg":self.instance.inst.inst.instanceOfClass.logged_client_sessions[wuuid]["typeacc"] + "   " + wuuid + "   " + self.instance.inst.inst.instanceOfClass.logged_client_sessions[wuuid]["username"]}
		self.socket_handler.send_normal_pkt(data=(self.instance.inst.inst.instanceOfClass.logged_client_sessions[self.fetch_uuid()]["typeacc"] + "   " + self.fetch_uuid() + "   " + self.instance.inst.inst.instanceOfClass.logged_client_sessions[self.fetch_uuid()]["username"]).encode("utf-8", errors="ignore"), socket=self.socket)
		return

	def delete_directory(self:object, wuuid=""):
		from os import rmdir as remove
		if self.authorize() == False:
			self.socket_handler.send_normal_pkt(data=b"error: unauthorized access!", socket=self.socket)
		directory = self.instance.inst.inst.instanceOfClass.logged_client_sessions[self.fetch_uuid()]["directory"]
		if isinstance(directory, list) == True:
			directory = directory[0][0]
		if len(self.command.split(" ")) < 2:
			self.socket_handler.send_normal_pkt(data=b"error: too few arguments provided!", socket=self.socket)
			return
		cmd, dirs = self.command.split(" ")
		info = {}
		dirs = "/".join(bob for bob in dirs.split("/") if bob != "" or len(bob) != 0)
		for directories in dirs.split(","):
			try:
				if self.file_control(file=directories, instance_class=self, wuuid=wuuid).is_dir_permissable() == False:
					info[directories] = "error: user has 0 permissive for deleting that directory"
				remove(directory + "/%s"%(directories))
			except Exception as f:
				info[directories] = "error: Error, while deleting a directory! Reason>> %s"%(f)
				continue
			info[directories] = "Directory deleted!"
		info = "\x2D" * 20  + "\x0A" + "[operation.file_deletion]" + "\x0A" + "\x0A".join("%s -> %s"%(data, info[data]) for data in info) + "\x0A" + "\x2D"*20
		self.socket_handler.send_normal_pkt(data=info.encode("utf-8", errors="ignore"), socket=self.socket)

	def create_directory(self:object, wuuid=""):
		from os import mkdir
		if self.arg == None and self.website_instance == True:
			return {"msg":"req.form"}
		if self.authorize() == False and self.website_instance == False:
			self.socket_handler.send_normal_pkt(data=b"error: unauthorized access!", socket=self.socket)
			return
		selected_args = [bob.split("=")[1] for bob in self.arg.split("&") if "=" in bob]
		properties = self.instance.inst.inst.instanceOfClass.logged_client_sessions[wuuid if wuuid != "" else self.fetch_uuid()]["account_id"]
		sel = self.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="SELECT createDir FROM __db__.account_rules WHERE account_id='%s'"%(properties))._fetch()[0][0]
		if sel != 1:
			if self.website_instance == True:
				return {"msg":"That operation is deactivated as a feature on this account! Please, inform your administrator if you think that's an error ..."}
			self.socket_handler.send_normal_pkt(data=b"error: user has 0 permissive for creating directories.", socket=self.socket)
			return
		if len(self.command.split(" ")) < 2 and self.website_instance == False:
			self.socket_handler.send_normal_pkt(data=b"error: too few arguments provided!", socket=self.socket)
			return
		if 1 <= len(selected_args) >= 10:
			return {"msg":"Too few or too much arguments provided! It is required N to be -> 1 <= N <= 10"}
		if self.website_instance == False:
			cmd, dirs = self.command.split(" ")
		else:
			dirs = selected_args[0]
		dir_ = self.instance.inst.inst.instanceOfClass.logged_client_sessions[self.fetch_uuid() if wuuid == "" else wuuid]["directory"]
		if isinstance(dir_, list) == True:
			dir_ = dir_[0][0]
		info = {}
		for directories in dirs.split(","):
			try:
				mkdir(dir_ + "/%s"%(directories))
			except Exception as f:
				info[dir_+ "/" + directories] = "Error, while creating a directory! Reason>> %s"%(f)
				continue
			info[dir_ + "/" + directories] = "Directory created!"
		for keys in info:
			if info[keys].startswith("Error"):
				continue
			directory_key = str(uuid4())
			self.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="INSERT INTO path_securities(client_uuid, security_uuid, path) VALUES ('%s', '%s', '%s');"%(self.instance.inst.inst.instanceOfClass.logged_client_sessions[self.fetch_uuid()]["account_id"], directory_key, keys))._insert()
		info = "\x2D" * 20  + "\x0A" + "[operation.file_deletion]" + "\x0A" + "\x0A".join("%s -> %s"%(data, info[data]) for data in info) + "\x0A" + "\x2D"*20
		if self.website_instance == True:
			return {"msg":info}
		self.socket_handler.send_normal_pkt(data=info.encode("utf-8", errors="ignore"), socket=self.socket)

	def request_file_deletion(self:object, wuuid="") -> (object):
		from os import remove
		if self.arg == None and self.website_instance == True:
			return {"msg":"req.form"}
		if self.authorize() == False and self.website_instance == False:
			self.socket_handler.send_normal_pkt(data=b"error: unauthorized access!", socket=self.socket)
			return
		if len(self.command.split(" ")) < 2 and self.website_instance == False:
			self.socket_handler.send_normal_pkt(data=b"error: too few arguments!", socket=self.socket)
			return
		args = [bob.split("=")[1] for bob in self.arg.split("&") if "=" in bob]
		if self.website_instance == False:
			command, file = self.command.split(" ")
		else:
			file = args[0]
		info = {}
		directory = self.instance.inst.inst.instanceOfClass.logged_client_sessions[wuuid if wuuid != "" else self.fetch_uuid()]["directory"]
		if isinstance(directory, list) == True:
			directory = directory[0][0]
		for files in file.split(","):
			files = files.strip()
			if exists(directory + "/" + files) == False:
				info[files] = "Could not delete account! Does not exist!"
			try:
				if self.file_control(file=files, instance_class=self, wuuid=wuuid).is_file_permissable() == False:
					info[files] = "Could not delete file! 0 PERMISSIONS."
					continue
				remove(directory + "/" + files)
			except Exception as f:
				info[files] = "Could not delete account! %s"%(f)
				continue
			info[files] = "Deleted successfully!"
			self.file_read_log(files)
		info = "\x2D" * 20  + "\x0A" + "[operation.file_deletion]" + "\x0A" + "\x0A".join("%s -> %s"%(data, info[data]) for data in info) + "\x0A" + "\x2D"*20
		if self.website_instance == True:
			return {"msg":info}
		self.socket_handler.send_normal_pkt(data=info.encode("utf-8", errors="ignore"), socket=self.socket)
		return

	def trigger_log(self:object, wuuid="") -> (object):
		if self.authorize() == False and self.website_instance == False:
			self.socket_handler.send_normal_pkt(data=b"error: unauthorized access!", socket=self.socket)
			return False
		self.instance.inst.inst.instanceOfClass.logged_client_sessions[wuuid if wuuid != "" else self.fetch_uuid()]["logging"] = True if self.instance.inst.inst.instanceOfClass.logged_client_sessions[wuuid if wuuid != "" else self.fetch_uuid()]["logging"] == False else False
		actualpack = ("Log is turned to '%r'!"%(self.instance.inst.inst.instanceOfClass.logged_client_sessions[wuuid if wuuid != "" else self.fetch_uuid()]["logging"]))
		if self.website_instance == True:
			return {"msg":actualpack}
		self.socket_handler.send_normal_pkt(data=actualpack.encode("utf-8", errors="ignore"), socket=self.socket)

	def ghashf(self:object, wuuid="") -> (object):
		if self.arg == None and self.website_instance == True:
			return {"msg":"req.form"}
		if self.authorize() == False and self.website_instance == False:
			self.socket_handler.send_normal_pkt(data=b"error: unauthorized access!", socket=self.socket)
			return
		if len(self.command.split(" ")) < 2 and self.website_instance == False:
			self.socket_handler.send_normal_pkt(data=b"error: too few arguments!", socket=self.socket)
			return
		args = [bob.split("=")[1] for bob in self.arg.split("&") if "=" in bob] # for frontend ONLY sha512!
		hashAlgo = "sha512" if len(self.command.split(" ")) < 3 or self.website_instance == True else self.command.split(" ")[2]
		if self.website_instance == False:
			command, file = self.command.split(" ")[:2]
		else:
			file = args[0]
		algorithms = {"sha256":hashlib.sha256, "sha512":hashlib.sha512, "md5":hashlib.md5}
		directory = self.instance.inst.inst.instanceOfClass.logged_client_sessions[wuuid if wuuid != "" else self.fetch_uuid()]["directory"]
		if isinstance(directory, list) == True:
			directory = directory[0][0]
		if hashAlgo not in algorithms:
			self.socket_handler.send_normal_pkt(data=b"error:hash algorithm not found!", socket=self.socket)
			return
		output = {}
		for files in file.split(","):
			if ":/" in files:
				files = files.strip()
			else:
				files = directory + "//" + files.strip()
			if exists(files) == False:
				output[files] = "File not found!"
				continue
			if getsize(files) >= 1000000000:
				output[files] = "Size too big! Size 1 > size < 1"
				continue
			method = algorithms[hashAlgo]
			method = method()
			method.update(self.instance.inst.inst.stream_little_File(file=files))
			output[files] = method.hexdigest()
		method = "\x0A".join("%s -> Hash=%s"%(bob, output[bob]) for bob in output)
		if self.website_instance == True:
			return {"msg":"\r\x0A%s\r\x0A\r\x0A"%(method)}
		self.socket_handler.send_normal_pkt(data=("\r\x0A%s\r\x0A\r\x0A"%(method)).encode("utf-8", errors="ignore"), socket=self.socket)
		self.file_read_log(file, wuuid)

	def dir_access_log(self:object, file:str, wuuid=""):
		unwanted = wuuid if wuuid != "" else self.fetch_uuid()
		account_id = self.instance.inst.inst.instanceOfClass.logged_client_sessions[unwanted]["account_id"]
		self.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="INSERT INTO __db__.user_action(client, account_id, file, datetime, note) VALUES ('%s', '%s', '%s', '%s', 'user accessed directory %s')"%(unwanted, account_id, file, self.instance.inst.inst.getLocalTime(), file))._insert()

	def file_read_log(self:object, file:str, wuuid=""):
		account_id = self.instance.inst.inst.instanceOfClass.logged_client_sessions[wuuid if wuuid != "" else self.fetch_uuid()]["account_id"]
		self.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="INSERT INTO __db__.user_action(client, account_id, file, datetime) VALUES ('%s', '%s', '%s', '%s')"%(self.fetch_uuid(), account_id, file, self.instance.inst.inst.getLocalTime()))._insert()

	def send_first_path(self:object, wuuid="") -> (object):
		if self.authorize() == False and self.website_instance == False:
			self.socket_handler.send_normal_pkt(data=b"error: unauthorized access!", socket=self.socket)
			return False
		enm = self.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="SELECT start_directory FROM __db__.account_rules WHERE account_id='%s'"%(self.instance.inst.inst.instanceOfClass.logged_client_sessions[wuuid if wuuid != "" else self.fetch_uuid()]["account_id"]))._fetch()[0][0]
		if self.website_instance == True:
			return {"msg":"Start path>> %s"%(enm)}
		self.socket_handler.send_normal_pkt(data=("Start path>> %s"%(enm)).encode("utf-8", errors="ignore"), socket=self.socket)
		return False

	def show_connections_available(self:object, wuuid="", *args) -> (object, list):
		if self.website_instance == True:
			return {"msg":"Total '%d' connections are alive"%(len(self.instance.inst.inst.instanceOfClass.alive_sessions))}
		self.socket_handler.send_normal_pkt(data=("Total '%d' connections are alive"%(len(self.instance.inst.inst.instanceOfClass.alive_sessions))).encode("utf-8", errors="ignore"), socket=self.socket)
		return

	def logout_user(self:object, wuuid=""):
		# only and only when the statement is True.
		if self.website_instance == True:
			del self.instance.inst.inst.instanceOfClass.logged_client_sessions[wuuid]
			return {"msg":"logout.True"}
		if self.authorize() == False:
			self.socket_handler.send_normal_pkt(data=b"error: unauthorized access!", socket=self.socket)
			return False
		del self.instance.inst.inst.instanceOfClass.logged_client_sessions[self.fetch_uuid()]
		self.instance.inst.inst.instanceOfClass.logged_client_sessions[self.fetch_uuid()] = {"account_id":"", "logged":False, "typeacc":"System.Ftsrv/users/guest", "username":"guest"}
		self.socket_handler.send_normal_pkt(data=b"logout", socket=self.socket)
		self.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="INSERT INTO __db__.logout_errors(client_id, message, datetime) VALUES ('%s','Reason>> user logout.','%s')"%(self.fetch_uuid(), self.instance.inst.inst.getLocalTime()))._insert()

	def account_operation_auth(self:object, column:str, wuuid="") -> (object, str):
		read = self.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="SELECT %s FROM __db__.account_rules WHERE account_id='%s'"%(column, self.instance.inst.inst.instanceOfClass.logged_client_sessions[self.fetch_uuid()]["account_id"]))._fetch()
		return False if len(read) == 0 or int(read[0][0]) != 1 else True

	def fs_dir(self:object, wuuid=""):
		print(self.fetch_uuid())
		if (self.fetch_uuid() not in self.instance.inst.inst.instanceOfClass.logged_client_sessions or self.account_operation_auth(column="browse_files") == False) and self.website_instance == False:
			self.socket_handler.send_normal_pkt(b"error: unauthorized access!", self.socket_handler.sock)
			return False
		fs = self.instance.inst.inst.instanceOfClass.logged_client_sessions[self.fetch_uuid() if wuuid == "" else wuuid]["directory"]
		args = []
		try:
			if self.arg != None:
				args = [bob.split("=")[1] for bob in self.arg.split("&") if bob != None and "=" in bob]
		except:
			return {"msg":"Error occured while parsing data ... Make sure that in the 'url' you have provided correct arguments!"}
		if isinstance(fs, list) == True:
			fs = fs[0][0]
		if len(args) == 0:
			data = "\x0A\x0A" + "Path: %s"%(fs) + "\x0A" + "\x0A".join(fs + "/" + bob for bob in listdir(fs)) + "\x0A\x0A"
		else:
			data = self.file_control.webbased_url_static(arguments=args, current_listed=listdir(fs), operation="fs_dir", cwd=fs)
			if data == False:
				return {"msg":"Error occcured, while processing data ..."} # in case if an error occurs, while processing data from client.
		if self.website_instance == True:
			return {"msg":data}
		self.socket_handler.send_normal_pkt((data).encode("utf-8", errors="ignore"), self.socket_handler.sock, True, True)
		return False

	def check_size_current_dir(self:object, wuuid=""):
		#print(self.command)
		uuid = self.fetch_uuid()
		if (uuid not in self.instance.inst.inst.instanceOfClass.logged_client_sessions or self.account_operation_auth(column="browse_files") == False) and self.website_instance == False:
			self.socket_handler.send_normal_pkt(data=b"error: unauthorized access!", socket=self.socket)
			return False
		directory = self.instance.inst.inst.instanceOfClass.logged_client_sessions[self.fetch_uuid()]["directory"] if wuuid == "" else self.instance.inst.inst.instanceOfClass.logged_client_sessions[wuuid]["directory"]
		if isinstance(directory, list) == True:
			directory = directory[0][0]
		if exists(directory) == False:
			if self.website_instance == False:
				self.socket_handler.send_normal_pkt(data=b"error: location not found!", socket=self.socket)
				return False
			return {"msg":"Location not found! '%s'"%(directory)}
		actual = [(getsize(directory + "/" + bob), bob, getsize(directory + "/" + bob)) for bob in listdir(directory) if isfile(directory + "/" + bob)]
		get_Files = "\x0APath: %s\x0A"%(directory) + "\x0A" + ("\x0A".join("%s - %f/kb"%(file, size/1000000) for size, file, size_2 in actual)) + "\x0A"
		if len(get_Files) == 0:
			get_Files = "error: files not found in the cd."
		actual_s = self.command.split(" ")
		if len(actual_s) == 1:
			actual_s.append("/fs")
		data = ""
		kakvo = [bob[2] for bob in actual]
		used = []
		for times in actual_s:
			if times.strip() in used:
				continue
			match times.strip():
				case "/a":
					direct = sum(kakvo)/len(kakvo)
					data += "\x0A\x0A" + "Average >> %d/b, %.2f/kb."%(direct, direct/1000000) + "\x0A\x0A"
				case "/fs":
					direct = sum(kakvo)
					data += "\x0A\x0A" + "Sum >> %d/b, %.2f/kb."%(direct, direct/1000000) + "\x0A\x0A"
				case "/bf":
					bigger = []
					file = ""
					for file_path, file_name, size in actual:
						if len(bigger) != 0 and bigger[0] < size:
							bigger[0] = size
							file = file_name
							continue
						bigger.append(size)
					if len(bigger) != 0:
						data += "\x0A\x0A" + "Biggest file in current working directory>> %s, size>> %.2f/kb."%(file, bigger[0]/1000000) + "\x0A\x0A"
				case "/sf":
					smallest = []
					file = ""
					for file_path, file_name, size in actual:
						if len(smallest) != 0 and smallest[0] > size:
							smallest[0] = size
							file = file_name
							continue
						smallest.append(size)
					if len(smallest) != 0:
						data += "\x0A\x0A" + "Smallest file in current working directory>> %s, size>> %.2f/kb."%(file, smallest[0]/1000000) + "\x0A\x0A"
				case other:
					pass
			used.append(times.strip())
		if len(data) != 0:
			get_Files += ("\x2D"*20) + "\x0A" + data + "\x0A" + ("\x2D"*20)
		if len(get_Files) >= 16384:
			return {"msg":"Current directory is way too big!"}
		if self.website_instance == True:
			return {"msg":get_Files}
		self.socket_handler.send_normal_pkt(data=get_Files.encode("utf-8", errors="ignore"), socket=self.socket, flag=True if wuuid == "" else False)
		return False

	def check_directory_permissions(self:object, path:str, defined_path:str, wuuid="") -> (object, str):
		if isinstance(defined_path, list) == True:
			defined_path = defined_path[0][0]
		act = self.instance.inst.inst.instanceOfClass.logged_client_sessions[wuuid] if wuuid != "" else self.instance.inst.inst.instanceOfClass.logged_client_sessions[self.fetch_uuid()]
		fetch = self.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="SELECT fixeddir FROM __db__.account_rules WHERE account_id='%s'"%(act["account_id"]))._fetch()
		if ":/" not in path:
			defined_path = defined_path + "/%s"%(path)
		if defined_path.strip() not in fetch[0][0].split(",") and fetch[0][0] != "":
			return False
		dota = [bob.lower() for bob in self.instance.inst.inst.instanceOfClass.firewallProperties["locked_dirs"].split(",")]
		for paths in dota:
			if ("*" in paths and paths.split("*")[0] in path.lower() or paths.split("*")[0] in path.lower() + "/") and act["typeacc"] != "System.Ftsrv/users/administrators":
				return False
		if defined_path in dota or path in dota:
			return False
		return True

	def fetch_lsl(self:object, wuuid:str) -> (object, str):
		if wuuid == "" and self.website_instance == False:
			return self.instance.inst.inst.instanceOfClass.logged_client_sessions[self.fetch_uuid()]
		return self.instance.inst.inst.instanceOfClass.logged_client_sessions[wuuid]

	# change directory persistence on current device, if user desire whatever, bla, bla.
	def change_dir(self:object, wuuid=""):
		if self.arg == None and self.website_instance == True:
			return {"msg":"req.form"}
		args = [bob for bob in self.arg.split("&")]
		locate = [bob.split("=")[1] for bob in args if "cmd" in bob and "=" in bob]
		if (self.authorize() == False or self.account_operation_auth(column="movdir") == False) and self.website_instance == False:
			self.socket_handler.send_normal_pkt(data=b"error: unauthorized access!", socket=self.socket)
			return False
		if len(locate) == 0:
			return {"msg":"User sent an unknown command. Please, make sure that the command IS understood by the server."}
		if len(self.command.split(" ")) < 2 and self.website_instance == False:
			self.socket_handler.send_normal_pkt(data=b"error: incorrect argument in command!", socket=self.socket)
			return False
		#fetch = self.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="SELECT fixeddir FROM __db__.account_rules WHERE account_id='%s'"%(self.instance.inst.inst.instanceOfClass.logged_client_sessions[self.fetch_uuid()]["account_id"]))._fetch()
		if self.website_instance == False:
			cmd, argument = self.command.split(" ")
		else:
			argument = locate[0]
		directory = self.fetch_lsl(wuuid)["directory"]
		if isinstance(directory, list) == True:
			directory = directory[0][0]
		if ":/" in argument:
			argument = argument
		else:
			argument = directory + "/" + argument
		argument = "/".join(bob for bob in argument.split("/") if bob != "" or len(bob) != 0)
		if "." in argument.split("/")[len(argument.split("/"))-1]:
			return {"msg":"Incorrect directory has been sent from client '%s' ... Make sure that you have validated a correct path!"%(argument)}
		if self.check_directory_permissions(argument.strip(), directory, wuuid) == False or self.file_control(argument.strip(), self, wuuid=wuuid).is_dir_permissable() == False:
			if self.website_instance == False:
				self.socket_handler.send_normal_pkt(data=b"error: unable to access given directory!", socket=self.socket)
				return
			return {"msg":"Access forbidden while reaching that destination on the server ..."}
		if exists(argument) == False:
			if self.website_instance == False:
				self.socket_handler.send_normal_pkt(data=b"error: directory does not exist!", socket=self.socket)
				return
			return {"msg":"User tried to accessed a directory that was not located on the server ..."}
		old_ = self.fetch_lsl(wuuid)["directory"][0]
		if isinstance(old_, tuple) == True:
			old_ = old_[0]
		if wuuid == "":
			self.instance.inst.inst.instanceOfClass.logged_client_sessions[self.fetch_uuid()]["directory"] = argument
		else:
			self.instance.inst.inst.instanceOfClass.logged_client_sessions[wuuid]["directory"] = argument
		if self.website_instance == False and wuuid == "":
			self.socket_handler.send_normal_pkt(data=("Changed directory to -> %s!"%(self.fetch_lsl(self.fetch_uuid())["directory"])).encode("utf-8", errors="ignore"), socket=self.socket)
		self.dir_access_log(file=argument, wuuid=wuuid) # will call that method from here, where the packet is already send. Thus the client to not receive the packet not as expected.
		if self.website_instance == True:
			return {"msg":"User successfully changed directory to '%s'"%(argument)}
		return False
		

	def current_dir(self:object, wuuid=""):
		if self.authorize() == False and self.website_instance == False:
			self.socket_handler.send_normal_pkt(data=b"error: unauthorized access!", socket=self.socket)
			return False
		direct_ = self.instance.inst.inst.instanceOfClass.logged_client_sessions[wuuid if wuuid != "" else self.fetch_uuid()]["directory"]
		if isinstance(direct_, list) == True:
			direct_ = direct_[0][0]
		if self.website_instance == True:
			return {"msg":direct_}
		self.socket_handler.send_normal_pkt(data=direct_.encode("utf-8", errors="ignore"), socket=self.socket)
		return False

	def fetch_uuid(self:object, wuuid=""):
		xz = self.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="SELECT session_id FROM __db__.connections WHERE client='%s' AND port=%d"%(self.client_data[0], self.client_data[1]))._fetch()
		if len(xz) == 0:
			return None
		return xz[0][0]

	def authorize(self:object, wuuid=""):
		#print(self.fetch_uuid(), self.instance.inst.inst.instanceOfClass.logged_client_sessions)
		if self.fetch_uuid() not in self.instance.inst.inst.instanceOfClass.logged_client_sessions:
			return False
		if "logged" not in self.instance.inst.inst.instanceOfClass.logged_client_sessions[self.fetch_uuid()] or self.instance.inst.inst.instanceOfClass.logged_client_sessions[self.fetch_uuid()]["logged"] != True:
			return False
		return True

	def current_user(self:object, wuuid=""):
		# "wuuid" IS an essential aragument, if website_instance is actually with a True value.
		#assert wuuid != "" and self.website_instance == True
		if self.authorize() == False and self.website_instance == False:
			self.socket_handler.send_normal_pkt(data=b"error: unauthorized access!", socket=self.socket)
			return False
		log = self.instance.inst.inst.instanceOfClass.logged_client_sessions
		if wuuid != "":
			uid = wuuid
		else:
			uid = self.fetch_uuid()
		log = log[uid]
		selInfo = self.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="SELECT datetime_created FROM __db__.user_ftsrv_accounts WHERE account_id='%s'"%(log["account_id"]))._fetch()
		append_files, remove_files, startdir, fetch_files , account_usage_per_clients  = self.instance.inst.inst.instanceOfClass.database(db="ftsrv ", syntax="SELECT append_files, remove_files, start_directory, fetch_files, account_usage_per_clients FROM __db__.account_rules WHERE account_id='%s'"%(log["account_id"]))._fetch()[0]
		text = "\x2D" * 20 + ("\r\x0A[Account information]\r\x0AUsername: %s\r\x0ADatetime logged: %s\r\x0ADatetime-created: %s\r\x0AType of user: %s\x0A\r\x0A"%(log["username"], log["datetime"], selInfo[0][0], "Anon" if log["anon"] == True else "Normal user") + "\x2D"*20 + "\x0A[Account rules]\x0A" + "append_files=%s\x0Aremove_files=%s\x0Astartdir=%s\x0Afetch_files=%s\x0Aaccount_usage_per_clients=%s\x0A"%(append_files, remove_files, startdir, fetch_files , account_usage_per_clients)) + "\x2D"*20 + "\x0A\x0A"
		if self.website_instance == True:
			return {"msg":text}
		self.socket_handler.send_normal_pkt(data=(text).encode("utf-8", errors="ignore"), socket=self.socket)
		return False


	def time_(self:object, wuuid=""):
		items = {"month":{1:"Jan", 2:"Feb", 3:"Mar", 4:"Apr", 5:"May", 6:"Jun", 7:"Jul", 8:"Aug", 9:"Sep", 10:"Oct", 11:"Nov", 12:"Dec"}, "week":{0:"Mon", 1:"Tue", 2:"Wed", 3:"Thu", 4:"Fri", 5:"Sat", 6:"Sun"}}
		year, monthn, dayn, day, hour, minute, sec = datetime.now().year, items["month"][datetime.now().month], items["week"][datetime.now().weekday()],datetime.now().day, datetime.now().hour, datetime.now().minute, datetime.now().second
		text = "%d %s %d %s, %d:%d:%d"%(year, monthn, day, dayn, hour, minute, sec)
		if self.website_instance == True:
			return {"msg":text}
		return text

	def hashlib_(self:object, target:bytes, wuuid="") -> (bytes):
		mod = sha512()
		mod.update(target)
		return mod.hexdigest()

	def user_handler(self:object, wuuid=""):
		if self.website_instance == True:
			return {"msg":"This type of login is disabled on the frontend ..."}
		if self.authorize() == True and self.instance.inst.inst.instanceOfClass.logged_client_sessions[self.fetch_uuid()]["logged"] == True:
			self.socket_handler.send_normal_pkt(data=b"error: there's already a session!", socket=self.socket)
			return
		self.socket_handler.send_normal_pkt(data=b"login.username", socket=self.socket)
		user = self.socket_handler.readClient(buffer=4096, sockaddr=self.socket).decode("utf-8", errors="ignore")
		if len(self.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="SELECT * FROM __db__.user_ftsrv_accounts WHERE username='%s'"%(user))._fetch()) == 0:
			self.socket_handler.send_normal_pkt(data=b"error: Incorrect username", socket=self.socket)
			self.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="INSERT INTO __db__.login_log_client(account_id, client_id, datetime, note, host) VALUES ('%s', '%s', '%s', '%s', '%s')"%(self.fetch_uuid(), "not logged", self.instance.inst.inst.getLocalTime(), "Client failed logging in!", self.instance.inst.data[0][0]))._insert()
			return False
		self.socket_handler.send_normal_pkt(data=b"login.password", socket=self.socket)
		password = self.hashlib_(self.socket_handler.readClient(buffer=4096, sockaddr=self.socket))
		returnout = self.check_authorize(user, password)
		if returnout == False and self.inc == True:
			self.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="INSERT INTO __db__.login_log_client(account_id, client_id, datetime, note, host) VALUES ('%s', '%s', '%s', '%s', '%s')"%(self.fetch_uuid(), "not logged", self.instance.inst.inst.getLocalTime(), "Client failed logging in!", self.instance.inst.data[0][0]))
			self.socket_handler.send_normal_pkt(data=b"error: Login attempt failed, due to incorrect username/password.", socket=self.socket)
			self.inc = None
			return False
		elif returnout == False:
			return False
		self.socket_handler.send_normal_pkt(data=dumps({"token":returnout, "account_user":user}).encode("utf-8", errors="ignore"), socket=self.socket)

	def check_authorize(self:object, user:str, password:str, wuuid="") -> (str, str):
		account_id = self.fetch_uuid()
		typeacc = ""
		anon, admin = self.check_anon_admin_like(user=user, password=password)
		if anon == None or admin == None:
			self.inc = True
			return False
		typeacc = self.find_typeacc(account_id, anon, admin)
		accid = self.get_account_id(user=user, password=password)
		self.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="INSERT INTO __db__.login_log_client(account_id, client_id, host, datetime, note) VALUES ('%s', '%s', '%s', '%s', '%s')"%(accid, account_id,self.instance.inst.data[0][0], self.instance.inst.inst.getLocalTime(), "Client logged in as %s!"%(user)))._insert()
		directory = self.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="SELECT start_directory FROM __db__.account_rules WHERE account_id='%s'"%(accid))._fetch()
		self.instance.inst.inst.instanceOfClass.logged_client_sessions[account_id] = {"logged":True, "account_id":accid, "datetime":self.instance.inst.inst.getLocalTime(), "username":user, "directory":directory, "anon":anon, "logging":False, "typeacc":typeacc}
		return account_id