from os.path import isfile, getsize
from typing import Type, Union


class file_control(object):
	def __init__(self:object, file:str, instance_class:object, wuuid:str) -> (str):
		self.file = file; self.instance_class = instance_class; self.wuuid = wuuid

	def is_file_permissable(self:object) -> (object):
		fil = self.instance_class.instance.inst.inst.instanceOfClass.normalProperties["forbiddenFiles"]
		if (self.file in fil.split(",")):
			return False

	def is_dir_permissable(self:object) -> (object):
		if self.wuuid == "":
			client_uuid = self.instance_class.instance.inst.inst.instanceOfClass.logged_client_sessions[self.instance_class.fetch_uuid()]["account_id"] # fetch the account id.
		else:
			client_uuid = self.instance_class.instance.inst.inst.instanceOfClass.logged_client_sessions[self.wuuid]["account_id"] # fetch the account id.
		select = self.instance_class.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="SELECT client_uuid, security_uuid FROM path_securities WHERE path='%s'"%(self.file))._fetch()
		if len(select) == 0:
			return True
		if select[0][0] != client_uuid and self.instance_class.website_instance == False:
			return False
		if self.file in select.split(","):
			return False
		return True

	@classmethod
	def webbased_url_static(cls, arguments:Type[list], current_listed:Type[list], operation:Type[str], cwd:str) -> (list, list, str):
		# max allowed arguments -> 2.
		if len(arguments) > 2:
			return False
		arg1, arg2 = arguments
		data = {}
		if operation == "fs_dir" and arg1 == "files2dict" or arg2 == "files2dict":
			for files in current_listed:
				if arg2 == "onlyfiles" or arg1 == "onlyfiles":
					if isfile(cwd + "/" + files) == True:
						data[files] = [cwd + "/" + files, str(getsize(cwd + "/" + files))]
		return data