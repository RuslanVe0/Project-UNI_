from functools import partial
from typing import Union, Type
from dataclasses import dataclass

class user_operations():
    def __init__(self:object, instance:object) -> (object):
        self.instance = instance; self.abstr = abstraction(self)
        
    def add_user_administrator(self:object, arguments:tuple, force:bool) -> (object, Union):
        
        """
Add user in the group of administrators. In order to prevent further problems - related with user authorization activites and user rules, the 'account_rules' rules table will be updated, 
by calling the method 'update_database_settings' in class - 'local_commands' where are the commands as well. It'll update them anyways, all.
        """

        if force == True and self.instance.is_admin_user() == False:
            return False, "[operation.add_user_administrator] Operation failed! That argument requires an administrative elvation!"
        cx, p2, p3 = self.abstr.parse(arguments, force=force, is_user=False, is_admin=True, is_anon=False)
        if cx == False:
            return False, p2
        self.instance.instanceOfClass.database(db="ftsrv", syntax="UPDATE __db__.user_ftsrv_accounts SET is_anon=0, is_admin=1, active_admin=1 WHERE username='%s' AND password='%s'"%(p3, p2))._insert()
        return True, "[operation.add_user_administrator] Operation completed! User '%s' is added to group admin (System.Ftsrv/users/administrators)."%(p3)
    
    def add_user_anon(self:object, arguments:tuple, force:bool) -> (object, Union):
        
        """
Add user in the group of anonymous. In order to prevent further problems - related with user authorization activites and user rules, the 'account_rules' rules table will be updated, 
by calling the method 'update_database_settings' in class - 'local_commands' where are the commands as well. It'll update them anyways, all.
        """

        if force == True and self.instance.is_admin_user() == False:
            return False, "[operation.add_user_anon] Operation failed! That argument requires an administrative elevation!"
        cx, p2, p3 = self.abstr.parse(arguments, force=force, is_user=False, is_admin=False, is_anon=True)
        if cx == False:
            return False, p2
        self.instance.instanceOfClass.database(db="ftsrv", syntax="UPDATE __db__.user_ftsrv_accounts SET is_anon=1, is_admin=0, active_admin=0 WHERE username='%s' AND password='%s'"%(p3, p2))._insert()
        return True, "[operation.add_user_anon] Operation completed! User '%s' is added to anonymous group (System.Ftsrv/users/anonymous)."%(p3)

    def add_user_user(self:object, arguments:tuple, force:bool) -> (object, Union):

        """
Add user in the group of users. In order to prevent further problems - related with user authorization activites and user rules, the 'account_rules' rules table will be updated, 
by calling the method 'update_database_settings' in class - 'local_commands' where are the commands as well. It'll update them anyways, all.
        """

        if force == True and self.instance.is_admin_user() == False:
            return False, "[operation.add_user_user] Operation failed! That argument requires an administrative elevation!"
        cx, p2, p3 = self.abstr.parse(arguments, force=force, is_user=True, is_admin=False, is_anon=False)
        if cx == False:
            return False, p2
        self.instance.instanceOfClass.database(db="ftsrv", syntax="UPDATE __db__.user_ftsrv_accounts SET is_anon=0, is_admin=0, active_admin=0 WHERE username='%s' AND password='%s'"%(p3, p2))._insert()
        return True, "[operation.add_user_user] Operation completed! User '%s' is added to users group (System.Ftsrv/users/users)."%(p3)
    
class abstraction(object):
    def __init__(self, instance):
        self.instance = instance
        pass
    
    def parse(self:object, arguments:tuple, force:bool, is_admin:bool, is_user:bool, is_anon:bool):
        arg = self.unpack(arguments)
        if isinstance(arg, tuple) == False:
            return False, str(arg), None
        if force == False:
            accountName, passwordlike = arg
        else:
            accountName = arg[0][0]
            passwordlike = self.instance.instance.instanceOfClass.database(db="ftsrv", syntax="SELECT password FROM __db__.user_ftsrv_accounts WHERE username='%s'"%(accountName))._fetch()
            if len(passwordlike) == 0:
                return False, "[operation.add_user_?] Operation failed! Reason>> account not found!", "???"
            passwordlike = passwordlike[0][0]
        cx, encr = self.check_account_authorization(accountName, passwordlike, is_admin=is_admin, is_user=is_user, is_anon=is_anon, encrypted=force)
        return cx, encr, accountName

    def check_account_authorization(self:object, accountName:str, passwordlike:str, is_admin:bool, is_user:bool, is_anon:bool, encrypted=False):
        sel = self.instance.instance.account_existence(account=(accountName, passwordlike), encrypted=encrypted)
        if sel == False:
            # in case if the requested account does not exist.
            return False, "[operation.add_user_administrator] Operation failed! Reason>> Either, the requested account does not exist or user requested invalid password!"
        match encrypted:
            case False:
                encr = self.instance.instance.encrypt_pass(accountName, passwordlike)
            case _: 
                encr = passwordlike
        if self.instance.instance.is_admin(accountName, encr) == True and is_admin==True:
            return False, "[operation.add_user_administrator] Operation failed! Reason>> user is already an administrator!"
        if is_user == True and self.instance.instance.is_user(accountName, encr) == True:
            return False, "[operation.add_user_user] Operation failed! Reason>> user is already an user!"
        if is_anon == True and self.instance.instance.is_anon(accountName, encr) == True:
            return False, "[operation.add_user_anon] Operation failed! Reason>> user is already an anonymous!"
        return True, encr
    
    def unpack(self:object, arguments:tuple) -> (tuple):
        assert arguments != []
        assert self.instance.instance != None
        if len(arguments) < 2:
            return "[operation.abstraction.unpack] Operation failed! Reason>> too few arguments provided!"
        return arguments[0], arguments[1] # so these are two elements that are getting indexed. First one is the account name, which will be used in order to know what account will be edited. And password in order to authorize. Force option requires administrative rights.

