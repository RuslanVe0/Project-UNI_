from functools import partial 
from typing import Union, Type
from dataclasses import dataclass
from numpy import array
from math import ceil

@dataclass
class tools(object):
    argument:Type[str]="no_arg"
    def __init__(self:object) -> (object):
        pass
    
    def parse_command(self:object, required_param_list:Type[list]=["accountname", "accountpassword"]) -> object:
        splitted = strop(self.argument).split(" ")[1:] # without the actual command, we don't really need it.
        elements = [splitted[0]] + splitted[1:]
        tryout = elements[1:]
        for index, element in enumerate(tryout, 1):
            if ("=" not in element):
                return "[operation.parse_command] Operation failed! Reason>> Invalid argument given!"
            if "=" in element and element.split("=")[0] in required_param_list:
                elements[index] = element.split("=")[1]
            elif "=" in element and element.split("=")[0] not in required_param_list:
                return "[operation.parse_command] Operation failed! Reason>> Provided an invalid argument!"
        return elements
    
    def remote_based_arguments(self:object, required_param_list:Type[list]=[]) -> (object, list):
        assert required_param_list != [] # Unexpected behavior.
        elements = self.argument.split(" ")[1:] # we don't need the command.
        new = []
        for element in elements:
            if "=" in element and element.split("=")[0] in required_param_list:
                new.append(element.split("=")[1])
        return new # return the prepared list.

    def json_many_in_much_find(self:object, dictionary:dict, tofind:(int, str, float, tuple, list), pf:[str]) -> (dict):
        """
Straightforward algorithm in order to find the main origin of a big data settled in a dictionary object.
"""
        found_data = []
        for keys in dictionary:
            if dictionary[keys][pf] == tofind:
                # in order to find the correct 'key'.
                found_data.append(keys)
        return found_data

    def is_int(self:object, is_integer:int): return isinstance(is_integer, int)

    def parse_json_join(self:object, json_doc:dict, arguments:[list, tuple]) -> (dict, object):
        # where arguments, arguments_k1 (where k1 means the index, where the index there should be two values in the actual list, where first value -> to_replace and second -> replacement).
        assert json_doc != {} or isinstance(json_doc, dict) != False
        assert arguments != () or arguments != [] or isinstance(arguments, tuple) != False or isinstance(arguments, list) != False
        for elements in arguments:
            toch, ch = elements
            json_doc[toch] = ch
        return json_doc

class strop(str):
    def __init__(self:object, value:str) -> (object, str): assert isinstance(value, str) == True; self.value = value; super().__init__()

    def split(self:object, delimiter:str): return super().split(delimiter)

    def char_array(self:object): return array([bob for bob in self.value], dtype="object")

    def char_bytearray(self:object): return array([ord(bytes(str(items), "utf-8")) for items in self.value], dtype="byte")