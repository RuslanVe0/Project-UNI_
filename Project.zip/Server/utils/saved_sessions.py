"""
This module is about creation, editing, and deletion of clients sessions.
Each attempt to save a session, the class in this module will be invoked - 'saved_sessions' in the desired envorinment.
"""
from base64 import b64encode, b64decode
from json import loads, dumps
from utils.tools import tools
from random import randint
from Cryptodome.PublicKey import RSA
from Cryptodome.Cipher import PKCS1_OAEP

class saved_sessions(object):
    def __init__(self:object, instanceofclass:object):
        self.instanceofclass = instanceofclass
    
    def is_allowed_saving(self:object):
        group = self.instanceofclass.instance.inst.inst.instanceOfClass.logged_client_sessions[self.instanceofclass.fetch_uuid()]["typeacc"]
        groupDesired = {"System.Ftsrv/users/administrators":self.instanceofclass.instance.inst.inst.instanceOfClass.adminProp,
		"System.Ftsrv/users/anonymous":self.instanceofclass.instance.inst.inst.instanceOfClass.anonProperties,
		"System.Ftsrv/users/user":self.instanceofclass.instance.inst.inst.instanceOfClass.account_rules}
        if group not in groupDesired:
            return False
        rep = groupDesired[group] # select the value in the dictionary above.
        if int(rep["savingAccount"]) == 0:
            return False
        return True

    def check_sessions(self:object):
        sel = self.instanceofclass.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="SELECT pub, datetime FROM auto_auth")._fetch()
        for elements in sel:
            account_id, datetime = elements
            check = self.instanceofclass.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="DELETE FROM auto_auth WHERE pub='%s'"%(account_id))._insert() if self.instanceofclass.instance.inst.inst.check_Timing(stamp=loads(b64decode(datetime.encode("utf-8", errors="ignore")).decode("utf-8", errors="ignore"))) == True else None
        return

    def save_account(self:object):
        from os import urandom
        from base64 import b64encode, b64decode
        self.check_sessions()
        if self.instanceofclass.authorize() == False:
            self.instanceofclass.socket_handler.send_normal_pkt(data=b"error: Unauthorized access! User has 0 permissions to execute that command!", socket=self.instanceofclass.socket)
            return
        if self.is_allowed_saving() == False:
            self.instanceofclass.socket_handler.send_normal_pkt(data=("error: Saving account on this specific group ('%s') was denied!"%(self.instanceofclass.instance.inst.inst.instanceOfClass.logged_client_sessions[self.instanceofclass.fetch_uuid()]["typeacc"])).encode("utf-8", errors="ignore"), socket=self.instanceofclass.socket)
            return
        if self.instanceofclass.too_much(table="auto_auth", limit=5, to_unique=("ip_address", self.instanceofclass.client_data[0])) == True:
            self.instanceofclass.socket_handler.send_normal_pkt(data=(b"error: An error occured! Reason>> too many saved sessions from your host! Please, try again later!"), socket=self.instanceofclass.socket)
            return
        parsed_commands = tools()
        parsed_commands.argument = self.instanceofclass.command
        parsed = parsed_commands.remote_based_arguments(required_param_list="bitsize")
        try:
            bit_size = 2048 if len(parsed) == 0 else int(parsed[0])
        except Exception as e:
            print(e)
            self.instanceofclass.socket_handler.send_normal_pkt(data=("error: An error occured! Reason>> %s"%(e)).encode("utf-8", errors="ignore"), socket=self.instanceofclass.socket)
            return
        if (1024 <= bit_size <= 65535) == False:
            self.instanceofclass.socket_handler.send_normal_pkt(data=(b"error: Incorrect bit size! 1024 <= bit_size <= 65535."), socket=self.instanceofclass.socket)
            return
        gen = RSA.generate(bit_size, randfunc=urandom)
        pub = gen.publickey()
        priv = gen.exportKey()
        encr = PKCS1_OAEP.new(pub)
        msg = "Account-%s::_session_addr-%s"%(self.instanceofclass.instance.inst.inst.instanceOfClass.logged_client_sessions[self.instanceofclass.fetch_uuid()]["account_id"], self.instanceofclass.client_data[0])
        encrypted_msg = b64encode(encr.encrypt(msg.encode("utf-8", errors="ignore"))).decode("utf-8", errors="ignore")
        timeConf = self.instanceofclass.instance.inst.inst.check_complexity(pool=self.instanceofclass.instance.inst.inst.getLocalTime(dict_like_obj=True), hour=15, minutes=1, add_hour=3) # calculate datetime complexity.
        self.instanceofclass.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="INSERT INTO auto_auth(account_id, encrypted_msg, pub, priv, datetime, ip_address) VALUES ('%s', '%s', '%s', '%s', '%s', '%s')"%(self.instanceofclass.instance.inst.inst.instanceOfClass.logged_client_sessions[self.instanceofclass.fetch_uuid()]["account_id"], encrypted_msg, b64encode(pub.exportKey()).decode("utf-8", errors="ignore"),b64encode(priv).decode("utf-8", errors="ignore"), b64encode(dumps(timeConf).encode("utf-8", errors="ignore")).decode("utf-8", errors="ignore"), self.instanceofclass.client_data[0]))._insert()
        self.instanceofclass.socket_handler.send_normal_pkt(data=("Bit-size: %s"%(bit_size)).encode("utf-8", errors="ignore") + b"," + b64encode(pub.exportKey()), socket=self.instanceofclass.socket)
        return