from json import loads, dumps
from utils.website.authentication import authentications
from utils.check_directory_if_specific import main as cmain
from utils.commands import commands_Interface as cmdinter
from Cryptodome.Cipher import AES
from base64 import b64encode, b64decode
from dataclasses import dataclass
from uuid import uuid4
from os.path import getsize

class post_controller():
    
    def __init__(self:object, post_data:dict, actual_packet:str, object_self:object, upload=False) -> (object):
        self.post_data = post_data if upload == True else self.get_list(post_data); self.actual_packet = actual_packet; self.object_self = object_self; self.database_con = self.object_self.instance.inst.inst.instanceOfClass.database
    
    def login_Control(self:object):
        if len(self.post_data) < 3:
            return False, False, False, False
        x1, x2, x3 = self.post_data
        if x3 == "normalweb.auth":
            return authentications(self.object_self, x1, x2).normalweb()
            
    def msg2aes(self:object):
        if len(self.post_data) < 3:
            return False, False, False, False
        x1, x2, x3 = self.post_data # msg, key
        alg = {"aes256":AES.MODE_GCM, "aes128":AES.MODE_CBC}
        if x3 not in alg:
            return False, False, False, False   
        try:
            sel = AES.new(x2.encode("utf-8", errors="ignore"), alg[x3], x2.encode("utf-8", errors="ignore"))
        except Exception as e:
            return dumps({"message":"Incorrect key? %s"%(e)}).encode("utf-8", errors="ignore"), "application/json", "200", self.object_self.path
        return dumps({"encrypted":b64encode(sel.encrypt(x1.encode("utf-8", errors="ignore"))).decode("utf-8", errors="ignore")}).encode("utf-8", errors="ignore"), "application/json", "200", self.object_self.path

    def uploadFiles(self:object):
        actual_data = self.post_data.split("\r\x0A")
        webbased = self.object_self.path.split("~")
        if len(webbased) < 2:
            return "/forbidden", "text/html",  "403", self.object_self.path
        webbased = webbased[1].split("/")[0]
        if webbased not in self.object_self.instance.inst.inst.instanceOfClass.logged_client_sessions:
            return "/ftsrv/account/login.html", "text/html", "301", self.object_self.path
        vals = {}
        for items in actual_data:
            if "--" in items:
                vals["cdis"] = items.replace("-", "")
            if ";" in items:
                act = [bob for bob in items.split(";") if "=" in bob]
                if len(act) == 2:
                    name, file = act
                    vals["name"], vals["filename"] = name, file.split("=")[1].replace('"', "")
        if "filename" not in vals:
            vals["filename"] = str(uuid4())
        self.object_self.socket.settimeout(5)
        dir = self.object_self.instance.inst.inst.instanceOfClass.logged_client_sessions[webbased]["directory"]
        if isinstance(dir, list) == True:
            dir = dir[0][0]
        designated = dir + "/" + vals["filename"]
        size = 0
        with open(designated, "wb") as file:
            file.write(self.object_self.instance.old_based.split(self.post_data.encode("utf-8", errors="ignore"))[1].strip())
            while True:
                try:
                    downloaded = self.object_self.socket.recv(2048)
                    if vals["cdis"].encode("utf-8", errors="ignore") in downloaded:
                        downloaded = downloaded.split(b"\r\x0A")[0]
                    file.write(downloaded)
                    size += len(downloaded)
                except TimeoutError as f:
                    break
        file.close()
        self.object_self.instance.inst.inst.instanceOfClass.uploaded_files[webbased] = {"file":vals["filename"], "datetime":self.object_self.instance.inst.inst.getLocalTime(), "size":"%.2f"%(getsize(designated)/1000**2) + "/mb", "designated":designated}
        self.object_self.instance.inst.inst.instanceOfClass.log_of_uploaded[str(uuid4())] = {"file":vals["filename"], "wuuid":webbased, "datetime":self.object_self.instance.inst.inst.getLocalTime()}
        self.object_self.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="INSERT INTO __db__.website_upload_(client, file, file_destination) VALUES ('%s', '%s', '%s');"%(self.object_self.data_hold[0][0], vals["filename"], designated))._insert()
        return "/uploaded.html", "text/html", "200", self.object_self.path

    def checkAccountPermissions(self:object) -> (object):
        if len(self.post_data) < 2:
            return dumps({"message":"Username and password not located in the given JSON-like message!"}).encode("utf-8", errors="ignore"), "application/json", "403", self.object_self.path
        self.post_data[1] = authentications(self.object_self, self.post_data[0], self.post_data[1]).encrypt_password()
        select = self.database_con(db="ftsrv", syntax="SELECT account_id FROM user_ftsrv_accounts WHERE username='%s' AND password='%s'"%(self.post_data[0], self.post_data[1]))._fetch()
        if len(select) == 0:
            return dumps({"message":"Provided an incorrect pair of - username and password!"}).encode("utf-8", errors="ignore"), "application/json", "403", self.object_self.path
        __an__ = {":ap":"Anonymous", ":adp":"Administrator"}
        admin, anon = cmdinter(website_instance=True, instance=self.object_self.instance).check_anon_admin_like(self.post_data[0], self.post_data[1])
        if admin == ":ap" or admin == "adp":
            return dumps({"account":"not accessible!", "message":"%s account currently is deactivated. Please, consult your administrator in order the problem to be fixed!"%(__an__[actual[0]])}).encode("utf-8", errors="ignore"), "application/json", "403", self.object_self.path
        return dumps({"message":True, "account":"accessible", "type-a":"%r"%(admin), "type-an":"%r"%(anon)}), "application/json", "200", self.object_self.path

    def userData(self:object) -> (object):
        if len(self.post_data) < 1:
            return False, False, False, False
        uuid = self.post_data[0]
        if uuid == "null" or uuid == "None" or uuid == None:
            uuid = cmain(self.object_self).dosc()
            return dumps(uuid).encode("utf-8", errors="ignore"), "application/json", "200", self.object_self.path
        if uuid not in self.object_self.instance.inst.inst.instanceOfClass.logged_client_sessions:
            return dumps({"msg":"Key needs to be removed from local storage!"}).encode("utf-8", errors="ignore"), "application/json", "403", self.object_self.path
        data = self.object_self.instance.inst.inst.instanceOfClass.logged_client_sessions[uuid]
        return dumps({"toc":data["typeacc"], "las":data["username"], "uuid":uuid}).encode("utf-8", errors="ignore"), "application/json", "200", self.object_self.path

    def logout(self:object) -> (object):
        if len(self.post_data) < 1:
            return False, False, False, False
        uuid = self.post_data[0]
        if uuid == "null" or uuid == "None" or uuid == None:
            return False, False, False, False
        if uuid not in self.object_self.instance.inst.inst.instanceOfClass.logged_client_sessions:
            return dumps({"msg":"Given key was not located!"}).encode("utf-8", errors="ignore"), "application/json", "200", self.object_self.path
        del self.object_self.instance.inst.inst.instanceOfClass.logged_client_sessions[uuid]
        return dumps({"msg":"Logout was successful!"}).encode("utf-8", errors="ignore"), "application/json", "200", self.object_self.path


    def get_list(self:object, value:(str, dict, tuple, list, ...)):
        list_ = []
        for keys in value:
            list_.append(value[keys])
        return list_
    
        