from hashlib import sha512, sha256
from utils.website.abstraction import abstraction
from base64 import b64encode, b64decode
from json import loads, dumps
from utils.commands import commands_Interface as scmd
from utils.website.security import security as sec
from uuid import uuid4

class authentications(object):

    def __init__(self:object, instance:object, username:str, password:str) -> (object, str, str):
        self.username, self.password, self.instance = username, password, instance
        self.cmd = scmd(command="", socket_handler=None, instance=self.instance.instance, sock=None, data=((None, 0)), website_instance=True)
    
    def normalweb(self:object):
        #op = self.hash_(msg=self.hash_(b64decode(self.password.encode(abstraction().encoding, errors="ignore"))))
        self.instance.instance.inst.inst.check_entries()
        second_hash_part = self.encrypt_password()
        sel = self.instance.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="SELECT account_id FROM __db__.user_ftsrv_accounts WHERE username='%s' AND password='%s'"%(self.username, second_hash_part))._fetch()
        if len(sel) == 0:
            return dumps({"message":"We're sorry, but the provided username or password is incorrect."}), "application/json", "403", "/ftsrv/account/login"
        account_id = sel[0][0]
        anon, admin = self.cmd.check_anon_admin_like(self.username, second_hash_part)
        if anon == ":ap" or anon == ":adp":
            return dumps({"message":"We're sorry, but the account you are trying to authorize is disabled on the server!"}), "application/json", "403", "/ftsrv/account/login"
        typeacc = self.cmd.find_typeacc(None, anon, admin)
        unique = "WebBased:-" + str(uuid4())
        check_sec = sec(self).hlh(host_=self.instance.data_hold[0][0], username=self.username)
        if check_sec == False:
            return dumps({"message":"We're sorry, but authentication limit was exceeded for that account! Over the limit authorizations from your network!"}), "application/json", "403", "/ftsrv/account/login"
        # only this, and this ... stays until logon from the client, or restart of the server.
        del self.instance.instance.inst.inst.instanceOfClass.logged_client_sessions[scmd(instance=self.instance.instance, data=self.instance.data_hold[0], website_instance=True).fetch_uuid()]
        self.instance.instance.inst.inst.instanceOfClass.logged_client_sessions[unique] = {"logged":True, "account_id":account_id, "datetime":self.instance.instance.inst.inst.getLocalTime(), "username":self.username, "directory":self.fetch_directory(account_id), "anon":anon, "logging":False, "typeacc":typeacc, "host":self.instance.data_hold[0][0], "remove":False, "timePool":self.instance.instance.inst.inst.check_complexity(pool=self.instance.instance.inst.inst.getLocalTime(dict_like_obj=True), add_minute=1)}
        self.instance.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="INSERT INTO website_logins(client, port, wuuid) VALUES ('%s', '%s', '%s');"%(self.instance.data_hold[0][0], self.instance.data_hold[0][1], unique))._insert()
        return dumps({"message":"Authentication is successful! Welcome aboard, %s!"%(self.username), "uuid":unique}), "application/json", "200", "/ftsrv/account/login"

    def fetch_directory(self:object, account_id:str):
        directory = self.instance.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="SELECT start_directory FROM __db__.account_rules WHERE account_id='%s'"%(account_id))._fetch()
        return directory

    def hash_(self:object, msg:str) -> (str):
        md = sha512()
        md.update(msg)
        return md.hexdigest()

    def encrypt_password(self:object) -> (object):
        first_hash_part = self.hash_(b64decode(self.password.encode(abstraction().encoding, errors="ignore")))
        second_hash_part = self.hash_(first_hash_part.encode(abstraction().encoding, errors="ignore"))
        return second_hash_part