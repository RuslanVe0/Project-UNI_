from dataclasses import dataclass
from typing import Union, Type
@dataclass
class abstraction(object):
    crlf:Type[str]="\r\x0A\r\x0A"
    newlr:Type[str]="\r\x0A"
    encoding:Type[str]="utf-8"
