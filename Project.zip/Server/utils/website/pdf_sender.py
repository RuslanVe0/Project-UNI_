class main(object):

    def __init__(self:object, self2:object, id_pdf:str) -> (object):self.inst = self2; self.id_pdf = id_pdf; self.enum()

    def enum(self:object):
        document = self.inst.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="SELECT path, accessibility FROM __db__.pdf_ WHERE pdf_id='%s'"%(self.id_pdf))._fetch()
        if len(document) == 0:
            self.inst.cont = "text/html; charset='utf-8'"; self.inst.path = "/fibo404.html"; self.inst.st = "404"; self.inst.sdir = "/fibo404.html"
            return
        path, accessibility = document[0]
        if accessibility != 1:
            self.inst.cont = "text/html; charset='utf-8'"; self.inst.path = "/forbidden.html"; self.inst.st = "403"; self.inst.sdir = "/forbidden.html"
        self.inst.cont = "application/pdf"; self.inst.path = path; self.inst.st = "200"; self.inst.sdir = path