function resolve_(seconds) {
    return new Promise(resolve => {
      setTimeout(() => {
        resolve('resolved');
      }, seconds*1000);
    });
  }
const total_connections = {
    "connections":[fetch_connections, "/ftsrv/account/guest/fetch-connections", "Total connections: ", 1],
    "help":[fetch_connections, "/ftsrv/account/guest/help", "Help: ", 0],
};

async function fetch_connections(directory, comment, foreverable) {
    var did = 0;
    var is_forever = 1;
    while(true && is_forever==1){
    if (did != 0) {
        const act = await resolve_(5);
    }
    console.log(foreverable);
    if (foreverable == 0) {
        is_forever = 0;
    }
    console.log("123");
    const xhr = new XMLHttpRequest();
    xhr.open("GET", directory, true);
    xhr.onreadystatechange = function() {
        if (this.status == 200 && this.readyState == 4) {
            if (document.getElementById("comment") == undefined) {
                console.error("Element is undefined!");
                return
            }
            js = JSON.parse(this.responseText);
            document.getElementById("comment").innerText = comment + js["data"];
            document.getElementById("readable_content").hidden = false;

        } else if (this.status != 200 && this.readyState == 4) {
            if (document.getElementById("comment") == undefined) {
                console.error("Element is undefined!");
                return
            }
            document.getElementById("comment").innerText = comment + "Unknown?";
            document.getElementById("readable_content").hidden = false;
        }
    };
    xhr.send();
    did = 1;
    };

};
function elementTransition(element) {
    element.transitionDuration = "2.5";
    element.transform = "rotate(50deg);"
}
function about_me () {
    if (document.getElementById("whatwedo").hidden) {
        document.getElementById("whatwedo").classList.add("slideshow");
        document.getElementById("whatwedo").hidden = false;
        scrolltop();
    } else {
        document.getElementById("whatwedo").classList.add("slideshow");
        document.getElementById("whatwedo").hidden = true;
    }
}
function scroll() {
    var last = 0;
    document.addEventListener("scroll", function() {
    var state = window.pageYOffset || window.pageXOffset;
    if (document.getElementById("footer") == undefined || document.getElementById("p1") == undefined
    || document.getElementById("p2") == undefined || document.getElementById("whatwedo") == undefined) {
        return;
    }
    if (state >= last) {
        document.getElementById("footer").style.opacity = 10;
        document.getElementById("p1").style.opacity = 0.5;
        document.getElementById("p2").style.opacity = 0.5;
        elementTransition(document.getElementById("p2"));
        elementTransition(document.getElementById("p1"));
        document.getElementById("whatwedo").style.opacity = 0.5;
        elementTransition(document.getElementById("whatwedo"));
    } else {
        document.getElementById("whatwedo").style.opacity = 1;
        elementTransition(document.getElementById("whatwedo"));
        document.getElementById("p1").style.opacity = 10;
        document.getElementById("p2").style.opacity = 10;
        document.getElementById("footer").style.opacity = 0.5;
        document.getElementById("p1").style.transitionDuration = "2.5s";
        document.getElementById("p1").style.transform = 'rotate(45deg);';
    }
    last = state;
})
}
async function listen_handler_login() {
    if (document.getElementById("login_button") == undefined) {
        return null;
    }
    document.getElementById("login_button").addEventListener("click", function(){
        document.getElementById("login_button").disabled = true;
        var cd = document.createElement("p");
        cd.innerText = "☑️";
        document.getElementById("elm").appendChild(cd);
    });
};

function fetch_type_acc(){
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/ftsrv/account/fetch/userData", true);
    xhr.onreadystatechange = function() {
        if (this.status == 200 && this.readyState == 4) {
            var loaded = JSON.parse(this.responseText);
            if ("data" in loaded) {
                loaded = loaded["data"];
            };
            document.getElementById("toc").innerText = loaded["toc"];
            document.getElementById("las").innerText = loaded["las"];
            document.getElementById("uuid").innerText = loaded["uuid"];
        } else if (this.status == 403 && this.readyState == 4){
            window.localStorage.removeItem("wuuid");
            fetch_type_acc();

        } else if (this.status != 200 && this.readyState == 4) {
            document.getElementById("toc").innerText = "Unknown";
            document.getElementById("las").innerText = "Unknown";
            document.getElementById("uuid").innerText = "Unknown";
        };
    };
    xhr.send(JSON.stringify({"wuuid":window.localStorage.getItem("wuuid")}));
};

$(window).load(function() {
    check_url();
    var class_ = $(".icon.xa-1").context;
    listen_handler_login();
    fetch_type_acc();
    scroll();
});

function fetchToken() {
    const xhr = new XMLHttpRequest();
    xhr.open("GET", "/ftsrv/account/fetch/fetch_uuid", true); 
    xhr.onreadystatechange = function() {
        if (this.status == 200 && this.readyState==4) {
            var jsonx = JSON.parse(this.responseText);
            if ("data" in jsonx) {
                uuid = jsonx["data"]["msg"];
            } else {
                uuid = json["msg"];
            }
            document.getElementById("uidfettok").innerText = uuid;
        } else if (this.status != 200 && this.readyState == 4) {
            document.getElementById("uidfettok").innerText = "Error occured, while fetching UUID token!";
        }
    };
    xhr.send();

};

function create_EventListenerRadio(element, id) {
    element.addEventListener("click", (event) => {
        var target = event.target;
        if (target.id == "yes") {
            logout();
            window.localStorage.removeItem("wuuid");
            window.location.reload();
        } else if (target.id == "no") {
            window.location.href = `/ftsrv/account/userAccount/~${window.localStorage.getItem("wuuid")}/ftAccount/index.html`;
            return;
        };
    });
};

function login() {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    if (username.length < 4 || username.length > 32) {
        document.getElementById("lms").hidden = false;
        document.getElementById("login_message_srv").style.color = "red";
        document.getElementById("login_message_srv").innerText = "Username is not with a correct length!";
        return;
    }
    var cx = window.localStorage.getItem("wuuid");
    if (cx != null) {
        document.getElementById("lgt").hidden = false;
        create_EventListenerRadio(document.getElementById("lgt"), "lgt");
        return;
    }
    encryptPassword(username, password);
};
function scrolltop() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}
function config_panel() {
    if (document.getElementById("config_panel").hidden) {
        document.getElementById("config_panel").classList.add("slideshow");
        document.getElementById("config_panel").hidden = false;
    } else {
        document.getElementById("config_panel").classList.add("slideshow");
        document.getElementById("config_panel").hidden = true;
    }
}
function check_url() {
    location_ = document.location.hash;
    loc_ = document.location.pathname;
    if (location_ == "#connections") {
        $("#connd").removeAttr("href");
        array = total_connections.connections;
        console.log(array);
        function_ = array[0];
        function_(array[1], array[2], array[3]);
        scrolltop();
    } else if (location_ == "#help") {
        $("#help").removeAttr("href");
        document.getElementById("blend1").style.opacity = "0.5";
        document.getElementById("blend2").style.opacity = "0.5";
        document.getElementById("readable_content").style.opacity = "1.0";
        document.getElementById("readable_content").style.width = "900px";
        array = total_connections.help;
        function_ = array[0];
        function_(array[1], array[2], array[3]);
        scrolltop();
    } else if (loc_.includes("login.html") == true) {
        document.getElementById("login").disabled = true;
        document.getElementById("login").href = "#";
    };
}
const resend_data = function(required_hash) {
    if (required_hash == "#help") {
        $("#help").removeAttr("href");
        document.getElementById("readable_content").style.width = "900px";
        array = total_connections.help;
        functon_ = array[0];
        function_(array[1], array[2], array[3]);
    } else if (required_hash == "#connections") {
        $("#help").removeAttr("href");
        document.getElementById("readable_content").style.width = "900px";
        array = total_connections.connections;
        functon_ = array[0];
        function_(array[1], array[2], array[3]);
    }
};
function what() {
    if (document.getElementById("whatwedo") == null) {
        return
    }
}
what();