function isupper(char) {
    if (char == char.toUpperCase()) {
        return true;
    }
    return false;
}
String.prototype.replaceAt = function(index, replacement) {
    return this.substring(0, index) + replacement + this.substring(index + replacement.length)
};
function promise(ms) {
    return new Promise(resolve => {
        setTimeout(() => {
            resolve("resolved");
        }, ms)
    })
}

function regex_find(expression, character) {
    return character.match(expression);
};

var is_already = 0;
async function start() {
    if (is_already != 0) {
        return;
    }
    var heading = document.getElementById("heading");
    if (heading == null) {
        return;
    }
    var text = heading.innerText;
    var previous_val = text;
    previous = "";
    var old_color = heading.style.color;
    is_already = 1;
    for (var i=0; i <= text.length; i++) {
        var char = text[i];
        if (char == undefined) {
            continue;
        }
        if (regex_find("[A-z]", char) == null && regex_find("[а-я]", char) == null && regex_find("[А-я]", char) == null) {
            continue;
        }
        if (isupper(char) == true) {
            char = char.toLowerCase();
        } else {
            char = char.toUpperCase();
        }
        if (i != 0) {
            text = text.replaceAt(i-1, text[i-1].toLowerCase());
        }
        text = text.replaceAt(i, char);
        const aw = await promise(500);
        document.getElementById("heading").innerText = text;
    };document.getElementById("heading").innerText = previous_val; document.getElementById("heading").style.color = old_color; is_already = 0;};
window.onload = async function() {
    start();
    mouse_capture();
};
const start_shining = function() {
    var argument = Array.prototype.slice.call(arguments, 0);
    for (var element=0; element<argument.length; element++) {
        var hoveredElm = argument[element][0];
        if (hoveredElm == null) {
            return false;
        };
        hoveredElm.classList.add("shine");
    };
};
function mouse_capture() {
    if (cloa == false) {
        return;
    }
    var old_states = [];
    document.addEventListener("mousemove", (event) => {
        if (old_states.length != 0) {
            for (var i in old_states) {
                var elm = old_states[i];
                if (elm == undefined) {
                    return false;
                }
                if ([event.clientX, event.clientY] != [elm[1], elm[2]]) {
                    var element = elm[0];
                    element.classList.remove("shine");
                    old_states.pop(i);
                }
            }
        } else {

            var x = document.elementsFromPoint(event.clientX, event.clientY);
            if (ot != false && x[0] != undefined && x[0].id != "animationable") {
                var ot = start_shining(x);
                old_states.push([x[0], event.clientX, event.clientY]);
            };
        };
    })
};