function PrepareChecksum(username, password) {
    packed = "";
    n = 0;
    for (var i=0; i<username.length; i++) {
        console.log(i);
        if (i+1+n >= username.length-1) {
            continue;
        };
        temp = username[i] + username[i+1+n];
        temp += password[i] + password[i+1+n];
        packed += temp;
        n += 1;
    }
    while (packed.length > 32) {
        packed = packed.slice(0, 1);
    }
    while (packed.length < 32) {
        packed += "a";
    }
    return packed;
};

function resolveSec(seconds) {
    return new Promise(resolve => {
      setTimeout(() => {
        resolve('resolved');
      }, seconds*1000);
    });
  }

async function makeRedirectingAfter(element_id, seconds, path, wuuid, responsetext) {
    document.getElementById(element_id).innerText += " Redirecting after ... ";
    var elmCr = document.createElement("p");
    elmCr.alt = "Redirecting.Object";
    elmCr.id = "element_Redirecting";
    document.getElementById(element_id).appendChild(elmCr);
    for (var i=seconds; i>=1; i--) {
        const sec = await resolveSec(1);
        document.getElementById("element_Redirecting").innerText = i + "...";
    };
    if (wuuid == true) {
        console.debug(`set wuuid -> ${window.localStorage.getItem("wuuid")}`);
    };
    window.location.href = path;
};
function send_post_form_auth(json_like_text) {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/ftsrv/account/login", true);
    xhr.onreadystatechange = function() {
        if (this.status == 200 && this.readyState == 4) {
            document.getElementById("lms").hidden = false;
            document.getElementById("login_message_srv").style.color = "green";
            document.getElementById("login_message_srv").innerText = JSON.parse(this.responseText)["message"];
            window.localStorage.setItem("wuuid", JSON.parse(this.responseText)["uuid"]);
            makeRedirectingAfter("login_message_srv", 5, `/ftsrv/account/userAccount/~${window.localStorage.getItem("wuuid")}/ftAccount/index.html`, true, this.responseText);
        } else if (this.status != 200 && this.readyState == 4) {
            document.getElementById("lms").hidden = false;
            document.getElementById("login_message_srv").style.color = "red";
            document.getElementById("login_message_srv").innerText = JSON.parse(this.responseText)["message"];
            return
        }
    };
    xhr.send(json_like_text);
};
const class_based_objects = {
    "account_perm":check_AccountPermissions,
    "send_post":send_post_form_auth,
};
function check_AccountPermissions(username, password) {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/ftsrv/account/checkPermissions", true);
    xhr.onreadystatechange = function() {
        if (this.status == 200 && this.readyState == 4) {
            console.debug("Account has no specific permissions.");
            class_based_objects.send_post(JSON.stringify({"username":username, "password":password, "type":"normalweb.auth"}));
        } else if (this.status != 200 && this.readyState == 4) {
            var xl = JSON.parse(this.responseText);
            console.log(xl);
            if ("message" in xl) {
                document.getElementById("lms").hidden = false;
                document.getElementById("login_message_srv").style.color = "red";
                document.getElementById("login_message_srv").innerText = xl["message"];
                return;
            }
            if ("data" in xl) {
                item = xl["data"]["msg"];
            } else {
                item = xl["msg"];
            }
            document.getElementById("lms").hidden = false;
            document.getElementById("login_message_srv").style.color = "red";
            document.getElementById("login_message_srv").innerText = item;

        };
    };
    xhr.send(JSON.stringify({"username":username, "password":password}));

} 

function send_encr(username, password, checksum) {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/ftsrv/services/msg2aes", false);
    xhr.onreadystatechange = function() {
        if (this.status == 200 && this.readyState == 4) {
            var lod = JSON.parse(this.responseText);
            let str = lod["encrypted"];
            class_based_objects.account_perm(username, str);
        }
    };
    xhr.send(JSON.stringify({"msg":password, "key":checksum, "algo":"aes256"}));
};

function encryptPassword(username, password) {
    var username = username;
    var password = password;
    if (username.length > password.length) {
        username = username.slice(0, Math.abs((username.length - (username.length - password.length))));
    };
    if (password.length > username.length) {
        password = password.slice(0, Math.abs((password.length - (password.length - username.length))));
    }
    checksum = PrepareChecksum(username, password);
    send_encr(username, password, checksum);
};

function logout() {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/ftsrv/services/logout", true);
    xhr.onreadystatechange = function() {
        if (this.status != 200 && this.readyState == 4) {
            console.error("Server responded with an unexpected answer.");
        };
    };
    xhr.send(JSON.stringify({"uuid":window.localStorage.getItem("wuuid")}));
}