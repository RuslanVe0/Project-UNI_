function scrolltop() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
};

function request_form(torequest_id) {
    var xc = document.getElementById("Inptconcrete").value;
    if (xc.length == 0) {
        document.getElementById("Inptconcrete").value = "";
        document.getElementById("msg").style.color = "#ff5400";
        document.getElementById("msg").innerText = `Entered an invalid argument ...`;
    } else {
        const xhr = new XMLHttpRequest();
        xhr.open("GET", `./command/${torequest_id}?cmd=${xc}`, true);
        xhr.onreadystatechange = function() {
            if (this.status == 200 && this.readyState == 4) {
                document.getElementById("msg").hidden = true;
                lib = JSON.parse(this.responseText);
                if ("data" in lib) {
                    lib = lib["data"]["msg"];
                } else {
                    lib = lib["msg"];
                };
                document.getElementById("Inptconcrete").value = "";
                document.getElementById("msg_text").hidden = false;
                document.getElementById("btn").hidden = false;
                document.getElementById("msg_text").innerText = lib;

            } else if (this.status != 200 && this.readyState == 4) {
                document.getElementById("msg").innerText = "Entered an invalid argument ...";
                document.getElementById("Inptconcrete").value = "";
            };
        };
        xhr.send();
    };
};
function create_table_contents(required_doc) {
    const objx = document.createElement("tr");
    const objxr = document.createElement("td");
    objxr.appendChild(required_doc);
    objx.appendChild(objxr);
    document.getElementById("down_table").appendChild(objx);
}
function request_download() {
    void function check_if_auth() {
        const xhr = new XMLHttpRequest();
        xhr.open("GET", "./checkAuth", true);
        xhr.onreadystatechange = function() {
            if (this.status == 200 && this.readyState == 4) {
                var load = JSON.parse(this.responseText);
                if ("data" in load) {
                    load = load["data"]["msg"];
                } else {
                    load = load["msg"];
                };
                if (load == false) {
                    window.localStorage.removeItem("wuuid");
                    window.location.href = "/ftsrv/account/login.html";
                }
            };
        };
        xhr.send();
    }();
    document.getElementById("msg_text").hidden = true;
    document.getElementById("msg_text").innerText = "";
    document.getElementById("btn").hidden = true;
    document.getElementById("download_input").hidden = false;
    const xhr = new XMLHttpRequest();
    xhr.open("GET", `./command/dir?command=files2dict&command2=onlyfiles`, true);
    xhr.onreadystatechange = function() {
        if (this.status == 200 && this.readyState == 4) {
            var loaded = JSON.parse(this.responseText);
            if ("data" in loaded) {
                loaded = loaded["data"]["msg"];
            } else {
                loaded = loaded["msg"];
            };
            for (var i in loaded) {
                const doc = document.createElement("a");
                doc.id = i;
                doc.href = "./command/download?file=" + i;
                doc.textContent = i;
                doc.download = i;
                doc.onclick = function check_if_auth() {
                    const xhr = new XMLHttpRequest();
                    xhr.open("GET", "./checkAuth", true);
                    xhr.onreadystatechange = function() {
                        if (this.status == 200 && this.readyState == 4) {
                            var load = JSON.parse(this.responseText);
                            if ("data" in load) {
                                load = load["data"]["msg"];
                            } else {
                                load = load["msg"];
                            };
                            if (load == false) {
                                window.localStorage.removeItem("wuuid");
                                window.location.href = "/ftsrv/account/login.html";
                            }
                        };
                    };
                    xhr.send();
                };
                doc.style.textDecoration = "underline";
                const docx = document.createElement("p");
                docx.id = loaded[i][1];
                docx.style.fontSize = "12pt";
                docx.textContent = "Size: " + loaded[i][1];
                create_table_contents(doc);
                create_table_contents(docx);
            };
        };
    };
    xhr.send();
};

function makeRequest(torequest_id) {
    document.getElementById("type_as").innerText = torequest_id;
    const xhr = new XMLHttpRequest();
    xhr.open("GET", `./command/${torequest_id}`, true);
    xhr.onreadystatechange = function(){
        if (this.status == 200 && this.readyState == 4) {
            var act = JSON.parse(this.responseText);
            if ("data" in act) {
                lib = act["data"]["msg"];
                document.getElementById("Inptconcrete").value = "";
            } else {
                lib = act["msg"];
                document.getElementById("Inptconcrete").value = "";
            }
            if (lib == "req.form") {
                document.getElementById("for_input").hidden = false;
                document.getElementById("clickon").onclick = function() {
                    scrolltop();
                    request_form(torequest_id);
                };
                return;
            } else if (lib == "req.down") {
                scrolltop();
                request_download();
                return;
            } else if (lib == "logout.True") {
                window.localStorage.removeItem("wuuid");
                window.location.reload();
                return;
            };
            document.getElementById("msg_text").hidden = false;
            document.getElementById("btn").hidden = false;
            document.getElementById("msg_text").innerText = lib;
            return;
        };
    };
    xhr.send();
};
document.getElementById("functionalities").addEventListener("click", (event) => {
    var doc = event.target;
    if (doc.type != "button") {
        return;
    }
    if (doc.id == "upload_button") {
        if (document.getElementById("for_upload").hidden == false) {
            document.getElementById("for_upload").hidden = true;
        } else {
            document.getElementById("for_upload").hidden = false;
        }
        return;
    }
    makeRequest(doc.id);
    
}); 


void function createButtonLabel() {
    console.debug("fetching buttons ...");
    let prepare_doc = window.location.href.split("~")[0] + "fetch-buttons/~" + localStorage.getItem("wuuid");
    const xhr = new XMLHttpRequest();
    xhr.open("GET", prepare_doc, true);
    xhr.onreadystatechange = function() {
        if (this.status == 200 && this.readyState == 4) {
            var sel = JSON.parse(this.responseText);
            if ("data" in sel) {
                lb = sel["data"]["msg"];
            } else {
                lb = sel["msg"];
            };
            decod = JSON.parse(atob(lb));
            var listed = [];
            for (var buttons in decod) {
                cr = document.createElement("button");
                cr.innerText = decod[buttons]["innerText"];
                cr.id = buttons;
                cr.type = "button";
                cr.style.backgroundColor = "#340b0b";
                cr.className = decod[buttons]["class"];
                cr.alt = decod["alt"];
                listed.push(cr);
            };
            const varx = document.createElement("button");
            varx.id = "upload_button";
            varx.className = "border";
            varx.type = "button";
            varx.innerText = "Upload a file";
            varx.style.backgroundColor = "#340b0b";
            listed.push(varx);
            for (var i in listed) {
                /*
                3 due to the fact, that - 20/3 if floored will be 6, thus... there'll be needed at least 6-colons and 3-rows.
                */
                if (i % 3 == 0) {
                    document.getElementById("functionalities").appendChild(document.createElement("br"));
                };
                document.getElementById("functionalities").appendChild(listed[i]);
            };
            console.debug("all buttons fetched ...");

        };
    };
    xhr.send();

}();