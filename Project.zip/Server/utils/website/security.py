class security(object):

    def __init__(self, instance):
        self.instance = instance

    def hlh(self:object, host_:str, username:str) -> (object, str):
        host = host_
        logged_sessions = self.instance.instance.instance.inst.inst.instanceOfClass.logged_client_sessions
        count = 0
        for uuids in logged_sessions:
            usr, hostS = logged_sessions[uuids]["username"], logged_sessions[uuids]["host"] if "host" in logged_sessions[uuids] else None
            if hostS == host and username == usr:
                count += 1
        if count >= int(self.instance.instance.instance.inst.inst.instanceOfClass.firewallProperties["maxLoginPerHost"]):
            return False
        return True