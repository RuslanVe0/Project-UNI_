from typing import Type, Union
from dataclasses import dataclass
from utils.check_directory_if_specific import main as cdis_main
from utils.website.pdf_sender import main as pdf_main
from utils.website.post_controller import post_controller
from utils.website.commands import commands
from json import dumps, loads
from re import search as research

__bytes = bytes
def create_packet(code:(Type[str], Type[int]), content: Type[bytes], xmessage: Type[str], location: Type[str], ymessage: Type[str], date: Type[str], reduce_lines: Type[bool], type: Type[str]="text/html; charset='utf-8'", content_disposition=False, filename=""):
    assert code != None
    assert xmessage != ""
    assert ymessage != ""
    #assert type in ["application/json", "text/html; charset='utf-8'"]
    msg = "HTTP/1.1 %s %s\r\x0AMessage: %s\r\x0AServer: FTSRV\r\x0AConnection: close\r\x0ALocation: %s\r\x0ADate: %s\r\x0AContent-Type: %s"
    msg += "\r\x0A\r\x0A" if content_disposition == False else '\r\x0AContent-Disposition: inline; filename="%s"\r\x0A\r\x0A'%(filename)
    msg = msg%(str(code),ymessage, xmessage, location, date, type)
    if content != False:
        content = b"".join(bob.strip() for bob in content.split(b"\r\x0A")) if reduce_lines == True else content
    out =  msg.encode("utf-8", errors="ignore") + content if content != False else msg.encode("utf-8", errors="ignore")
    return out

def client_directory(self:object) -> (object):
    cdis = cdis_main(self)
    acessible = None
    langident = None
    if "?lang=" in self.path and self.path.split("?lang=") != 1:
        self.path, langident = self.path.split("?lang=")
    self.path = "/index.html" if len(self.path) == 0 or self.path == "/" else self.path # check path in the header, that was sent by the client.
    if cdis.is_pdf() == True:
        path = self.path
        rp = pdf_main(self2=self, id_pdf=path.split("?id=")[1])
        return self.path, self.cont, self.st, self.sdir
    if "getUploadedFile" in self.path:
        temp = cdis.uploaded_detection()
        if isinstance(temp, dict) == False:
            return temp
        self.contentIFJSON = dumps(temp)
        return self.path, "application/json", "200", self.path
    elif "checkAuth" in self.path:
        temp = cdis.check_authorize()
        self.contentIFJSON = dumps(temp)
        return self.path, "application/json", "200", self.path
    if cdis.ispart() == False:
        return return_path(self, langident)
    part = cdis.dosc()
    if isinstance(part, str) == True and part.strip() == "text/html":
        self.cont = "text/html; charset='utf-8'"
        return return_path(self, langident)
    self.contentIFJSON = dumps({"data":part}).encode("utf-8", errors="ignore")
    return self.path, "application/json", "200", self.path

def client_authorization(self:object, addr:str, port:int) -> (object):
    pass


def PostMethod(self:object, path:str, post_data:str, actual_packet:dict) -> (object, str, str, dict):
    assert isinstance(post_data, str) != False
    if "upload-file-engine" in path:
        return post_controller(post_data, actual_packet, self, True).uploadFiles()
    match (path):
        case "/ftsrv/account/login":
            return post_controller(loads(post_data), actual_packet, self).login_Control()
        case "/ftsrv/services/msg2aes":
            return post_controller(loads(post_data), actual_packet, self).msg2aes()
        case "/ftsrv/account/fetch/userData":
            return post_controller(loads(post_data), actual_packet, self).userData()
        case "/ftsrv/services/logout":
            return post_controller(loads(post_data), actual_packet, self).logout()
        case "/ftsrv/account/checkPermissions":
            return post_controller(loads(post_data), actual_packet, self).checkAccountPermissions()
        case other:
            return False

def return_path(self, langident:str):
    actual = commands(self, self)
    if langident in ["bg"]:
        abbr = self.path.split(".")
        self.path = abbr[0] + "-" + langident + "." + abbr[1]
    if langident in ["en"]:
        abbr = self.path.split(".")
        self.path = abbr[0] + "." + abbr[1]
    elif langident != None:
        self.path = self.path.split("?")[0]
    directory = self.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="SELECT path, accessible_, content_type FROM website_paths WHERE directory_suffix='%s'"%(self.path))._fetch()
    if len(directory) == 0:
        st_code = "404"
        directory = self.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="SELECT path, content_type FROM website_paths WHERE directory_suffix='/not-found'")._fetch()
        path, content_type = directory[0]
    elif directory[0][1] != "u.accessible" and actual.check_group_policy(self.webbasedToken, directory[0][1]):
        # first statement should be True (if it DOESN'T equal to ...), and second statement should return True as well...., IN CASE IF... something is basically off.. 
        st_code = "403"
        directory = self.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="SELECT path, content_type FROM website_paths WHERE directory_suffix='/forbidden'")._fetch()
        path, content_type = directory[0]
    else:
        st_code = "200"
        path, acessible, content_type = directory[0] # user desired directory
    return self.path, content_type, st_code, path