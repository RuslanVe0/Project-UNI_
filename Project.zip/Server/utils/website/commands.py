from typing import Union, Type


class commands(object):
    userPool:Type[list]=("System.Ftsrv/users/administrators", "System.Ftsrv/users/user", "System.Ftsrv/users/anonymous")
    userPoolAuthForFile:Type[dict]={"u.accessible":"System.Ftsrv/users/guest", "a1.accessible":("System.Ftsrv/users/anonymous", "System.Ftsrv/users/user"),
    "a2.accessible":"System.Ftsrv/users/administrators"}

    def __init__(self:object, inst1:object, inst2:object) -> (object, object, object): self.inst1, self.inst2 = inst1, inst2
    
    def help_menu(self:object):
        return '''
        These commands are only, AND ONLY used in website enviornment. They are not used in the basic UI environment as a command mode.
        If commands are pointed with - "!", that means they require authorization from the user, thus the server will return that the user
        is not authorized, and the command will not be executed as supposed to when the user is authorized.

        -------------------------------------------------------------------------
        (Please make sure that you have readed the above message!)

        (basic commands located on the index page of the website.)

        login or LOGIN -> is a feature path-based that is used to attempt to login a user.
        Services or SERVICES -> is a feature path-based that is used to show all possible, guest services that can be executed.
        Help or HELP -> is a feature path-based that is used to output this message.
        Connections or CONNECTIONS -> is a feature path-based that is used to enumerate all connected clients.


        -------------------------------------------------------------------------
        '''
    
    def check_if_authorizedWebBased(self:object, required_str:str) -> (object, str):

        selected = self.inst2.instance.inst.inst.instanceOfClass.logged_client_sessions
        if required_str not in selected:
            return False
        return True
    
    def fetch_webbasedToken(self:object):
        if "~" not in self.inst1.path:
            return False
        webbased = self.inst1.path.split("~")[1].split("/")[0]
        return webbased
    
    def check_group_policy(self:object, *args):
        assert len(args) == 2
        token, directory = args
        sel = self.inst2.instance.inst.inst.instanceOfClass.logged_client_sessions
        if token not in sel:
            return True
        """
Straightforward policies of user groups ...
    'u.accessible - guests',
    'a1.accessible - users and anonymous',
    'a2.accessible - administrators',
        """
        group = self.inst2.instance.inst.inst.instanceOfClass.logged_client_sessions[token]["typeacc"] # it should return the type of the account, whether -> System.Ftsrv/users/administrators || System.Ftsrv/users/user as a group of users.
        if group not in self.userPool or group not in self.userPoolAuthForFile[directory]:
            return True
        return False