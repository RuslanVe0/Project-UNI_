from utils.website.packet_view import packet_view
from utils.website.server_side import create_packet, client_directory, client_authorization, PostMethod
from json import dumps
class main(packet_view):
    def __init__(self:object, instance:object, data_hold:tuple, socket:object) -> (object, object):
        self.instance = instance # inheritence.
        self.contentIFJSON = None
        self.socket = socket
        self.data_hold = data_hold # client connectivity data -> ip addr, port.
        self.start_website_occurrence()
    
    def start_website_occurrence(self:object):
        if self.instance.packet == False:
            return
        if len(self.instance.packet) == 0:
            self.badreq()
        packet_view.__init__(self)
        dict_b = {"GET":self.get_like, "POST":self.post_like}
        if self.method not in dict_b:
            self.badreq()
        obj = dict_b[self.method]
        obj()

    def notfound(self:object):
        sel = self.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="SELECT path FROM __db__.website_paths WHERE directory_suffix='/not-found'")._fetch()
        assert len(sel) != 0
        self.instance.inst.inst.send_normal_pkt(create_packet(code="404", content=self.instance.inst.inst.stream_little_File(file=self.instance.inst.inst.instanceOfClass.normalProperties["websitePath"] + sel[0][0]), xmessage=dumps({"msg":""}), ymessage="OK", type="text/html", date=self.instance.inst.inst.getLocalTime(), reduce_lines=True, location=self.path), socket=self.socket)
        return

    def badreq(self:object):
        self.instance.inst.send_normal_pkt(create_packet(code="400", content=b"124214241124", xmessage=dumps({"content":"Invalid packet has been sent from the client!"}), ymessage="Uncompleted", type="application/json", date=self.instance.inst.inst.getLocalTime(), reduce_lines=True, location="bad"), socket=self.socket)
        self.close_connection()
        return

    def send_perm(self:object, path:str) -> (object, str):
        self.instance.inst.send_normal_pkt(create_packet(code="301", content=b"Moving ...", xmessage=dumps({"content":"Invalid packet has been sent from the client!"}), ymessage="Uncompleted", type="application/json", date=self.instance.inst.inst.getLocalTime(), reduce_lines=True, location=path), socket=self.socket)
        return

    def post_like(self:object):
        post_data = self.instance.packet["postData"]
        if post_data == None:
            # in case if postData is None, will attempt to receive data from the client again.
            try:
                self.instance.sock.settimeout(5) # timeout-time is set to 5.
                post_data = self.instance.inst.receivePacket(pow(2, 16), sockaddr=self.instance.sock) # attempting to receive, if available.
            except (TimeoutError, ConnectionResetError, Exception):
                # in case of these errors while this part is implementing, it'll send that data was partial.
                self.instance.inst.send_normal_pkt(create_packet(code="206", content=bytes(dumps({"content":"Partial data? Client sent data that was partial, and could not be comitted!"}), "utf-8"), xmessage=dumps({"content":"Partial data"}), ymessage="Partial Content", type="application/json", date=self.instance.inst.inst.getLocalTime(), reduce_lines=False, location=self.path), socket=self.socket)
                return
        datatoclient, type, st_code, path = PostMethod(self, self.path, post_data, self.instance.packet)
        if datatoclient == False:
            self.instance.inst.send_normal_pkt(create_packet(code="206", content=bytes(dumps({"content":"Partial data? Client sent data that was partial, and could not be comitted!"}), "utf-8"), xmessage=dumps({"content":"Partial data"}), ymessage="Partial Content", type="application/json", date=self.instance.inst.inst.getLocalTime(), reduce_lines=False, location=self.path), socket=self.socket)
            return
        if type == "text/html":
            if st_code == "301" or st_code == "302":
                self.send_perm(datatoclient)
            sel = self.instance.inst.inst.instanceOfClass.database(db="ftsrv", syntax="SELECT path FROM __db__.website_paths WHERE directory_suffix='%s'"%(datatoclient))._fetch()
            if len(sel) == 0:
                self.notfound()
                return
            self.instance.inst.send_normal_pkt(create_packet(code=st_code, content=self.instance.inst.inst.stream_little_File(file=self.instance.inst.inst.instanceOfClass.normalProperties["websitePath"] + sel[0][0]), xmessage=dumps({"msg":"Operation successfully comitted!"}), ymessage="OK", type=type, date=self.instance.inst.inst.getLocalTime(), location=self.path, reduce_lines=True), socket=self.socket, flag=False)
        elif type == "application/json":
            if isinstance(datatoclient, bytes) == False:
                datatoclient = datatoclient.encode("utf-8", errors="ignore")
            self.instance.inst.send_normal_pkt(data=create_packet(code=st_code, content=datatoclient, xmessage=dumps({"content":"Client successfully fetched connection list."}), ymessage="OK", type=type, date=self.instance.inst.inst.getLocalTime(), reduce_lines=True, location=self.path), socket=self.socket)
        self.close_connection()

    def get_like(self:object):
        directory, type, st_code, path = client_directory(self)
        if directory == True:
            return
        if type.split("/")[0] == "image":
            self.instance.inst.send_normal_pkt(create_packet(code=st_code, content=False, xmessage=dumps({"content":"%s"%(type)}), ymessage="OK", type=type, date=self.instance.inst.inst.getLocalTime(), location=self.path, reduce_lines=True), socket=self.socket)
            self.instance.inst.inst.send_little_file(file=self.instance.inst.inst.instanceOfClass.normalProperties["websitePath"] + path,socket_obj=self.instance.inst.send_normal_pkt, socket=self.instance.sock)
        elif type == "application/json":
            if isinstance(self.contentIFJSON, bytes) == False:
                self.contentIFJSON = self.contentIFJSON.encode("utf-8", errors="ignore")
            self.instance.inst.send_normal_pkt(data=create_packet(code=st_code, content=self.contentIFJSON, xmessage=dumps({"content":"Client successfully fetched connection list."}), ymessage="OK", type=type, date=self.instance.inst.inst.getLocalTime(), reduce_lines=True, location=self.path), socket=self.socket)
        elif type == "application/pdf":
            self.odd_specific(st_code=st_code, content=b"", type=type, file=self.instance.inst.inst.instanceOfClass.normalProperties["websitepdfPath"] + path)
        else:
            self.instance.inst.send_normal_pkt(create_packet(code=st_code, content=self.instance.inst.inst.stream_little_File(file=self.instance.inst.inst.instanceOfClass.normalProperties["websitePath"] + path), xmessage=dumps({"path":self.path}), ymessage="OK", type=type, date=self.instance.inst.inst.getLocalTime(), location=self.path, reduce_lines=True), socket=self.socket, flag=False)
        self.close_connection()
 
    def close_connection(self:object):
        self.socket.close()
        self.instance.inst.inst.kick_client(self.data_hold[0][0], self.data_hold[0][1])
        self.instance.inst.inst.clean_connectedList()
    
    def odd_specific(self:object, st_code:str, content:str, file:str, type:str):
        self.instance.inst.send_normal_pkt(data=create_packet(code=st_code, content=content, xmessage=dumps({"content":"Client successfully fetched connection list."}), ymessage="OK", type=type, date=self.instance.inst.inst.getLocalTime(), reduce_lines=True, location=self.path), socket=self.socket)
        self.instance.inst.inst.send_little_file(file=file, socket_obj=self.instance.inst.send_normal_pkt, socket=self.instance.sock)
        