from utils.website.abstraction import abstraction as abstr
class packet_view(object):
    # parse client HTTP packet.
    def __init__(self):
        # inherited
        actual_ = self.instance.packet.split(" ")[:-(len(self.instance.packet.split(" "))-3)]
        self.method, self.path, self.http_ver = actual_ if len(actual_) == 3 else ["?", "?", "?"]
        parsed = [elements for elements in self.instance.packet.split("\r\x0A") if elements.strip().split(":")[0] in ["Host", "Connection", "User-Agent", "Accept-Encoding", "Accept-Language", "Cookie"]] # only to see if there's required
        if len(self.instance.packet.split(abstr().crlf)) == 1:
            post_data = None
        else:
            post_data = self.instance.packet.split(abstr().crlf)[1] # crlf.
        self.instance.packet = {}
        for elements in parsed:
            if ":" in elements:
                self.instance.packet[elements.split(":")[0].strip()] = elements.split(":")[1]
        self.instance.packet["postData"] = post_data