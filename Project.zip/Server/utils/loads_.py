class loadFile(object):

	def parse_data(file_2:str, *args):
		temp = {}
		ps1, ps2 = args
		for j in file_2.split(ps1)[1].split(ps2)[0].strip().split("\x0A"):
			if "->" in j:
				p1, p2 = j.split("->")
				temp[p1.strip().split(" ")[0].strip().lower()] = p2.strip()
		return temp

	def __init__(self:object):
		##an> account.anonymous.rules
		if "local_commands" in dir(self):
			file = (self.local_commands.stream_little_File(file=self.configFile)).decode("utf-8", errors="ignore")
		else:
			file = (self.stream_little_File(file=self.instanceOfClass.configFile).decode("utf-8", errors="ignore"))
		firewall_utils, normal_utils, database_prop = [bob for bob in file.split("f> firewall_rules")[1].split("<f")[0].split("\r") if "#" not in bob or len(bob.strip()) != 0], [bob for bob in "".join(cr for cr in file.split("f> firewall_rules")).split("\r") if "#" not in bob or len(bob.strip()) != 0], [bob for bob in file.split("m> mysql.rules")[1].split("<m")[0].split("\r") if "#" not in bob or len(bob.strip()) != 0]
		acc = [bob for bob in file.split("a> account.rules")[1].split("<a")[0].split("\r") if "#" not in bob or len(bob.strip()) != 0]
		anonymous_account = [bob for bob in file.split("an> account.anonymous.rules")[1].split("<an")[0].split("\r") if "#" not in bob or len(bob.strip()) != 0]
		adminProp = [bob for bob in file.split("admin> account.admin.rules")[1].split("<admin")[0].split("\r") if "#" not in bob or len(bob.strip()) != 0]
		if "local_commands" in dir(self):
			self.firewallProperties, self.normalProperties, self.database_prop, self.account_rules, self.anonProperties, self.adminProp = {}, {}, {}, {}, {}, {}
			for j in ((firewall_utils, self.firewallProperties), (normal_utils, self.normalProperties), (database_prop, self.database_prop), (acc, self.account_rules), (anonymous_account, self.anonProperties), (adminProp, self.adminProp)):
				for items in j:
					sal = j[1]
					for xz in items:
						if len(xz) == 0 or "=" not in xz:
							continue
						sal[xz.split("=")[0].strip()] = (xz.split("=")[1].split("#")[0]).strip()
		else:
			self.instanceOfClass.firewallProperties, self.instanceOfClass.normalProperties, self.instanceOfClass.database_prop, self.instanceOfClass.account_rules, self.instanceOfClass.anonProperties, self.instanceOfClass.adminProp = {}, {}, {}, {}, {}, {}
			for j in ((firewall_utils, self.instanceOfClass.firewallProperties), (normal_utils, self.instanceOfClass.normalProperties), (database_prop, self.instanceOfClass.database_prop), (acc, self.instanceOfClass.account_rules), (anonymous_account, self.instanceOfClass.anonProperties), (adminProp, self.instanceOfClass.adminProp)):
				for items in j:
					sal = j[1]
					for xz in items:
						if len(xz) == 0 or "=" not in xz:
							continue
						sal[xz.split("=")[0].strip()] = (xz.split("=")[1].split("#")[0]).strip()
		file_2 = self.local_commands.stream_little_File(file="README.md").decode("utf-8", errors="ignore") if "local_commands" in dir(self) else self.stream_little_File(file="README.md").decode("utf-8", errors="ignore")
		if "local_commands" in dir(self):
			self.podrobno_menu = loadFile.parse_data(file_2, "x>", "<x")
			self.loaded_slashes_help = loadFile.parse_data(file_2, "z>", "<z")
			self.loaded_argument_help = loadFile.parse_data(file_2, "y>", "<y")
		else:
			self.instanceOfClass.podrobno_menu = loadFile.parse_data(file_2, "x>", "<x")
			self.instanceOfClass.loaded_slashes_help = loadFile.parse_data(file_2, "z>", "<z")
			self.instanceOfClass.loaded_argument_help = loadFile.parse_data(file_2, "y>", "<y")
		self.remote_based_commands = loadFile.parse_data(self.local_commands.stream_little_File(file="remote_commands.txt").decode("utf-8", errors="ignore"), "commands>", "<commands")
