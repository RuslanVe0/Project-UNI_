class UserProp(object):

	def __init__(self:object, instance:object) -> (object, object):
		self.instance = instance

	def change_password(self:object) -> (object):
		if len(self.instance.cmd.split(" ")) < 5:
			raise Exception("[operation.suserchange] Too few arguments provided!")
		usr, old_password, new_password = self.instance.cmd.split(" ")[2:]
		if self.user_existence(usr, old_password) == False:
			raise Exception("[operation.userchange] Invalid user. User could not be located!")
		inp = input("Are you really sure you want to change the password of '%s' user (y/n)>> "%(usr))
		xz = None if inp == "y" or inp == "Y" else "return"
		if xz != None:
			return
		new_password = self.instance.encrypt_pass(usr, new_password)
		self.instance.database(db="ftsrv", syntax="UPDATE __db__.user_ftsrv_accounts SET password='%s' WHERE username='%s'"%(new_password, usr))._insert()
		print("\n[operation.change_password] Password changed successfully!\n\n")
		return

	def show_acc_info(self:object) -> (object):
		if len(self.instance.cmd.split(" ")) < 2:
			raise Exception("[operation.show_acc_info] Too few arguments provided! Required 'username'!")
		usr = self.instance.cmd.split(" ")[2]
		if self.user_existence(username=usr, password=None) == False:
			raise Exception("[operation.show_acc_info] User not found!")
		sel_all = self.instance.database(db="ftsrv", syntax="SELECT * FROM __db__.user_ftsrv_accounts WHERE username='%s'"%(usr))._fetch()[0]
		inf = {0:"id", 1:"username", 2:"password", 3:"account_id", 4:"datetime", 5:"is_anonymous", 6:"active", 7:"is_administrator", 8:"active_admin"}
		zx = "~Information about '%s'!~\r\x0A"%(usr) + "\x0A".join("%s -> "%(inf[index]) + str(bob) for index, bob in enumerate(sel_all, 0)) + "\r\x0A"
		print(zx)
		return

	def change_username(self:object) -> (object):
		if len(self.instance.cmd.split(" ")) < 5:
			raise Exception("[operation.userChange] Too few arguments provided!")

		usr, pass_, nusr = self.instance.cmd.split(" ")[2:]
		if self.user_existence(usr, pass_) == False:
			raise Exception("[operation.userChange] User not found!")
		inp = input("Are you really sure you want to change the username of '%s' user>> "%(usr))
		xz = None if inp == "y" or inp == "Y" else "bob"
		if xz != None:
			return
		self.instance.database(db="ftsrv", syntax="UPDATE __db__.user_ftsrv_accounts SET username='%s' WHERE username='%s'"%(nusr, usr))._insert()
		print("\n[operation.change_username] Username changed successfully!")
		return

	def user_existence(self:object, username:str, password:str) -> (object, str, str):
		if password != None:
			pass_ = self.instance.encrypt_pass(username, password)
			xz = self.instance.database(db="ftsrv", syntax="SELECT * FROM __db__.user_ftsrv_accounts WHERE username='%s' AND password='%s'"%(username, pass_))._fetch()
		else:
			xz = self.instance.database(db="ftsrv", syntax="SELECT * FROM __db__.user_ftsrv_accounts WHERE username='%s'"%(username))._fetch()
		return False if len(xz) == 0 else True
	
	def user_operations(self:object, anon:bool, admin:bool):
		if anon == False:
			uploadfiles, browsedirs, removefiles, oneper, dirto, movdir, fixeddir, createDir, forbiddenDir = self.instance.instanceOfClass.account_rules["uploadFiles"], self.instance.instanceOfClass.account_rules["browseDirs"], self.instance.instanceOfClass.account_rules["removeFiles"], self.instance.instanceOfClass.account_rules["OneClientPerSess"], self.instance.instanceOfClass.account_rules["startdir"], self.instance.instanceOfClass.account_rules["movedir"], self.instance.instanceOfClass.account_rules["fixeddir"], self.instance.instanceOfClass.account_rules["createDir"], self.instance.instanceOfClass.account_rules["forbiddenDir"]
		elif anon == True and self.instance.instanceOfClass.normalProperties["anon"] == "True":
			uploadfiles, browsedirs, removefiles, oneper, dirto, movdir, fixeddir, createDir, forbiddenDir = self.instance.instanceOfClass.anonProperties["uploadFiles"], self.instance.instanceOfClass.anonProperties["browseDirs"], self.instance.instanceOfClass.anonProperties["removeFiles"], self.instance.instanceOfClass.anonProperties["OneClientPerSess"], self.instance.instanceOfClass.anonProperties["startdir"], self.instance.instanceOfClass.anonProperties["movedir"], self.instance.instanceOfClass.anonProperties["fixeddir"], self.instance.instanceOfClass.anonProperties["createDir"], self.instance.instanceOfClass.adminProp["forbiddenDir"]
		else:
			return False, "[operation.addusr] Anonymous account deactived in the 'config.ini' file! Not creating account for now...", None, None, None, None, None, None, None
		if admin == True and self.instance.instanceOfClass.normalProperties["adminAccount"] == "True":
			uploadfiles, browsedirs, removefiles, oneper, dirto, movdir, fixeddir, createDir, forbiddenDir = self.instance.instanceOfClass.adminProp["uploadFiles"], self.instance.instanceOfClass.adminProp["browseDirs"], self.instance.instanceOfClass.adminProp["removeFiles"], self.instance.instanceOfClass.adminProp["OneClientPerSess"], self.instance.instanceOfClass.adminProp["startdir"], self.instance.instanceOfClass.adminProp["movedir"], self.instance.instanceOfClass.adminProp["fixeddir"], self.instance.instanceOfClass.adminProp["createDir"], self.instance.instanceOfClass.adminProp["forbiddenDir"]
		elif admin == True and self.instance.instanceOfClass.normalProperties["adminAccount"] != "True":
			return False, "[operation.addusr] Admin account disabled!", None, None, None, None, None, None
		return True, uploadfiles, browsedirs, removefiles, oneper, dirto, movdir, fixeddir, createDir, forbiddenDir
