# each user will have a session.
"""
Client-1 -> session (threaded) in the actual thread pool.
It should be asynchronously! Up to N-allowed client connections (maximum is defined in 'config.ini' file).
The recommended connections are already defined in the "config.ini" file!
----------------------------------------------------------------------------
"""
from base64 import b64encode, b64decode
from hashlib import sha256
from uuid import uuid4
from Cryptodome.Cipher import AES
from json import dumps, loads
from utils.website import main as website_main

class session(object):
	def __init__(self:object, instance_self:object, instance_self_:object, socket:object, data:tuple) -> (object):
		self.inst = instance_self; self.data = data; self.inst.client_buffer = (2**16)-32
		self.sock = socket
		http_packet = None
		read = self.inst.readClient(buffer=int((self.inst.inst.instanceOfClass.normalProperties["recvBuffer"])), sockaddr=self.sock)
		if read == False:
			return
		self.old_based = read
		read = read.decode("utf-8", errors="ignore").strip()
		if self.inst.inst.instanceOfClass.website == True and read != "!website_ui":
			self.packet = read
			website_main.main(self, self.data, socket)
		elif read == "!website_ui":
			self.anti_robot()
			self.send_flag
			self.fing_recv = False
			self.recv_fing()
			self.receive_buffer()
			self.continuous_receive()
		raise Exception("Unknown purpose?")

	def receive_buffer(self:object):

		self.inst.send_normal_pkt(data=b"get_buffer", socket=self.sock)
		self.inst.client_buffer = int(self.inst.readClient(buffer=int(self.inst.inst.instanceOfClass.normalProperties["recvBuffer"]), sockaddr=self.sock).decode("utf-8", errors="ignore"))

	def anti_robot(self:object) -> (object):
		if self.inst.inst.instanceOfClass.normalProperties["antibot"] != "True":
			return
		key = ""
		msg_uuid = str(uuid4())
		datetime = self.inst.inst.getLocalTime()
		while key == "":
			nonce = self.random_nonce()
			# sending nonce message to client. The client is required to fetch the nonce message, create an AES message with it, and send it to the server.
			# After it is send, it should be checked whether it is True or False.
			"""
If something fails, it'll try again, again and again until it finally matches all specific data.
"""
			self.inst.send_normal_pkt(data=(("AntiBot-NONCE:%s"%(nonce))).encode("utf-8", errors="ignore"), socket=self.sock)
			self.inst.send_normal_pkt(data=dumps({"uuid":msg_uuid, "datetime":datetime}).encode("utf-8", errors="ignore"), socket=self.sock)
			recv_back_receive_msg = self.inst.readClient(buffer=int(self.inst.inst.instanceOfClass.normalProperties["recvBuffer"]), sockaddr=self.sock)
			if self.inst.inst.is_base64(recv_back_receive_msg) == False:
				self.inst.send_normal_pkt(data=b"error: incorrect base64-message! (x)", socket=self.sock)
				continue
			try:
				decryptedAes = AES.new(nonce.encode("utf-8", errors="ignore"), AES.MODE_GCM, nonce.encode("utf-8", errors="ignore")).decrypt(b64decode(recv_back_receive_msg))
				if self.inst.inst.is_json(decryptedAes, True) == False:
					self.inst.send_normal_pkt(data=b"error: incorrect json-like message! (x)", socket=self.sock)
					continue
			except Exception as f:
				self.inst.send_normal_pkt(data=b"error: incorrect AES-like message! (x)", socket=self.sock)
				continue
			decryptedAes = loads(decryptedAes)
			if ("uuid" not in decryptedAes or "datetime" not in decryptedAes or decryptedAes["uuid"] != msg_uuid or decryptedAes["datetime"] != datetime) == True:
				self.inst.send_normal_pkt(data=b"error: Missing key in json-like message! (x)", socket=self.sock)
				continue
			key = str(uuid4())
			self.inst.inst.instanceOfClass.anti_robot_id[self.fetch_uuid()] = {"uuid":key, "datetime":self.inst.inst.getLocalTime()}
			print(self.fetch_uuid())
			self.inst.send_normal_pkt(data=(dumps(self.inst.inst.instanceOfClass.anti_robot_id[self.fetch_uuid()]) + "_PARS_").encode("utf-8", errors="ignore"), socket=self.sock)

	def fetch_uuid(self:object):
		#print(self.data)
		xz = self.inst.inst.instanceOfClass.database(db="ftsrv", syntax="SELECT session_id FROM __db__.connections WHERE client='%s' AND port=%d"%(self.data[0][0], self.data[0][1]))._fetch()
		if len(xz) == 0:
			return None
		return xz[0][0]

	def random_nonce(self:object):
		xz = sha256()
		xz.update(b"random_nonce")
		xz.update((str(uuid4())).encode("utf-8", errors="ignore"))
		return xz.hexdigest()[:-32]

	def continuous_receive(self:object) -> (object):
		while True:
			if self.sock.fileno() == -1:
				break
			data = self.inst.readClient(buffer=int(self.inst.inst.instanceOfClass.normalProperties["recvBuffer"]), sockaddr=self.sock)
			if (self.fetch_uuid() == None):
				self.inst.send_normal_pkt(data=b"error::Critical conflict occured, while receiving data from client!", socket=self.inst.sock)
				self.inst.inst.close_connection(client=self.data[0][0], port=int(self.data[0][1]))
				break
			if ("fingerprint" not in self.inst.inst.instanceOfClass.logged_client_sessions[self.fetch_uuid()] or self.inst.inst.instanceOfClass.logged_client_sessions[self.fetch_uuid()]["fingerprint"] == False) and self.inst.inst.instanceOfClass.fingerprint == True:
				self.inst.send_normal_pkt(data=b"error::conflict_fingerprint\n", socket=self.inst.sock)
				self.inst.inst.close_connection(client=self.data[0][0], port=int(self.data[0][1]))
				break
			if self.check_Receive(data=data) == False:
				self.inst.inst.close_connection(client=self.data[0][0], port=int(self.data[0][1]))
				break

	def recv_fing(self:object, *args) -> (object):
		if self.inst.inst.instanceOfClass.fingerprint == False:
			return
		self.inst.send_normal_pkt(data=("FING_::%s"%(self.inst.inst.get_system_data(client=self.data[0][0]))).encode("utf-8", errors="ignore"), socket=self.inst.sock)
		receive_fing = self.inst.readClient(buffer=int(self.inst.inst.instanceOfClass.normalProperties["recvBuffer"]), sockaddr=self.sock)
		print(receive_fing)
		self.inst.inst.instanceOfClass.database(db="ftsrv", syntax="INSERT INTO __db__.client_fingerprints(client, fingerprint_base64, datetime) VALUES ('%s', '%s', '%s');"%(self.data[0][0], b64encode(receive_fing).decode("utf-8", errors="ignore"), self.inst.inst.getLocalTime()))._insert()
		self.inst.inst.instanceOfClass.logged_client_sessions[self.fetch_uuid()]["fingerprint"] = True

	def command_check(self:object, command:str) -> (object, str):
		command = command.decode("utf-8", errors="ignore").strip().lower()
		if command == "" or len(command) == 0:
			self.inst.send_normal_pkt(data=b"error::mempty\n", socket=self.inst.sock)
			return False
		if command.strip() == "req.info_menu":
			data = ("""
Welcome to this File Transfer server (%s). 
 * You can fetch the help menu, by sending 'help' data to the server.
 * Maximum connections allowed per clients - %s. Current connections -> %s-connection out of %s. %s more connections left..
 * Maximum length allowed - %s.
 * Maximum logins per a client - %s.
 * You are currently a guest, login in order to proceed!
 -------------------------------------------------------------------

 Thank you, enjoy and BE cReAtIvE!

"""%(self.inst.data[0][0],self.inst.inst.instanceOfClass.normalProperties["maxConnectedClients"],len(self.inst.inst.instanceOfClass.alive_sessions),self.inst.inst.instanceOfClass.normalProperties["maxConnectedClients"],(int(self.inst.inst.instanceOfClass.normalProperties["maxConnectedClients"])-len(self.inst.inst.instanceOfClass.alive_sessions)), self.inst.inst.instanceOfClass.normalProperties["recvLength"], self.inst.inst.instanceOfClass.firewallProperties["maxLoginPerHost"])).encode("utf-8", errors="ignore")
			self.inst.send_normal_pkt(data=data, socket=self.inst.sock)
			return
		if command.strip() == "uuidtok":
			find_ = self.inst.inst.locate_uuid_session_token(self.data[0])
			if len(find_) != 0:
				self.inst.send_normal_pkt(data=(find_[0][0]).encode("utf-8", errors="ignore"), socket=self.inst.sock)
			else:
				self.inst.send_normal_pkt(data=b"no-token", socket=self.inst.sock)
			return
		self.inst.inst.instanceOfClass.commands(command=command.strip(), socket_handler=self.inst, instance=self, sock=self.sock, data=self.data[0])

	def check_Receive(self:object, data:str) -> (object, str):
		if isinstance(data, bool) == False and int(self.inst.inst.instanceOfClass.normalProperties["recvLength"]) < len(data):
			self.inst.send_normal_pkt(data=b"error::mpkt\n", socket=self.inst.sock)
		return self.command_check(command=data)
		"""
		if isinstance(check, str) != True:
			pass
		if check == None:
			return
		self.inst.send_normal_pkt(data=check.encode("utf-8", errors="ignore"), socket=self.inst.sock)
		"""

	@property
	def send_flag(self:object):
		self.inst.send_normal_pkt(data=(self.inst.inst.instanceOfClass.normalProperties["flag"]).encode("utf-8", errors="ignore") + ("\x0AAnonymous account - usage >> %r"%(self.inst.inst.instanceOfClass.normalProperties["anon"])).encode("utf-8", errors="ignore") + ("\x0AFingerprint: '%r'"%(self.inst.inst.instanceOfClass.fingerprint)).encode("utf-8", errors="ignore") + b"\x0A", socket=self.inst.sock)