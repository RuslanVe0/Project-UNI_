import asyncore
from asyncio import run
from socket import socket, AF_INET, SOCK_STREAM
from threading import Thread
from uuid import uuid4
from utils.UserSessions import session
from uuid import uuid4
class Server(asyncore.dispatcher):

	def __init__(self, instanceOfClass:int):
		self.inst = instanceOfClass
		self.client_buffer = pow(2, 16)-32
		self.inst.connectedList = []
		self.inst.server_instance = self
		self.stop_server_connectionsSimult = False
		self.srsrv = []
		asyncore.dispatcher.__init__(self)
		self.request_Blacklist = False
		self.stop_server_connectionsFIREWALL = False
		self.mitg_stamp = None
		self.host_ = instanceOfClass.instanceOfClass.normalProperties["bindHost"]
		if "toH" in dir(self.inst):
			self.host_ = self.inst.toH
		self.port_ = int(instanceOfClass.instanceOfClass.normalProperties["bindPort"])
		self.inst.verbose_operation(text="[operation.start_server] Creating socket - %s:%d"%(self.host_, self.port_), handle=self.inst.instanceOfClass.verbose_srv)
		self.inst.verbose_operation(text="[operation.start_server] Firewall properties - %s"%(",".join("%s=%s"%(bob, self.inst.instanceOfClass.firewallProperties[bob]) for bob in self.inst.instanceOfClass.firewallProperties)), handle=self.inst.instanceOfClass.verbose_srv)
		self.create_socket(AF_INET, SOCK_STREAM)
		self.socket.settimeout(2)
		self.socket.setblocking(True)
		try:
			self.bind((self.host_, self.port_))
		except OSError as e:
			print("Uh-oh, it looks like an error occured, while binding the socket.. More further information: %s"%(e))
			raise asyncore.ExitNow("Stopping..")
		else:
			self.inst.verbose_operation(text="[operation.start_server] Server started!\n", handle=self.inst.instanceOfClass.verbose_srv)
			instanceOfClass.instanceOfClass.binded = True
			self.listen(pow(2, pow(2, 6)))
			instanceOfClass.instanceOfClass.sock = self.socket

	def handle_accept(self:object):
		from asyncio import run
		if len(self.inst.instanceOfClass.alive_sessions) > int(self.inst.instanceOfClass.normalProperties["maxConnectedClients"]):
			return
		if self.socket.fileno() == -1:
			self.close()
			return
		sock = self.accept()
		if self.inst.instanceOfClass.firewallProperties["max_wait"] != "":
			sock[0].settimeout(int(self.inst.instanceOfClass.firewallProperties["max_wait"])*60)
		if self.stop_server_connectionsFIREWALL == True and self.inst.instanceOfClass.check_Timing(stamp=self.mitg_stamp) == True:
			self.stop_server_connectionsFIREWALL = False; self.mitg_stamp = None
		if self.stop_server_connectionsSimult == True and self.inst.instanceOfClass.check_Timing(stamp=self.srsrv[0]) == True:
			self.stop_server_connectionsSimult = False; self.srsrv = []
		if sock != None and self.stop_server_connectionsFIREWALL == False and self.stop_server_connectionsSimult == False:
			sock, addr = sock
			self.addr, self.port = addr
			if self.inst.instanceOfClass.firewallProperties["dosmitg"] == "1":
				self.inst.instanceOfClass.mitg_pool[str(uuid4()) + "-" + addr[0]] = {"connected":self.inst.datetime_pool()}
				if len(self.inst.instanceOfClass.mitg_pool) > 1024:
					self.inst.instanceOfClass.mitg_pool	= {}
			if self.inst.instanceOfClass.normalProperties["updateConfigFile"] == "1":
				self.inst.instanceOfClass.load_attr(self.inst.instanceOfClass)
			async def running():
				read = ("\x0A".join(bob for bob in open(self.inst.instanceOfClass.currentWork + "/cont/blacklist", "r"))).split("\x0A")
				if addr[0] in [bob for bob in self.inst.instanceOfClass.firewallProperties["blacklist"].split(",")] and self.inst.instanceOfClass.normalProperties["firewallMode"] == "True" or len([bob for bob in read if addr[0] == bob]) != 0:
					sock.close()
					return
				if self.inst.instanceOfClass.firewallProperties["dosmitg"] == "1":
					self.inst.instanceOfClass.mitigation_strategy(client=addr[0], connectedList=self.inst.instanceOfClass.mitg_pool, instance=self)
					if self.request_Blacklist == True:
						self.inst.request_IP_BlackList(client=addr[0])
						self.request_Blacklist = False
				unique = str(uuid4())
				self.inst.unique_id = unique
				self.inst.instanceOfClass.database(db="ftsrv", syntax="INSERT INTO __db__.connections(client, port, datetime, session_id) VALUES ('%s', %d, '%s', '%s');"%(addr[0], addr[1], self.inst.getLocalTime(), unique))._insert()
				self.unikalen = unique
				def forclient():
					self.inst.instanceOfClass.alive_sessions[unique] = {"is_logged":None, "port-connected":addr[1], "socket":sock}
					self.inst.instanceOfClass.logged_client_sessions[unique] =  {"account_id":"", "logged":False, "typeacc":"System.Ftsrv/users/guest", "username":"guest", "timePool":self.inst.check_complexity(self.inst.getLocalTime(dict_like_obj=True))}
					self.inst.instanceOfClass.connectedList.append((self.inst.instanceOfClass.alive_sessions[unique]["socket"], (addr[0], addr[1])))
					self.inst.instanceOfClass.database(db="ftsrv", syntax="INSERT INTO __db__.alive_user_sessions(client, account_id, datetime_) VALUES ('%s', '%s', '%s');"%(addr[0], unique, self.inst.getLocalTime()))._insert()
					self.inst.instanceOfClass.database(db="ftsrv", syntax="INSERT INTO __db__.user_log(client, is_logged) VALUES ('%s', '%d')"%(unique, 0))._insert()
					if unique in self.inst.instanceOfClass.alive_sessions:
						Thread(target=self.listen_forever, args=(self.inst.instanceOfClass.alive_sessions[unique]["socket"], addr, self.port_)).start()
				Thread(target=forclient, args=()).start()
			run(running())
		elif self.stop_server_connectionsFIREWALL == True and len(self.inst.alive_sessions) != 0 or self.instanceOfClass.stop_server_connectionsSimult:
			self.inst.stop_all_connections()
			return
		elif self.stop_server_connectionsSimult:
			self.inst.stop_all_connections()
			return



	def fetchDataCl(self:object, recv_buff=165918):
		pass

	def send_normal_pkt(self:object, data:bytes, socket:object, flag=True, is_basic=False) -> (object, bytes, object, bool):
		if len(data) >= self.client_buffer and flag == True:
			socket.send(b"big_amount")
			return
		try:
			socket.send(data)
		except:
			return

	def send_file(self:object, file:str, socket:object, header:bytes) -> (list):
		socket.send(header)
		with open(file, "rb") as file:
			for content in file:
				socket.send(content)
		socket.close()

	def readClient(self:object, sockaddr:object, buffer:int) -> (object, int, object):
		try:
			return sockaddr.recv(buffer)
		except Exception as f:
			print(f)
			return False

	def remove_client(self:object, *args) -> (object, list):
		sock, addr, port = args
		index = [index for index, bob in enumerate(self.inst.connectedList, 0) if bob[1][0] == addr[0] and port == bob[1][1]]
		if len(index) != 0:
			del self.inst.connectedList[index[0]]
		unique = self.inst.instanceOfClass.database(db="ftsrv", syntax="SELECT session_id FROM __db__.connections WHERE client='%s' AND port=%d"%(addr[0], port))._fetch()
		if len(unique) == 0:
			return
		self.inst.instanceOfClass.database(db="ftsrv", syntax="DELETE FROM __db__.connections WHERE client='%s' AND port=%d"%(addr[0], addr[1]))._insert()
		self.inst.instanceOfClass.database(db="ftsrv", syntax="DELETE FROM __db__.alive_user_sessions WHERE client='%s'"%(addr[0]))._insert()
		self.inst.instanceOfClass.database(db="ftsrv", syntax="DELETE FROM __db__.user_log WHERE client='%s'"%(unique[0][0]))._insert()
		if len(unique) != 0 and unique[0][0] in self.inst.alive_sessions:
			try:
				del self.inst.instanceOfClass.alive_sessions[unique[0][0]]
			except:
				pass
		if self.inst.instanceOfClass.unique_id in self.inst.instanceOfClass.logged_client_sessions and "removed" not in self.inst.instanceOfClass.logged_client_sessions:
			del self.inst.instanceOfClass.logged_client_sessions[self.inst.instanceOfClass.unique_id]
		try:
			sock.close()
		except:
			pass

	def listen_forever(self:object, *args) -> (object):
		sock, addr, port = args
		self.sock = sock
		try:
			self.data = (addr, port)
			session(self, self.inst.instanceOfClass, sock, (addr, port))
		except Exception as e:
			print(e)
			self.remove_client(sock, addr, port)

class start_threaded_server(object):

	def serverInstance(self:object, less:tuple):
		Server(self)
		asyncore.loop()

	def __init__(self):
		Thread(target=start_threaded_server.serverInstance, args=(self, ())).start()