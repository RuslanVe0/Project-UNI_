from server.start_threaded_server import Server
class server(object):
	def __init__(self:object) -> (object):
		self.host_ = ""

	@property
	def start_server(self:object, *args) -> (object):
		pass

	@start_server.setter
	def set_host(self:object, host:str) -> (str):
		if (len(host.split(".")) != 4):
			raise Exception("[operation.set_host] Cannot set host. Invalid IPv4 address format.")
		self.host_ = host

xz = server()
xz.set_host = "192.168.3.4.4.6.6.6"
xz.start_server
