EDIT WEBSITEPATHS, AND EVERYTHING CORRELATED WITH IT, otherwise it won't run as it should...
-------
РЕДАКТИРАЙТЕ "WEBSITEPATHS", И ВСИЧКО СВЪРЗАНО С НЕГО, И ПОДОБНИ, ИНАЧЕ НЯМА ДА СЕ ИЗПЪЛНИ КАКТО ТРЯБВА....
Препратка: websitePath=""
	   websitepdfPath
	   startdir=""
	   startdir=""