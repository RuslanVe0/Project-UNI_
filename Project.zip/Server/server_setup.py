from setuptools import setup as PythonSetup
from argparse import ArgumentParser
from sys import stdout
from os.path import exists
from os import listdir
from os import chdir, getcwd
try:
	import mysql.connector
except ImportError as e:
	print("MySQL not installed! %s"%(e))
	exit()
class StartLocalInstallation(object):

	def __init__(self:object, verbose:bool, log:bool) -> (bool, bool):
		self.queries = []
		self.db_ = "ftsrv"
		print('''
Offical release of server_setup, which is installer of essential files in order server to work as it supposed to.
This program is supposed to setup - config.ini file and README.md file and to configure MySQL schemas and tables, in case if they are missing this is the place.
-----------------------------------------------
-----------------------------------------------
Thank you for choosing us, ;)!\r\x0A\r\x0A''')
		self.verbose = verbose; self.log = log
		self.output_verbose(msg="Preparing to install essential information... ")
		self.install_essent()			

	def output_verbose(self:object, msg:str):
		if self.verbose == True:
			stdout.write(msg + "\r\x0A")

	def enter_desired_records(self:object):
		self.output_verbose(msg="Preparing to configure desired queries ...")
		for queries in self.queries:
			mysql_handler = self.create_handlerMySQL(username=self.username, password=self.password, database=self.db_)
			curs = mysql_handler.cursor()
			curs.execute(queries)
			curs.close()

	def load_Queries(self:object):
		xz = True if input("Would you like to load queries? (y/n)>> ") == "y" else False
		if xz == False:
			return
		listed = listdir("%s/queries"%(getcwd()))
		queries = []
		for files in listed:
			queries.append("".join(bob for bob in open(getcwd() + "/queries/" + files, "r", encoding="utf-8")))
		self.queries = queries		

	def install_essent(self:object):
		# due it's protection level.
		essentials = [self.check_config_ini_file, self.check_readme_file]
		for methods in essentials:
			methods()
		self.create_schema_and_tables() if input("Do you want to automatically install - schema and tables right now (y/n): ").lower() == "y" else "f"
		self.enter_desired_records()
		self.output_verbose(msg="\r\x0A\r\x0ASetup completed!")

	def check_readme_file(self:object):
		__filename__ = "README.md"
		if exists(__filename__) == False:
			self.loadPipe(Readfile="readme_backup", Writefile=__filename__)
			return
		self.output_verbose(msg="README file already exists. Skipping!")

	def loadPipe(self:object, Readfile:str, Writefile:str) -> (str, str):
		op = open(Writefile, "w")
		op.write("".join(bob for bob in open("installationFiles/%s"%(Readfile), "r")))
		op.close()
		return

	def create_schema_and_tables(self:object):
		self.username, self.password = input("Please, input your RDBMS MySQL username: "), input("Please, input your RDBMS MySQL password: ")
		self.load_Queries()
		db_ = None
		syntaxes = [
		("CREATE DATABASE IF NOT EXISTS ftsrv", None),
		("CREATE TABLE IF NOT EXISTS user_log(id int primary key auto_increment not null, client text, is_logged tinyint(1));", "user_log"),
		("CREATE TABLE IF NOT EXISTS user_ftsrv_accounts(id int primary key auto_increment not null, username varchar(256), password varchar(512), account_id varchar(128), datetime_created varchar(128), is_anon bool, active bool);", "user_ftsrv_accounts"),
		("CREATE TABLE IF NOT EXISTS server_outage_info(id int primary key auto_increment not null, level tinyint, description varchar(128));", "server_outage_info"),
		("CREATE TABLE IF NOT EXISTS server_outage(id int primary key auto_increment not null, outage_type varchar(512), datetime varchar(512), notes varchar(128), level tinyint);", "server_outage"),
		("CREATE TABLE IF NOT EXISTS request_given(id int primary key auto_increment not null, client varchar(16), request_id varchar(36), type varchar(64), datetime varchar(512));","request_given"),
		("CREATE TABLE IF NOT EXISTS login_log_client(id int primary key auto_increment not null, account_id text, client_id text, datetime text, note text, host text);", "login_log_client"),
		("CREATE TABLE IF NOT EXISTS connections(id int primary key auto_increment not null, client varchar(16), port int, datetime text, session_id text)", "connections"),
		("CREATE TABLE IF NOT EXISTS client_fingerprints(id int primary key auto_increment not null, client varchar(15), fingerprint_base64 varchar(2048), datetime varchar(512));","client_fingerprints"),
		("CREATE TABLE IF NOT EXISTS alive_user_session(id int primary key auto_increment not null, client text, account_id text, datetime_ text);", "alive_user_session"),
		("CREATE TABLE IF NOT EXISTS account_rules(id int primary key auto_increment not null, account_id text, append_files tinyint(1), remove_files tinyint(1), start_directory text, fetch_files tinyint(1), account_usage_per_clients int, movdir int, browse_files int, is_anon tinyint(1), fixeddir text);", "account_rules"),
		("CREATE TABLE IF NOT EXISTS website_paths(id int primary key auto_increment not null, path text, content_type text, permissions text, directory_suffix text, accessible_ text)", "website_paths"),
		("CREATE TABLE IF NOT EXISTS website_contents_specific(id int primary key auto_increment not null, system_account_ text, encoded_base64 text, name text);", "website_contents_specific"),
		("CREATE TABLE IF NOT EXISTS website_logins(id int primary key auto_increment not null, client text, port int, wuuid text);", "website_logins"),
		("CREATE TABLE IF NOT EXISTS website_upload_(id int primary key auto_increment not null, client text, file text, file_destination text);", "website_upload_"),
		("CREATE TABLE IF NOT EXISTS user_action(id int primary key auto_increment not null, client varchar(256), account_id text, file text, datetime text, note text)", "user_action"),
		("CREATE TABLE IF NOT EXISTS path_securities(id int primary key auto_increment not null, client_uuid text, security_uuid text, path text)", "path_securities"),
		("CREATE TABLE IF NOT EXISTS auto_auth(id int primary key auto_increment not null, account_id text, encrypted_msg text, pub text, priv text, datetime text, ip_address varchar(16))", "auto_auth"),
		("CREATE TABLE IF NOT EXISTS connectivity_issues(id int primary key auto_increment, client text, port int, datetime text, notes text)", "connectivity_issues"),
		("CREATE TABLE IF NOT EXISTS logout_errors(id int primary key auto_increment not null, client_id text, message text, datetime text);", "logout_errors"),
		("CREATE TABLE IF NOT EXISTS pdf_(id int primary key auto_increment not null, pdf_id int, path text, accessibility int)", "pdf_")
		]
		for syntax, tables in syntaxes:
			self.output_verbose(msg="Preparing to configure '%s' table!"%(tables))
			mysql_handler = self.create_handlerMySQL(username=self.username, password=self.password, database=db_)
			if mysql_handler == False:
				continue
			try:
				curs = mysql_handler.cursor()
				curs.execute(syntax)
				curs.close()
				if db_ == None:
					self.output_verbose(msg="Created schema '%s'!"%(tables))
					db_ = "ftsrv"
					continue
				self.output_verbose(msg="Created '%s' table in schema ftsrv!"%(tables))
			except Exception as f:
				print(f)
				self.output_verbose(msg="Could not create table '%s'!"%(tables))
		self.output_verbose(msg="Created tables!")
		return


	def create_handlerMySQL(self:object, username:str, password:str, database:str) -> (object, str, str):
		try:
			if database == None:
				return mysql.connector.connect(host="localhost", user=username, password=password)
			return mysql.connector.connect(host="localhost", user=username, password=password, database=database)
		except mysql.connector.errors.ProgrammingError:
			print("Unauthorized access!")
			return False

	def check_config_ini_file(self:object):
		# in order to configure the - "config.ini" file. The user can do that option manually.
		__filename__ = "config.ini"
		if exists(__filename__) == False:
			self.loadPipe(Readfile="backup_config_ini", Writefile=__filename__)
			return
		self.output_verbose(msg="Config.ini file already exists! Skipping!")


if __name__ == "__main__":
	arg = ArgumentParser(prog="Setup file", description="File for installation of features related to FTSRV software. RDBMS configaration")
	arg.add_argument("-l", "--log", action="store_true", help="Logging in a local file.")
	arg.add_argument("-v",  "--verbose", action="store_true", help="Program verbosity, in order there to be a output of whats going on.")
	args = arg.parse_args()
	StartLocalInstallation(verbose=args.verbose, log=args.log)