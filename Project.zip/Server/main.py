from utils.loads_ import *
from utils.env import *
from utils.commands import commands_Interface as commands
from utils.UserAdministration import UserProp
from utils.database import database
from utils.mitigation_strategy import mitigation_strategy
from server.start_threaded_server import * 
from os import getcwd
import pdb
from threading import Thread
from datetime import datetime
from typing import Union, Type
from functools import partial
from Cryptodome.Cipher import AES
from uuid import uuid4
from hashlib import sha256, sha512, md5
from os import system as os_system
from socket import SHUT_RDWR
from platform import platform,system,machine, architecture
from sys import stdout
from utils.local_commands import local_commands
import ctypes
class startServer(loadFile, run_no_gui, start_threaded_server):

	def __init__(self:object, configFile="config.ini") -> (object, str):
		self.local_commands = local_commands(self)
		self.currentWork = getcwd()
		self.server_instance = None
		self.commands = commands
		self.Clientlog = False
		self.anti_robot_id = {}
		self.instation = None
		stdout.write("\x2D"*50 + """\x0A[EN-version] This is official release of the server. There is a difference between the client, and the difference is that - commands that are inputed by the user could be both used in local and when the server is started envoirnment.
In the client it should be configured with - 'lprov' command.\x0A
There'll be a designed GUI in a future reference both for - server and client. Thank you for reading this text!\x0A'help' for more help. 

Notice: If you haven't runned the installation file, this server won't be configured correctly and might gives errors!\x0A\x0A""")
		# alive sessions pool.
		self.load_attr = loadFile.__init__; self.mitg_pool = {}; self.mitigation_strategy = mitigation_strategy
		self.uploaded_files = {}; self.log_of_uploaded = {}
		self.configFile = configFile; self.currdir = getcwd(); self.binded = False; self.database = database; self.connectedList = []; self.binded = False; self.alive_sessions = {}; self.User = UserProp; self.logged_client_sessions = {}
		loadFile.__init__(self)
		self.fingerprint = int(self.normalProperties["fing"])
		# in ordrer to choose an environment desired by the user.
		self.chooseEnv()

	def chooseEnv(self:object) -> (object):
		# when that happens, thus it'll call NO gui and will launch the UI.
		splitted = self.normalProperties["env"].split(",")
		if "cmd_ui" in splitted:
			run_no_gui.__init__(self, True if "website_ui" in splitted else False)


if __name__ == "__main__":
	startServer()